/* eslint-disable dot-notation */
import { Component, OnInit, TemplateRef, ViewChild, ElementRef, HostListener, Renderer2, ViewChildren, QueryList } from '@angular/core';
import { Router } from '@angular/router';
import { AutoCompleteComponent } from '@progress/kendo-angular-dropdowns';
import { CustomerSearchResult } from '../../models/customer-search-result.model';
import { KendoModalService, RestService, SelectedCustomerService } from '../../services';
import { NewEditEarningsComponent } from '../earnings/new-edit-earnings/new-edit-earnings.component';
import { ConsoGrpSelectionComponent } from '../consolidations/conso-grp-selection/conso-grp-selection.component'
import { ConsolidationMaintenanceComponent } from '../consolidations/consolidation-maintenance/consolidation-maintenance.component'
import { WindowCloseResult, WindowService } from '@progress/kendo-angular-dialog';
import { environment } from '../../../../../CreditPro/src/environments/environment';
import { select, Store } from '@ngrx/store';
import { AppState } from '../../store';
import * as actions from '../../store/actions';
import { userCustomers } from '../../store/selectors/customer.selector';
import { cloneDeep } from 'lodash';
import { NewEditBalanceSheetComponent } from '../balancesheet/new-edit-balance-sheet/new-edit-balance-sheet.component';
import { UtilityService } from '../../services/utility/utility.service';
import { AppConstant } from '../../constants/app-constants';
import { AdminOptionComponent } from '../admin-option/admin-option.component';
import { AlertDialogComponent } from '../alert-dialog/alert-dialog.component';
import { WindowDialogComponent } from '../window-dialog/window-dialog.component';
import { CustomerDetails } from '../../models/customerDetails.model';
import { EarningsStatementProjectionComponent } from '../earnings/earnings-statement-projection/earnings-statement-projection.component';
import { OpenStatementComponent } from '../open-statements/open-statements.component';
import { OpenProjectedESComponent } from '../earnings/open-projected-es/open-projected-es.component';
import { FinancialStatementSubType } from '../../enum/financialStatementSubType';
import { TooltipDirective } from '@progress/kendo-angular-tooltip'
import { NewProjectedBSComponent } from '../balancesheet/new-projected-bs/new-projected-bs.component';
import { OpenConsolidationsComponent } from '../consolidations/open-consolidations/open-consolidations.component';
import { OpenEarningStatementComponent } from '../earnings/open-earning-statement/open-earning-statement.component';


@Component({
  selector: 'lib-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss']
})
export class MenuComponent implements OnInit {
  @ViewChild('anchor') public anchor: ElementRef;
  @ViewChild('searchIcon') public searchIcon: ElementRef;
  @ViewChild('popup', { read: ElementRef }) public popup: ElementRef;
  @ViewChild('bSWindowTitleBar', { static: false, read: TemplateRef }) public bSWindowTitleBar
  @ViewChild('pBSWindowTitleBar', { static: false, read: TemplateRef }) public pBSWindowTitleBar
  @ViewChild('earningWindowTitleBar', { static: false, read: TemplateRef }) public earningWindowTitleBar
  @ViewChild('consoGrpSelectionWindowTitleBar', { static: false, read: TemplateRef }) public consoGrpSelectionWindowTitleBar
  @ViewChild('consoGrpSelectionWindowTitleBarBal', { static: false, read: TemplateRef }) public consoGrpSelectionWindowTitleBarBal
  @ViewChild('consolidationMaitenanceWindowTitleBar', { static: false, read: TemplateRef }) public consolidationMaitenanceWindowTitleBar
  @ViewChild('consolidationMaitenanceWindowTitleBarBal', { static: false, read: TemplateRef }) public consolidationMaitenanceWindowTitleBarBal

  @ViewChild('createNewProjES', { static: false, read: TemplateRef }) public createNewProjectionES;
  @ViewChild('openStatement', { static: false, read: TemplateRef }) public openStatement;
  @ViewChildren(TooltipDirective) public tooltipDir: QueryList<TooltipDirective>;
  @ViewChild('openConsolidationWindowTitleBarBal', { static: false, read: TemplateRef }) public openConsolidationsTitleBar;

  // @ViewChild("autocomplete", { static: false })
  // @ViewChild('menuAnchor') menuAnchor: ElementRef;
  isLoading = false;
  bsWinTitle: string;
  placeholderSearch = 'Customer Search';
  showblsubmenu = false;
  searchList: CustomerSearchResult = {};
  empowerCustomerList: CustomerSearchResult = {};
  searchFilterList: CustomerSearchResult = {};
  opened = false;
  selectedCustomer = '';
  isOpen = false;
  public autocomplete: AutoCompleteComponent;
  customerSearch = '';
  public show = false;
  public expandedKeys: any[] = ['0'];
  public expandedKeysSearch: any[] = ['0'];

  public toggleText = 'earningsShow';
  public earningsShow = false;

  public selectedCustomerDetails: CustomerDetails = {};

  windowRef;
  showBSMenu: boolean;
  showEarningMenu: boolean;
  recentlyViewedCustomersLbl = 'Recently Viewed Customers';
  empowerLbl = 'EmPOWER Key Customers';
  menus: any[] = AppConstant.appMenus;
  clickedMenuItem;
  lastTouchUserInfo: any;
  searchText = '';
  public static page: string = '';
  helpToolTip = 'hover';
  infoToolTip = 'hover';
  public showhelp: boolean = true;
  public showinformation: boolean = true;
  closeAnchor: any[];

  constructor (
    private router: Router,
    private restService: RestService,
    private kendoModalService: KendoModalService,
    private utiltyService: UtilityService,
    private store: Store<AppState>,
    private eRef: ElementRef,
    private _selectedCustomerService: SelectedCustomerService,
    private renderer: Renderer2,
    private windowService: WindowService
  ) {
    this.renderer.listen('window', 'click', (e) => {
      // console.log(e.target, this.menuAnchor)

    })
  }

  @HostListener('document:click', ['$event'])
  onPageClick (event): void {
    if (!this.eRef.nativeElement.contains(event.target)) {
      this.menus = this.menus.map(it => {
        return { ...it, clickedMenu: false };
      });
    }
  }

  ngOnInit (): void {
    new Promise((resolve, reject) => {
      resolve(this.store.dispatch(actions.customers({})));
    }).then(d => {
      this.initializeFormLoad();
    });
  }

  showEnterHelpTooltip (checked) {
    this.helpToolTip = 'none'
    this.showhelp = checked;
  }

  showEnterInfoTooltip (checked) {
    this.infoToolTip = 'none'
    this.showinformation = checked;
  }

  hideHelpToolTip () {
    this.helpToolTip = 'hover';
    this.showhelp = true;
    // this.tooltipDir.toArray()[0].hide();
    // this.tooltipDir.filter((element, index) => index === 0);
    this.tooltipDir.forEach((element) => {
      // eslint-disable-next-line dot-notation
      this.closeAnchor = element['anchor'];
      if (this.closeAnchor['nativeElement'].className === 'help') {
        element.hide();
      }
    });
  }

  hideInfoToolTip () {
    this.infoToolTip = 'hover'
    this.showinformation = true;
    this.tooltipDir.forEach((element) => {
      this.closeAnchor = element['anchor'];
      if (this.closeAnchor['nativeElement'].className === 'info') {
        element.hide();
      }
    });
  }

  getBsTitle (): void {
    // this.utiltyService.title.subscribe((value: string) =>
    //   this.bsWinTitle = value
    // );

    // this.utiltyService.title.subscribe((response) => {
    //   this.bsWinTitle = response;
    // });
  }

  initializeFormLoad (): void {
    // eslint-disable-next-line no-unused-expressions
    this.empowerCustomerList
      ? this.empowerCustomerList.Customers =
      [{ CustomerName: 'EmPOWER Key Customers', CustomerTasks: this.empowerCustomerList.Customers }]
      : null
    this.store.pipe(select(userCustomers))
      .subscribe(data => {
        this.searchList = cloneDeep(data.customer.RetrieveFavoriteRecentCustomersByUserIDResult);
        this.searchList = this.searchList ? this.filterSaerchData(this.searchList) : null;
        // eslint-disable-next-line no-unused-expressions
        this.searchList
          ? this.searchList.Customers =
          [{ CustomerName: 'Recently Viewed Customers', CustomerTasks: this.searchList.Customers }]
          : null
      });
  }

  private filterSaerchData (dataToFilter: any) {
    dataToFilter.Customers.forEach((customer) => {
      customer.CustomerTasks = [];
      dataToFilter.CustomerTasks.forEach(customerTask => {
        if (customer.CustomerBID === customerTask.CustomerBID) {
          customer.CustomerTasks.push(customerTask);
        }
      });
    });

    return dataToFilter;
  }

  handleFilter (event: any) {
    const paramsData: any = {
      searchString: this.customerSearch
    }
    this.searchText = '';
    this.searchFilterList = {};
    if (event.key === 'Enter' || event === 'search') {
      if (this.customerSearch.length >= 3) {
        this.isLoading = true;
        const apiUrl = environment.baseURI + environment.endpoints.customerSearchListURL;
        this.restService.post(apiUrl, paramsData).subscribe((data: any) => {
          this.searchFilterList = data.CustomerSearchWithTasksResult;
          this.searchFilterList = this.filterSaerchData(this.searchFilterList);
          if (this.searchFilterList.Customers.length === 0) {
            this.searchFilterList.Customers = [{ CustomerName: 'No results', CustomerTasks: this.searchFilterList.Customers }];
            this.searchText = this.searchFilterList.Customers[0].CustomerName;
          }
          // eslint-disable-next-line no-unused-expressions
          this.searchFilterList
            ? this.searchFilterList.Customers =
            [{ CustomerName: 'Search', CustomerTasks: this.searchFilterList.Customers }]
            : null;
          this.isLoading = false;
        });
      } else {
        this.searchFilterList.Customers = [{ CustomerName: 'Min. 3 characters required', CustomerTasks: this.searchFilterList.Customers }];
        this.searchText = this.searchFilterList.Customers[0].CustomerName;
        // eslint-disable-next-line no-unused-expressions
        this.searchFilterList
          ? this.searchFilterList.Customers =
          [{ CustomerName: 'Search', CustomerTasks: this.searchFilterList.Customers }]
          : null;
      }
    }
  }

  searchClick (): void {
    this.onToggle();
    this.handleFilter('search');
  }

  onFinancialStatementHover (id: any): void {
    const paramsData = {
      financialStatementBID: id
    };
    const apiUrl = environment.baseURI + environment.endpoints.retrieveLastInfo;
    this.restService.post(apiUrl, paramsData).subscribe((data: any) => {
      this.lastTouchUserInfo = data.RetrieveLastChangedInformationByFinanicalStatementBIDResult;
    });
  }

  openSelectedCustomer (customer: any): void {
    this.store.dispatch(actions.updateCustomersData({
      customer: {
        RetrieveFavoriteRecentCustomersByUserIDResult: {
          CustomerTasks: customer.CustomerTasks,
          Customers: customer
        }
      }
    }));
    this._selectedCustomerService.setCustomerOpenedSelectedInfo(customer.CustomerBID, customer.CustomerName, true, false, false, {}, null);
    this.onToggle(false);
    this.router.navigate(['home']);
  }

  openTrendingView (dataItem: any): void {
    this.onToggle(false);
    if (dataItem.FinancialStatementSubTypeCde === FinancialStatementSubType.BalanceSheet ||
      dataItem.FinancialStatementSubTypeCde === FinancialStatementSubType.BalanceSheetConsolidation ||
      dataItem.FinancialStatementSubTypeCde === FinancialStatementSubType.BalanceSheetProjection) {
      this.router.navigateByUrl('balance-sheet', { state: dataItem });
    } else if (dataItem.FinancialStatementSubTypeCde === FinancialStatementSubType.EarningsStatement) {
      this.router.navigateByUrl('earnings', { state: dataItem });
    }
  }

  onClickBalancesheet (): void {
    this.router.navigate(['balancesheetBS']);
  }

  onClickBalancesheet2 (): void {
    this.newBalanceSheetForm(this.bSWindowTitleBar);
    this.showblsubmenu = true;
  }

  openStatementWindow () {
    this.windowRef = this.windowService.open({
      title: 'Open Statements',
      content: OpenStatementComponent,
      minWidth: 400,
      width: 400,
      minHeight: 400,
      height: 400
    })
  }

  newBalanceSheetForm (titleContent: TemplateRef<any>) {
    this.selectedCustomer = this._selectedCustomerService.getCurrentSelectedCustomer2().customerName;
    this.opened = true;
    this.windowRef = this.kendoModalService.open('window', 'balanceSheetForm',
      NewEditBalanceSheetComponent,
      { titleBarContent: titleContent });
    this.showblsubmenu = true;

    this.windowRef.result.subscribe((result) => {
      if (result instanceof WindowCloseResult) {
        this.opened = false;
        this.utiltyService.dialogClose(true);
      }
    });
  }

  createNewProjBS(titleContent: TemplateRef<any>) {
    this.selectedCustomer = this._selectedCustomerService.getCurrentSelectedCustomer2().customerName;
    this.opened = true;
    this.windowRef = this.kendoModalService.open('window', 'newProjectedBS',
    NewProjectedBSComponent,
      { titleBarContent: titleContent });
      let projectionSelection = this.windowRef.content.instance
      projectionSelection.page = "Projection"
       this.showblsubmenu = true;

    this.windowRef.result.subscribe((result) => {
      if (result instanceof WindowCloseResult) {
        this.opened = false;
        this.utiltyService.dialogClose(true);
      }
    });
  }

  openBalanceSheetTrendView () {
    this.store.dispatch(actions.initialGridDataLoad({ customerId: 123, gridType: 'balancesheet' }))
    this.router.navigate(['/balancesheet']);
  }

  onClickReports () {
    this.router.navigate(['/reports'])
    this.showblsubmenu = true;
  }

  onClickHome () {
    this.router.navigate(['']);
  }

  openEarnings () {
    // const params = {
    //   width: 500,
    //   height: 'auto',
    //   top: 50,
    //   left: 150,
    //   titleBarContent: titleContent
    // }
    this.opened = true;
    this.windowRef = this.kendoModalService.open('window', 'openBalanceSheet',
    OpenEarningStatementComponent,
      { titleBarContent: this.openStatement })
    this.showblsubmenu = true;
    this.windowRef.result.subscribe((result) => {
      if (result instanceof WindowCloseResult) {
        this.opened = false;
        this.utiltyService.dialogClose(true);
      }
    });
    this.opened = false;
    // this.earningsShow = !this.earningsShow;
    // this.toggleText = this.earningsShow ? 'Hide' : 'Show';
    // this.store.dispatch(actions.initialGridDataLoad({ customerId: 123, gridType: 'earning' }))

    // this.router.navigate(['/earnings'])
  }
  


  openConsoGrpSelection(titleContent: TemplateRef<any>, page: string) {
    // MenuComponent.page = page;
    const params: any = {
      width: 600,
      height: 400,
      titleBarContent: titleContent
    };

    this.opened = true;
    this.windowRef = this.kendoModalService.open('window', 'consoGrpSelection', ConsoGrpSelectionComponent, params)
    let consolidationGroupSelection = this.windowRef.content.instance
    consolidationGroupSelection.page = page
    this.showblsubmenu = true;

    this.windowRef.result.subscribe((result) => {
      if (result instanceof WindowCloseResult) {
        this.opened = false;
        this.utiltyService.dialogClose(true);
      }
    });
  }

  openConsolidationMaintenance (titleContent: TemplateRef<any>, page: string) {
    // MenuComponent.page = page;
    const params: any = {
      width: 800,
      height: 550,
      titleBarContent: titleContent
    };

    this.opened = true;
    this.windowRef = this.kendoModalService.open('window', 'ConsolidationMaintenanceComponent', ConsolidationMaintenanceComponent, params)
    let consolidationMaintenance = this.windowRef.content.instance
    consolidationMaintenance.page = page
    this.showblsubmenu = true;

    this.windowRef.result.subscribe((result) => {
      if (result instanceof WindowCloseResult) {
        this.opened = false;
        this.utiltyService.dialogClose(true);
      }
    });
  }

  newEarnings (titleContent: TemplateRef<any>) {
    const params = {
      width: 500,
      height: 'auto',
      top: 50,
      left: 150,
      titleBarContent: titleContent
    }
    this.selectedCustomer = this._selectedCustomerService.getCurrentSelectedCustomer2().customerName;
    this.opened = true;
    this.windowRef = this.kendoModalService.open('window', 'newEarningsForm',
      NewEditEarningsComponent,
      params)
    this.showblsubmenu = true;

    this.windowRef.result.subscribe((result) => {
      if (result instanceof WindowCloseResult) {
        this.opened = false;
        this.utiltyService.dialogClose(true);
      }
    });

    // this.opened = false;
  }

  openProjected (titleContent: TemplateRef<any>) {
    this.windowRef = this.kendoModalService.open('window', 'openProjectedES',
      OpenProjectedESComponent,
      { titleBarContent: 'Projection Selection' })
  }

  checkCurrentRoute (route, check?) {
    if (check) {
      if (this.router.url.includes(route) && (route === 'balance' || route === 'earning')) {
        return true;
      }
      return false;
    } else {
      if (this.router.url.includes(route)) {
        return true;
      }
      return false;
    }
  }

  openEarningTrendView () {
    this.store.dispatch(actions.initialGridDataLoad({ customerId: 123, gridType: 'earning' }))

    this.router.navigate(['earnings']);
  }

  // Added to close search popup on clicking outside
  @HostListener('keydown', ['$event'])
  public keydown (event: any): void {
    if (event.keyCode === 27) {
      this.onToggle(false);
    }
  }

  @HostListener('document:click', ['$event'])
  public documentClick (event: any): void {
    if (!this.contains(event.target)) {
      this.customerSearch = '';
      this.onToggle(false);
    }
  }

  public onToggle (show?: boolean): void {
    this.show = show !== undefined ? show : !this.show;
  }

  private contains (target: any): boolean {
    return (
      this.anchor.nativeElement.contains(target) || this.searchIcon.nativeElement.contains(target) ||
      (this.popup ? this.popup.nativeElement.contains(target) : false)
    );
  }

  onClickAdminOptions () {
    const params = {
      width: 800,
      height: 600
    }
    this.opened = true;
    this.windowRef = this.kendoModalService.open('window', 'adminOptions', AdminOptionComponent, params);
    this.windowRef.result.subscribe((result) => {
      if (result instanceof WindowCloseResult) {
        this.opened = false;
      }
    });
  }

  onClickOpenBalancesheet (selectedCust: number) {
    //Needs to be modified/removed when dynamic data is binded
    if (selectedCust!= 283605) {
      const body = {
        userId: 1932,
        customerId: 285578,
        appViewCde: 4,
        trendViewMode: 1,
        financialStatementType: 1,
        financialStatementSubTypes: 1,
        financialSheetIds: [6134860],
        IsNewFinancialStatement: true
      }
      this.store.dispatch(actions.initialBSGridDataLoad(body))
      this.router.navigate(['balancesheet']);
    }
    
    else
    this.alertNoBS();
  }

  alertNoBS() {
    this.router.navigate(['balancesheet']);
    this.opened = true;
    const params = {
      title: 'Attention',
      width: 300
    }
    let window: any = this.kendoModalService.open('window', 'alertDialog', WindowDialogComponent, params)
    const windowContent = window.content.instance;
    windowContent.body = `This customer does not have any Balance Sheet statements.\
    Click "New..." to create a new Balance Sheet statement.`;
    windowContent.btnText = 'New...';
    windowContent.showLinkWithBtn = false;
    
    window.result.subscribe((response) => {
      if (response instanceof WindowCloseResult) {
        this.opened = false;
      }
      else {
        if(response === 'ok')
        this.newBalanceSheetForm(this.bSWindowTitleBar);
      }
      window = null;
    });

  }

  // End block added for closing popup on clicking outside
  menuClickEvent (event) {
    const eventName = event.item.eventName
    event.item.clickedMenu = !event.item.clickedMenu
    this.menus.forEach(it => {
      if (it.text !== event.item.text) it.clickedMenu = false;
    })

    let customerSelected = false;
    customerSelected = this._selectedCustomerService.hasSelectedCustomer();
    const selectedCustId = customerSelected ? this._selectedCustomerService.getCurrentSelectedCustomer2()?.customerId : null;
    switch (eventName) {
      case 'openEarnings()':
        customerSelected ? this.openEarnings() : this.alertUser();
        break;
      case 'newBalanceSheet()':
        customerSelected ? this.newBalanceSheetForm(this.bSWindowTitleBar) : this.alertUser();
        // customerSelected ? this.isCustomerSelected() : this.alertUser();
        break;
      case 'openBalanceSheet()':
        customerSelected ? this.onClickOpenBalancesheet(selectedCustId) : this.alertUser();
        break;
       case 'openBalanceSheetTrendView()':
       customerSelected ? this.onClickOpenBalancesheet(selectedCustId) : this.alertUser();
       break;
      case 'onClickBalancesheet2()':
        this.onClickBalancesheet2();
        break;
      case 'openEarningTrendView()':
        this.openEarningTrendView();
        break;
      case 'newEarnings()':
        customerSelected ? this.newEarnings(this.earningWindowTitleBar) : this.alertUser();
        break;
      case 'onClickReports()':
        customerSelected ? this.onClickReports() : this.alertUser();
        break;
      case 'adminOptions()':
        this.onClickAdminOptions();
        break;
      case 'createNewProjES()':
        this.createNewProjES(this.createNewProjectionES);
        break;
      case 'createNewProjBS()':
        this.createNewProjBS(this.pBSWindowTitleBar);
        break;
      case 'openConsoGrpSelection()':        
        this.openConsoGrpSelection(this.consoGrpSelectionWindowTitleBar, 'earning');
        break;
      case 'openConsoGrpSelectionBal()':
        this.store.dispatch(actions.consolidationGroup({
          CustomerBID: this._selectedCustomerService.getCurrentSelectedCustomer2().customerId,
          EmPOWER: true, includeActiveGroupsOnly: true
        }))
        this.openConsoGrpSelection(this.consoGrpSelectionWindowTitleBarBal, 'balansheet');
        break;
      case 'openConsolidationsBal()':        
      this.store.dispatch(actions.openConsolidation({
        customerBID: this._selectedCustomerService.getCurrentSelectedCustomer2().customerId,
        includeBS: true, includeES: false, includeActiveGroupsOnly: true
      }))
        this.openConsolidations(this.openConsolidationsTitleBar, 'balanceSheet');
        break;
      case 'openConsolidationMaintenance()':
        this.openConsolidationMaintenance(this.consolidationMaitenanceWindowTitleBar, 'earning');
        break;
      case 'openConsolidationMaintenanceBal()':
        this.openConsolidationMaintenance(this.consolidationMaitenanceWindowTitleBarBal, 'balansheet');
    }
  }


  openConsolidations(openConsolidationsTitleBar: any, page: string) {
    const params: any = {
      width: 500,
      height: 400,
      titleBarContent: openConsolidationsTitleBar
    };

    this.opened = true;
    this.windowRef = this.kendoModalService.open('window', 'OpenConsolidations', OpenConsolidationsComponent, params)
    let openConsolidations = this.windowRef.content.instance;
    openConsolidations.page = page;
    this.showblsubmenu = true;

    this.windowRef.result.subscribe((result) => {
      if (result instanceof WindowCloseResult) {
        this.opened = false;
        this.utiltyService.dialogClose(true);
      }
    });
  }

  createNewProjES (titleContent: TemplateRef<any>) {
    this.opened = true;
    this.windowRef = this.kendoModalService.open('window', 'newProjectionES',
      EarningsStatementProjectionComponent,
      { titleBarContent: titleContent })

    this.windowRef.result.subscribe((result) => {
      if (result instanceof WindowCloseResult) {
        this.opened = false;
        this.utiltyService.dialogClose(true);
      }
    });

    this.opened = false;
  }

  onSelect (e) {
  }

  onOpen (event) {
    if (event.index.includes('_')) {
      return;
    }
    this.menus.forEach(it => {
      if (it.text !== event.item.text) it.clickedMenu = false;
      // return it
    })
    event.item.clickedMenu = true;
  }

  onClose (event) {
    if (event.index.includes('_')) {
      return;
    }
    this.menus.forEach(it => {
      it.clickedMenu = false
    })
  }

  onToggleMenu (e): void {

  }

  alertUser () {
    const params = {
      title: 'Alert',
      width: 260,
      height: 150
    }

    const dialog: any = this.kendoModalService.open('dialog', 'alertDialog', AlertDialogComponent, params)
    const selectedCustomerError = dialog.content.instance;
    selectedCustomerError.body = 'Please select a customer.';
    selectedCustomerError.showCancelbtn = false;
  }
}
