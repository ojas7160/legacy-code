import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-secondary-menu',
  templateUrl: './secondary-menu.component.html',
  styleUrls: ['./secondary-menu.component.scss']
})
export class SecondaryMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  openNewConsolidation(): void {
    alert("New Consolidation");
  }

}
