import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CashSavingsComponent } from './cash-savings.component';

describe('CashSavingsComponent', () => {
  let component: CashSavingsComponent;
  let fixture: ComponentFixture<CashSavingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CashSavingsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CashSavingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
