import { Component, OnInit } from '@angular/core'
import { AppConstant } from 'apps/Shared/src/lib/constants/app-constants'
import { Align, ButtonCaption, controlType } from 'apps/Shared/src/lib/enum';
import { IGrid } from 'apps/Shared/src/lib/interface/grid';
import { KendoModalService } from 'apps/Shared/src/lib/services';

@Component({
  selector: 'uc-modal-content',
  templateUrl: './modal-content.component.html',
  styleUrls: ['./modal-content.component.scss']
})
export class ModalContentComponent implements OnInit {
  public rows : IGrid[] = [
    {
      id: 1,
      data: {
        CustomerLookup: 'Purdyest Farms, LLC',
        AdditionalDescription: 'test pri 1',
        LinkedFinancial: 'test linked',
        Ownership: 0,
        EntityValue: '',
        FCSEntityValue: '',
        Value: 5,
        FCSValue: 0,
        Collateral: false,
        YearPurchased: '',
        PurchasePrice: 0,
        Purchasedthis: '',
        SoldSinceLastStatement: '',
        SalesPrice: 0,
        PriorLienAmount: 0,
        PriorLienHolder: '',
        Comment: ''
      },
      isSelected: false
    },
    {
      id: 2,
      data: {
        CustomerLookup: 'Purdy New, LLC',
        AdditionalDescription: 'test pri 2',
        LinkedFinancial: '',
        Ownership: 0,
        EntityValue: '3251',
        FCSEntityValue: '',
        Value: 4,
        FCSValue: 0,
        Collateral: false,
        YearPurchased: '',
        PurchasePrice: 0,
        Purchasedthis: '',
        SoldSinceLastStatement: '',
        SalesPrice: 0,
        PriorLienAmount: 0,
        PriorLienHolder: '',
        Comment: '<div>Hello</div>'
      },
      isSelected: false
    }];

  options = [
    { controlType: controlType.Button, controlName: ButtonCaption.Remove, align: Align.Left, index: 3, class: 'btn btn-primary btn-custom-size3' },
    { controlType: controlType.Button, controlName: ButtonCaption.Percent, align: Align.Left, index: 1, class: 'btn btn-primary btn-custom-size2' },
    { controlType: controlType.Button, controlName: ButtonCaption.Collateral, align: Align.Left, index: 2, class: 'btn btn-primary btn-custom-size5' },
    { controlType: controlType.Button, controlName: ButtonCaption.CopyFromStatement, align: Align.Left, index: 1, class: 'btn btn-primary btn-custom-size5' },
    { controlType: controlType.Button, controlName: ButtonCaption.SaveOrder, align: Align.Left, index: 2, class: 'btn btn-primary btn-custom-size4' },
    { controlType: controlType.Button, controlName: ButtonCaption.ExportGrid, align: Align.Left, index: 1, class: 'btn btn-primary btn-custom-size3' },
    { controlType: controlType.HyperLink, controlName: ButtonCaption.Cancel, align: Align.Right, index: 2, class: '' },
    { controlType: controlType.Button, controlName: ButtonCaption.Save, align: Align.Right, index: 1, class: 'btn btn-primary btn-custom-size3' },
    { controlType: controlType.Button, controlName: ButtonCaption.SaveAndClose, align: Align.Right, index: 2, class: 'btn btn-primary btn-custom-size4' }
  ];

    columns: any = AppConstant.gridColumns.equityInCorporation;
    result: any;

    constructor (private modalService: KendoModalService) { }

    ngOnInit (): void { }

    buttonClicked (buttonName) {
      console.log('button -', buttonName)
    }

    onGridChanged (data) {
      this.result = data;
    }

    updateGridView () {
      this.rows = [
        {
          id: 1,
          data: {
            CustomerLookup: 'Purdyest Farms, LLC',
            AdditionalDescription: 'test pri',
            LinkedFinancial: 'test linked',
            Ownership: '',
            EntityValue: '',
            FCSEntityValue: '',
            Value: '',
            FCSValue: '',
            Collateral: '',
            YearPurchased: '',
            PurchasePrice: '',
            Purchasedthis: '',
            SoldSinceLastStatement: '',
            SalesPrice: '',
            PriorLienAmount: '',
            PriorLienHolder: '',
            Comment: ''
          }
        },
        {
          id: 2,
          data: {
            CustomerLookup: 'Purdy New, LLC',
            AdditionalDescription: 'test pri 2',
            LinkedFinancial: '',
            Ownership: '',
            EntityValue: '',
            FCSEntityValue: '',
            Value: '',
            FCSValue: '',
            Collateral: '',
            YearPurchased: '',
            PurchasePrice: '',
            Purchasedthis: '',
            SoldSinceLastStatement: '',
            SalesPrice: '',
            PriorLienAmount: '',
            PriorLienHolder: '',
            Comment: 'comment 2'
          }
        },
        {
          id: 3,
          data: {
            CustomerLookup: 'Purdy New, Searched',
            AdditionalDescription: 'test pri 3',
            LinkedFinancial: '',
            Ownership: '',
            EntityValue: '',
            FCSEntityValue: '',
            Value: '',
            FCSValue: '',
            Collateral: '',
            YearPurchased: '',
            PurchasePrice: '',
            Purchasedthis: '',
            SoldSinceLastStatement: '',
            SalesPrice: '',
            PriorLienAmount: '',
            PriorLienHolder: '',
            Comment: 'comment 3'
          }
        }];
    }

    selectedColumnData (data) {
      switch (data.fieldName) {
        case 'LinkedFinancial': {
          this.result = data;
          break;
        }
        case 'CustomerLookup': {
          alert(data.value[data.fieldName]);
          this.result = data;
          // this.updateGridView()
          break;
        }
        default : {
          this.result = data;
          break;
        }
      }
    }

    modifyUpdatedData (gridData) {
      const data = gridData.map(item => {
        const isEmpty = Object.values(item).every(x => (x === null || x === ''));
        if (isEmpty) {
          return null
        }
        return item
      }).filter(x => x !== null);
      return data;
    }
}
