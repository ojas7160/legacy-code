import { Component, OnInit } from '@angular/core'
import { WindowService } from '@progress/kendo-angular-dialog'
import { KendoModalService } from '../../../services'
import { ModalContentComponent } from './modal-content/modal-content.component'

@Component({
  selector: 'uc-equity-in-corporation',
  templateUrl: './equity-in-corporation.component.html',
  styleUrls: ['./equity-in-corporation.component.scss']
})
export class EquityInCorporationComponent implements OnInit {
  constructor (private modalService: KendoModalService, private windowService: WindowService) {}

  ngOnInit (): void {}

  openModal () {
    const popUpParams = {
      title: ' Equity',
      draggable: true,
      // minWidth: 400,
      // width: 800,
      // minHeight: 200
      width: 100,
      height: 230
    }
    // this.modalService.open('window', popUpParams, ModalContentComponent)
    this.windowService.open({ ...popUpParams, content: ModalContentComponent });
  }
}
