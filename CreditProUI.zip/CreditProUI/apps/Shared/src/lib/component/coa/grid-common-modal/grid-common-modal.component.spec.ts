import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GridCommonModalComponent } from './grid-common-modal.component';

describe('GridCommonModalComponent', () => {
  let component: GridCommonModalComponent;
  let fixture: ComponentFixture<GridCommonModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GridCommonModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GridCommonModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
