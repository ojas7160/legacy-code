/*This component is used to search the customer as per the input we provide in the textbox

@params: for input before using you need to pass
	@searchHeading: show heading above the search list data
	@currentCustomer: this is an optional and used for show current user/customer 
  details on load if you want to show then pass true else false.
	
	for output or what this will return
	@financialData: emit or return the selected user/customer details

  for example:

	<uc-grid-customer-search [searchHeading]="variable name what you want to display"
	[currentCustomer]="optional parameter which we can pass true or false"
	(financialData)="function name where you want to get the selected customer details">
	</uc-grid-customer-search>
*/

import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ListViewComponent } from '@progress/kendo-angular-listview';
import { environment } from 'apps/CreditPro/src/environments/environment';
import { CustomerSearchResult } from 'apps/Shared/src/lib/models/customer-search-result.model';
import { RestService, SelectedCustomerService } from 'apps/Shared/src/lib/services';

@Component({
  selector: 'uc-grid-customer-search',
  templateUrl: './grid-customer-search.component.html',
  styleUrls: ['./grid-customer-search.component.scss']
})
export class GridCustomerSearchComponent implements OnInit {

  //variable list start which is used in the component to perform a logic as per the requirment
  @ViewChild('listView', { static: false })
  listView: ListViewComponent;
  @Input() searchHeading;
  @Input() currentCustomer?=false;
  @Input() customerHeadingCSS?:any;
  @Output() selectedCustomerData = new EventEmitter();
  @Output() errorDataForSearch = new EventEmitter();
  txtCustomerSearch:any;
  txtForPlaceholder = "Customer Search";
  show = false;
  isLoading = false;
  searchText = '';
  searchList: CustomerSearchResult = {};
  searchFilterList: CustomerSearchResult = {};
  currentUser?:any;
  varSelectedCustomer:any;
  tooltipUserInfo:any;
  //variable list end

  //life cycle hooks start
  constructor(private restService : RestService,private selectedCustomerService:SelectedCustomerService) { }

  ngOnInit(): void {
    //check if current cutomer yes then call appropriate function and display data
    if(this.currentCustomer)
    {
      if (history.state) { 
        this.getCurrentCustomer();
      }
    }
    //end current customer detail
  }

  //life cycle hooks end

  //function list start as per the requirment

  //filter ther data as per user and collect only single data
  private filterCustomerSearchData (dataToFilter: any) {
    dataToFilter.Customers.forEach((customer) => {
      customer.CustomerTasks = [];
      dataToFilter.CustomerTasks.forEach(customerTask => {
        if (customer.CustomerBID === customerTask.CustomerBID) {
          customer.CustomerTasks.push(customerTask);
        }
      });
    });
    return dataToFilter;
  }

  searchClick (): void {
    this.getDataForCustomers('search');
  }

  getDataForCustomers (event: any) {
    if(this.txtCustomerSearch || event === 'current user')
    {
      let paramKeyValue='';
      if(this.txtCustomerSearch)
      {
        paramKeyValue = this.txtCustomerSearch
      }
      else if(event === 'current user' && this.varSelectedCustomer)
      {
        paramKeyValue = this.varSelectedCustomer.customerName;
      }
      else
      {
        return;
      }
      const paramsData: any = {
        searchString: paramKeyValue
      }
      this.searchText = '';
      this.searchFilterList = {};
      this.selectedCustomerData.emit('');
        if (paramKeyValue.trim().length >= 3) {
          this.isLoading = true;
          const apiUrl = environment.baseURI + environment.endpoints.customerSearchListURL;
          this.restService.post(apiUrl, paramsData).subscribe(data => {
            this.errorDataForSearch.emit('');
            this.searchFilterList = this.filterCustomerSearchData(data.CustomerSearchWithTasksResult);
            if(event === 'current user'){
              this.selectedCustomerData.emit(this.searchFilterList.Customers[0]);
            }
            if (this.searchFilterList.Customers.length === 0) {
              this.searchText = 'No results';
            }
            this.isLoading = false;
          });
        } else {
          this.minThreeCharError();
        }
    }
    else
    {
      this.minThreeCharError();
    }
  }

  getSelectedIndex() {
    this.selectedCustomerData.emit(this.searchFilterList.Customers[this.listView.activeIndex]);
  }

  getCurrentCustomer()
  {
    this.selectedCustomerService.getCurrentSelectedCustomer().subscribe(data => {
      if (data !== undefined) {
        this.varSelectedCustomer = data;
        this.getDataForCustomers('current user');
      }
    });
    // this.varSelectedCustomer=JSON.parse(localStorage.getItem('openCustomers')).openCustomers.find(item => item.isSelected === true);
    // this.getDataForCustomers('current user');
  }

  minThreeCharError()
  {
    let param=[{
      key: "Customer Search",
      value:"Min. 3 characters required"
    }];
    this.errorDataForSearch.emit(param);
  }

  onCustomerHover (name: any): void {
    let tooltipData = this.searchFilterList.Customers.filter(item => item.CustomerName.includes(name));
    this.tooltipUserInfo = tooltipData[0];
  }
  //end function list

}
