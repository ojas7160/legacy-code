import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GridCustomerSearchComponent } from './grid-customer-search.component';

describe('GridCustomerSearchComponent', () => {
  let component: GridCustomerSearchComponent;
  let fixture: ComponentFixture<GridCustomerSearchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GridCustomerSearchComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GridCustomerSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
