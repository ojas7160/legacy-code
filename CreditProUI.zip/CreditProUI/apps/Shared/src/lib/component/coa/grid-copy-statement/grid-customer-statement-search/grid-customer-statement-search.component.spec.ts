import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GridCustomerStatementSearchComponent } from './grid-customer-statement-search.component';

describe('GridCustomerStatementSearchComponent', () => {
  let component: GridCustomerStatementSearchComponent;
  let fixture: ComponentFixture<GridCustomerStatementSearchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GridCustomerStatementSearchComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GridCustomerStatementSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
