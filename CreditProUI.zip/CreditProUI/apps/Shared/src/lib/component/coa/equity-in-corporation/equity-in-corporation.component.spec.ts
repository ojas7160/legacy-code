import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EquityInCorporationComponent } from './equity-in-corporation.component';

describe('EquityInCorporationComponent', () => {
  let component: EquityInCorporationComponent;
  let fixture: ComponentFixture<EquityInCorporationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EquityInCorporationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EquityInCorporationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
