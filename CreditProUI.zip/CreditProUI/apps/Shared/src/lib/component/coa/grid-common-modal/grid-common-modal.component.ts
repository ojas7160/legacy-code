import { Component, ElementRef, Input, OnInit, SimpleChange, ViewChild } from '@angular/core';
import { WindowRef } from '@progress/kendo-angular-dialog';
import { GridComponent } from '@progress/kendo-angular-grid';
import { Button } from 'protractor';
import { PercentAdjustComponent } from '../..';
import { AppConstant } from '../../../constants/app-constants';
import { controlType, ButtonCaption, Align } from '../../../enum';
import { IGrid } from '../../../interface/grid';
import { RestService, KendoModalService } from '../../../services';
import { GridButtonService } from '../../../services/common/grid-button.service';
import { SimpleGridComponent } from '../../common/simple-grid/simple-grid.component';
import { GridCustomerStatementSearchComponent } from '../grid-copy-statement/grid-customer-statement-search/grid-customer-statement-search.component';

@Component({
  selector: 'uc-grid-common-modal',
  templateUrl: './grid-common-modal.component.html',
  styleUrls: ['./grid-common-modal.component.scss']
})
export class GridCommonModalComponent extends GridButtonService {
  
  @ViewChild(SimpleGridComponent) simpleGrid;
  gridSelectedIndex:any;
  fileName = "CashSaving.xlsx"

  btnOptions = [
    { controlType: controlType.Button, controlName: ButtonCaption.Remove, align: Align.Left, index: 3, class: 'btn btn-primary btn-custom-size3' },
    { controlType: controlType.Button, controlName: ButtonCaption.Percent, align: Align.Left, index: 1, class: 'btn btn-primary btn-custom-size2' },
    { controlType: controlType.Button, controlName: ButtonCaption.CopyFromStatement, align: Align.Left, index: 1, class: 'btn btn-primary btn-custom-size5' },
    { controlType: controlType.Button, controlName: ButtonCaption.SaveOrder, align: Align.Left, index: 2, class: 'btn btn-primary btn-custom-size4' },
    { controlType: controlType.Button, controlName: ButtonCaption.Export, align: Align.Left, index: 1, class: 'btn btn-primary btn-custom-size3' },
    { controlType: controlType.HyperLink, controlName: ButtonCaption.Cancel, align: Align.Right, index: 2, class: '' },
    { controlType: controlType.Button, controlName: ButtonCaption.Save, align: Align.Right, index: 1, class: 'btn btn-primary btn-custom-size3' },
    { controlType: controlType.Button, controlName: ButtonCaption.SaveAndClose, align: Align.Right, index: 2, class: 'btn btn-primary btn-custom-size4' }
  ];
  //columns: any = AppConstant.gridColumns.equityInCorporation;
  columns: any;
  allData: any;
  body:any;
  public rows : IGrid[] = [
    {
      id: 1,
      data: {
        ItemType: 'Purdyest Farms, LLC',
        Value: 5,
        FCSValue: 0,
        Comment: ''
      },
      isSelected: false
    },
    {
      id: 2,
      data: {
        ItemType: 'Test',
        Value: 50,
        FCSValue: 10,
        Comment: '<p>Hello</p>'
      },
      isSelected: false
    }]
  public equityRows : IGrid[] = [
    {
      id: 1,
      data: {
        CustomerLookup: 'Purdyest Farms, LLC',
        AdditionalDescription: 'test pri 1',
        LinkedFinancial: 'test linked',
        Ownership: 0,
        EntityValue: '',
        FCSEntityValue: '',
        Value: 5,
        FCSValue: 0,
        Collateral: '',
        YearPurchased: '',
        PurchasePrice: 0,
        Purchasedthis: '',
        SoldSinceLastStatement: '',
        SalesPrice: 0,
        PriorLienAmount: 0,
        PriorLienHolder: '',
        Comment: ''
      },
      isSelected: false
    },
    {
      id: 2,
      data: {
        CustomerLookup: 'Purdy New, LLC',
        AdditionalDescription: 'test pri 2',
        LinkedFinancial: '',
        Ownership: 0,
        EntityValue: '3251',
        FCSEntityValue: '',
        Value: 4,
        FCSValue: 0,
        Collateral: '',
        YearPurchased: '',
        PurchasePrice: 0,
        Purchasedthis: '',
        SoldSinceLastStatement: '',
        SalesPrice: 0,
        PriorLienAmount: 0,
        PriorLienHolder: '',
        Comment: '<div>Hello</div>'
      },
      isSelected: false
    }];

    
  constructor(private _restService:RestService,private _kendoModalService:KendoModalService,
    private _windoRef:WindowRef) { 
      super(_restService,_kendoModalService,_windoRef)
  }

  ngOnInit(): void {
    console.log("on init: ", this.simpleGrid);
  }

  ngAfterViewInit()
  {
    console.log("After on init: ", this.simpleGrid.gridData.data);
    console.log("After on init: ", this.simpleGrid.grids);
  }

  /*this method call in our button click and get the name of the button
  and perform an action on the basis of the name*/
  btnClickEvent (event) {
    console.log("event: "+ JSON.stringify(event) + "  count: " + this.btnOptions.length);
    const controlName = event;

    switch (controlName) {
      case ButtonCaption.Cancel:
        this.closeModal();
        break;
      case ButtonCaption.Save:
        console.log("body: ",this.body)
        //this.saveData(this.url,this.body).subscribe(result => {console.log("result: " + JSON.stringify(result));});
        break;
      case ButtonCaption.SaveAndClose:
        //this.saveData(this.url,this.body).subscribe(result => {this.closeModal()});
      break;
      case ButtonCaption.Remove:
        this.removeSelectedRows(this.gridSelectedIndex)
      break;
      case ButtonCaption.Export:
        this.exportToCSV(this.simpleGrid.grids);
      break;
      case ButtonCaption.CopyFromStatement:
        this.openComponent('dialog','alertDialogs','Customer Statement Search',250,'auto',GridCustomerStatementSearchComponent);
      break;
      case ButtonCaption.Percent:
        this.openComponent('dialog','alertDialogs','Percentage','auto','auto',PercentAdjustComponent);
      break;
    }
  }

  onGridDataChanged(data)
  {
    if(data){
      this.allData = this.simpleGrid.gridData.data
      console.log("onGridDataChanged: ", this.simpleGrid.gridData.data);
    }
  }

  selectedColumnData(data)
  {
    if(data){
      console.log("selectedColumnData: ", data);
    }
  }

  selectedIndex(data)
  {
    if(data){
      this.gridSelectedIndex = data.rowIndex;
    }
  }

  
  removeSelectedRows(index) {
    if(index)
    {
      let data = this.simpleGrid.gridData.data;
      //console.log("data: ", data);
      let selectedIdVal = data[index].value.id;
      console.log("selectedIdVal: ",selectedIdVal);
      if(!selectedIdVal)
      {
        data.splice(index,1);
        //console.log("data after remove: ", data);
      }
      else
      {
        this.deleteData('url','body').subscribe(item =>{
          this.getData('url','body').subscribe(result=>{
            this.rows = result;
          })
        })
      }
      this.gridSelectedIndex = null;
    }
    else
    {
      alert("please select any row from the grid");
    }
  }

}

