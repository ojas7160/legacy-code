import { Component } from '@angular/core';
import { environment } from 'apps/CreditPro/src/environments/environment';
import { KendoModalService } from '../../../../services';
import { DialogCloseResult, DialogRef, DialogService, WindowRef } from '@progress/kendo-angular-dialog';
import { UtilityService } from '../../../../services/utility/utility.service';
import { FinancialStatementSubType } from 'apps/Shared/src/lib/enum/financialStatementSubType';

@Component({
  selector: 'uc-grid-customer-statement-search',
  templateUrl: './grid-customer-statement-search.component.html',
  styleUrls: ['./grid-customer-statement-search.component.scss']
})
export class GridCustomerStatementSearchComponent {

  customerHeading='Customer:';
  financialHeading='Financial Statements:';
  selectedCustomer:any;
  selectedFinancialStatement:any;
  openDialog = false;
  dialogBody = 'Do you want to over-write data?';
  currentCustomer = true;
  statementName = 'earning Sheet';
  apiUrl = environment.endpoints.retrieveBalanceSheet;
  apiUrlJsonKey = 'RetrieveBalanceSheetHeadersByCustomerBIDResult';
  financialFilter = [FinancialStatementSubType.BalanceSheet];
  windowRef;
  customerHeadingCSS='font-weight-bold mt-2';
  financialHeadingCSS='font-weight-bold mt-2';
  errorForCustomerSearch:any;

  constructor(private kendoModalService:KendoModalService, private dialogRef: DialogRef,
    private dialogService:DialogService, private utiltyService:UtilityService) { }

  ngOnInit(): void {
    //console.log("id: ", this.id);
  }

  getSelectedCustomerData(event)
  {
    this.selectedCustomer=event;
    this.selectedFinancialStatement = '';
    console.log('getSelectedCustomerData : ' + JSON.stringify(this.selectedCustomer));
  }

  getSelectedFinancialData(event)
  {
    this.selectedFinancialStatement=event;
    console.log('getSelectedFinancialData : ' + JSON.stringify(this.selectedFinancialStatement));
  }

  errorDataForSearch(event)
  {
    this.errorForCustomerSearch = event;
    console.log(this.errorForCustomerSearch);
  }

  openPopup() {
    //this.dialogRef.close();
    this.openAnotherPopup();  
    //this.openDialog=true;
  }

  onDialogClose() {
    // if(data === 'confirm')
    //   this.openDialog = false;
    // //else
      this.dialogRef.close();
  }
  onDeleteData() {
    this.openDialog = false;
  }

  openAnotherPopup()
  {
    // this.openDialog = true
   this.dialogRef.close();
    var dialog = this.dialogService.open({
      title: 'confirm',
      content: 'Do you want to over-write data?',
      actions: [
        { text: 'No' },
        { text: 'Yes'}
      ]
    });

    dialog.result.subscribe((result) => {
      if (result instanceof DialogCloseResult) {
        console.log('close');
      } else {
        console.log('action', result);
        if(result?.text.toLowerCase() == 'yes')
        {
          //return this.selectedFinancialStatement;
        }
        else
        {
          //check for no
          //return this.selectedFinancialStatement='';
        }
      }
    });
  }

}
