import { Component, OnInit, ViewChild } from '@angular/core';
import { WindowRef } from '@progress/kendo-angular-dialog';
import { GridComponent } from '@progress/kendo-angular-grid';
import { AppConstant } from '../../../constants/app-constants';
import { Align, ButtonCaption, controlType } from '../../../enum';
import { IGrid } from '../../../interface/grid';
import { KendoModalService, RestService } from '../../../services';
import { GridButtonService } from '../../../services/common/grid-button.service';
import { SimpleGridComponent } from '../../common/simple-grid/simple-grid.component';
import { PercentAdjustComponent } from '../../consolidations/percentage-adjustment/percent-adjust.component';
import { GridCustomerStatementSearchComponent } from '../grid-copy-statement/grid-customer-statement-search/grid-customer-statement-search.component';

@Component({
  selector: 'uc-cash-savings',
  templateUrl: './cash-savings.component.html',
  styleUrls: ['./cash-savings.component.scss']
})
export class CashSavingsComponent extends GridButtonService implements OnInit {

  /*local variable*/
  @ViewChild(SimpleGridComponent) 
  grid:SimpleGridComponent;
  columns: any = AppConstant.gridColumns.equityInCorporation;
  result: any;
  public rows : IGrid[] = [
    {
      id: 1,
      data: {
        CustomerLookup: 'Purdyest Farms, LLC',
        AdditionalDescription: 'test pri 1',
        LinkedFinancial: 'test linked',
        Ownership: 0,
        EntityValue: '',
        FCSEntityValue: '',
        Value: 5,
        FCSValue: 0,
        Collateral: '',
        YearPurchased: '',
        PurchasePrice: 0,
        Purchasedthis: '',
        SoldSinceLastStatement: '',
        SalesPrice: 0,
        PriorLienAmount: 0,
        PriorLienHolder: '',
        Comment: ''
      },
      isSelected: false
    },
    {
      id: 2,
      data: {
        CustomerLookup: 'Purdy New, LLC',
        AdditionalDescription: 'test pri 2',
        LinkedFinancial: '',
        Ownership: 0,
        EntityValue: '3251',
        FCSEntityValue: '',
        Value: 4,
        FCSValue: 0,
        Collateral: '',
        YearPurchased: '',
        PurchasePrice: 0,
        Purchasedthis: '',
        SoldSinceLastStatement: '',
        SalesPrice: 0,
        PriorLienAmount: 0,
        PriorLienHolder: '',
        Comment: '<div>Hello</div>'
      },
      isSelected: false
    }];
  options = [
    { controlType: controlType.Button, controlName: ButtonCaption.Remove, align: Align.Left, index: 3, class: 'btn btn-primary btn-custom-size3' },
    { controlType: controlType.Button, controlName: ButtonCaption.Percent, align: Align.Left, index: 1, class: 'btn btn-primary btn-custom-size2' },
    { controlType: controlType.Button, controlName: ButtonCaption.Collateral, align: Align.Left, index: 2, class: 'btn btn-primary btn-custom-size5' },
    { controlType: controlType.Button, controlName: ButtonCaption.CopyFromStatement, align: Align.Left, index: 1, class: 'btn btn-primary btn-custom-size5' },
    { controlType: controlType.Button, controlName: ButtonCaption.SaveOrder, align: Align.Left, index: 2, class: 'btn btn-primary btn-custom-size4' },
    { controlType: controlType.Button, controlName: ButtonCaption.ExportGrid, align: Align.Left, index: 1, class: 'btn btn-primary btn-custom-size3' },
    { controlType: controlType.HyperLink, controlName: ButtonCaption.Cancel, align: Align.Right, index: 2, class: '' },
    { controlType: controlType.Button, controlName: ButtonCaption.Save, align: Align.Right, index: 1, class: 'btn btn-primary btn-custom-size3' },
    { controlType: controlType.Button, controlName: ButtonCaption.SaveAndClose, align: Align.Right, index: 2, class: 'btn btn-primary btn-custom-size4' }
  ];

  /* end local variable*/

  constructor(private _restService:RestService,private _kendoModalService:KendoModalService,private _windowRef:WindowRef) {
    super(_restService,_kendoModalService,_windowRef);
  }

  ngOnInit(): void {
    console.log('onint');
  }

  buttonClicked (buttonName) {
    console.log('button -', buttonName)
  }

  onGridChanged (data) {
    this.result = data;
  }

  updateGridView () {
    this.rows = [
      {
        id: 1,
        data: {
          CustomerLookup: 'Purdyest Farms, LLC',
          AdditionalDescription: 'test pri',
          LinkedFinancial: 'test linked',
          Ownership: '',
          EntityValue: '',
          FCSEntityValue: '',
          Value: '',
          FCSValue: '',
          Collateral: '',
          YearPurchased: '',
          PurchasePrice: '',
          Purchasedthis: '',
          SoldSinceLastStatement: '',
          SalesPrice: '',
          PriorLienAmount: '',
          PriorLienHolder: '',
          Comment: ''
        }
      },
      {
        id: 2,
        data: {
          CustomerLookup: 'Purdy New, LLC',
          AdditionalDescription: 'test pri 2',
          LinkedFinancial: '',
          Ownership: '',
          EntityValue: '',
          FCSEntityValue: '',
          Value: '',
          FCSValue: '',
          Collateral: '',
          YearPurchased: '',
          PurchasePrice: '',
          Purchasedthis: '',
          SoldSinceLastStatement: '',
          SalesPrice: '',
          PriorLienAmount: '',
          PriorLienHolder: '',
          Comment: 'comment 2'
        }
      },
      {
        id: 3,
        data: {
          CustomerLookup: 'Purdy New, Searched',
          AdditionalDescription: 'test pri 3',
          LinkedFinancial: '',
          Ownership: '',
          EntityValue: '',
          FCSEntityValue: '',
          Value: '',
          FCSValue: '',
          Collateral: '',
          YearPurchased: '',
          PurchasePrice: '',
          Purchasedthis: '',
          SoldSinceLastStatement: '',
          SalesPrice: '',
          PriorLienAmount: '',
          PriorLienHolder: '',
          Comment: 'comment 3'
        }
      }];
  }

  selectedColumnData (data) {
    switch (data.fieldName) {
      case 'LinkedFinancial': {
        this.result = data;
        break;
      }
      case 'CustomerLookup': {
        alert(data.value[data.fieldName]);
        this.result = data;
        // this.updateGridView()
        break;
      }
      default : {
        this.result = data;
        break;
      }
    }
  }

  modifyUpdatedData (gridData) {
    const data = gridData.map(item => {
      const isEmpty = Object.values(item).every(x => (x === null || x === ''));
      if (isEmpty) {
        return null
      }
      return item
    }).filter(x => x !== null);
    return data;
  }

  // onClick(event)
  // {
  //   this.clickEvent(event)
  // }

    /*this method call in our button click and get the name of the button
  and perform an action on the basis of the name*/
  clickEvent (event) {
    console.log("event: "+ JSON.stringify(event) );
    console.log(this.grid);
    const controlName = event;

    switch (controlName) {
      case 'Cancel':
        this.closeModal();
        break;
      case 'Save':
        //this.restService.post(this.url,this.body).subscribe(result => {console.log("result: " + JSON.stringify(result));});
        break;
      case 'Save & Close':
        //this.restService.post(this.url,this.body).subscribe(result => {this.closeModal()});
      break;
      case 'Remove':
        //this.restService.post(this.url,this.body).subscribe(result => {});
      break;
      case ButtonCaption.ExportGrid:
        //this.exportToCSV(this.grid);
      break;
      case ButtonCaption.CopyFromStatement:
        this.openComponent('dialog','alertDialogs','Customer Statement Search',250,'auto',GridCustomerStatementSearchComponent);
      break;
      case ButtonCaption.Percent:
        this.openComponent('dialog','alertDialogs','Percentage','auto','auto',PercentAdjustComponent);
      break;
    }
  }


}