import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Align, Offset } from '@progress/kendo-angular-popup';
import { RestService } from '../../../services/rest/rest-service.service';
import { environment } from '../../../../../../CreditPro/src/environments/environment';
import { CustomerSearchResult, OpenedCustomer } from '../../../models/customer-search-result.model';
import { SelectedCustomerService } from '../../../services';
import { ActivatedRoute, Router } from '@angular/router';
import { DcCustomer } from '../../../models/customer';
import { select, Store } from '@ngrx/store';
import { userCustomers } from '../../../store/selectors/customer.selector';
import { AppState } from '../../../store';
import { cloneDeep } from 'lodash';
import * as actions from '../../../store/actions'
import { FinancialStatementSubType } from '../../../enum/financialStatementSubType';
import { openCustomersSelector } from '../../../store/selectors/open.customer.selector';
import { AppConstant } from '../../../constants/app-constants';
@Component({
  selector: 'uc-customer-header-popup',
  templateUrl: './customer-header-popup.component.html',
  styleUrls: ['./customer-header-popup.component.scss']
})
export class CustomerHeaderPopupComponent implements OnInit {
  @ViewChild('anchor') public anchor: ElementRef;
  @ViewChild('popup', { read: ElementRef }) public popup: ElementRef;
  public customerData: CustomerSearchResult = {};
  customerHeadersearchList: CustomerSearchResult = {};
  public offset: Offset = { left: 100, top: 250 };
  public popupAlign: Align = { horizontal: 'center', vertical: 'center' };
  openedCustomer: OpenedCustomer
  relatedCustomers: any;
  selectedCustomer: DcCustomer;
  currentCustomerBID: number;
  searchList: CustomerSearchResult = {};
  isLoading = false;
  private openedCustomers: OpenedCustomer[] = [];
  lastTouchUserInfo: any;
  public show = false;
  dateFormat = AppConstant.dateFormat
  timeFormat = AppConstant.timeFormat
  
  constructor (private restService: RestService,
    private _selectedCustomerService: SelectedCustomerService,
    private _router: Router,private store: Store<AppState>,
    private route: ActivatedRoute) {

  }

  ngOnInit (): void {   
    this.openedCustomer = this._selectedCustomerService.getRelatedCustomers()
    this.relatedCustomers = this.openedCustomer.relatedCustomers.RelatedCustomers.map(rc => rc.RelatedCustomerData)  
    this.relatedCustomers = this.filterSearchData(this.openedCustomer.relatedCustomers);
    this.relatedCustomers = this.filterSearchFinalData(this.relatedCustomers.RelatedCustomers);
  }

  initializeFormLoad () {
    const jsonUrl = environment.endpoints.customerHeaderSearchUrl;
    this.restService.get(jsonUrl).subscribe(data => {
      this.customerHeadersearchList = data.RetrieveFavoriteRecentCustomersByUserIDResult;
      this.customerHeadersearchList = this.filterSaerchData(this.customerHeadersearchList);
    });
  }
  private filterSearchData (dataToFilter: any) {
    dataToFilter.RelatedCustomers.forEach((relatedCustomer) => {
      relatedCustomer.CustomerTasks = [];
      dataToFilter.CustomerTasks.forEach(customerTask => {
        if (relatedCustomer.CustomerBID === customerTask.CustomerBID) {
          relatedCustomer.CustomerTasks.push(customerTask);
        }
      });
    });
    return dataToFilter;
  }
  
  recordList:any=[]; 
  private filterSearchFinalData (dataToFilter: any) {   
    dataToFilter.forEach((relatedCustomer) => { 
      let record={
        Address:[],
        CustomerName :'',
        DisplayName:'',
        CustomerTypeCde:0,
        CustomerEID:0,
        BranchID:0,
        CustomerBID:0,
        Phone:[],
        CustomerTasks:[]
        }
         record.Address = relatedCustomer.RelatedCustomerData.Address        
         record.CustomerTasks = relatedCustomer.CustomerTasks
         record.CustomerName=relatedCustomer.RelatedCustomerData.CustomerName;
         record.CustomerName = relatedCustomer.RelatedCustomerData.CustomerName;
         record.DisplayName= relatedCustomer.RelatedCustomerData.DisplayName ;
         record.CustomerTypeCde= relatedCustomer.RelatedCustomerData.CustomerTypeCde;
         record.CustomerEID= relatedCustomer.RelatedCustomerData.CustomerEID;
         record.BranchID= relatedCustomer.RelatedCustomerData.BranchID;
         record.CustomerBID= relatedCustomer.RelatedCustomerData.CustomerBID;
         record.Phone = relatedCustomer.RelatedCustomerData.Phone 
          this.recordList.push(record)
   
    });
    return this.recordList;
  }


  private filterSaerchData (dataToFilter: any) {
    dataToFilter.Customers.forEach((customer) => {
      customer.CustomerTasks = [];
      dataToFilter.CustomerTasks.forEach(customerTask => {
        if (customer.CustomerBID === customerTask.CustomerBID) {
          customer.CustomerTasks.push(customerTask);
        }
      });
    });

    return dataToFilter;
  }

  openSelectedCustomer (customerId, customerName) {
    this._router.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    }
    this._router.onSameUrlNavigation = 'reload';

    this._selectedCustomerService.setCustomerOpenedSelectedInfo(customerId, customerName, true, false, false, {}, null);
    this._router.navigateByUrl(this._router.url, {
      state: {
        selectedCustomerInfo: { CustomerBID: customerId, customerName: customerName },
        isSelected: true,
        isOpened: false
      }
    });
  }
  loadData(){
    this.isLoading = true;
    this.relatedCustomers=[];        
    this.show= true;
    this.store.pipe(select(openCustomersSelector)).subscribe(data => {
      this.openedCustomers = cloneDeep(data.openCustomers)
      this.relatedCustomers = this.openedCustomer.relatedCustomers.RelatedCustomers.map(rc => rc.RelatedCustomerData)     
      this.relatedCustomers = this.filterSearchData(this.openedCustomer.relatedCustomers);
      this.relatedCustomers = this.filterSearchFinalData(this.relatedCustomers.RelatedCustomers);
     
    })   
    setTimeout(() => {
      this.isLoading = false;
    }, 1000);
   
  }
  OpenStatement (dataItem: any) {
    const customerInfo = this.relatedCustomers.find(cu => cu.CustomerBID === dataItem.CustomerBID);
    this._selectedCustomerService.setCustomerOpenedSelectedInfo(customerInfo.CustomerBID, customerInfo.CustomerName, true, true, true, dataItem, dataItem);
    if (dataItem.FinancialStatementSubTypeCde === FinancialStatementSubType.BalanceSheet ||
      dataItem.FinancialStatementSubTypeCde === FinancialStatementSubType.BalanceSheetConsolidation ||
      dataItem.FinancialStatementSubTypeCde === FinancialStatementSubType.BalanceSheetProjection) {
      this.store.dispatch(actions.initialGridDataLoad({ customerId: 123, gridType: 'balancesheet' }))
      this._router.navigateByUrl('balance-sheet', { state: dataItem });
    } else if (dataItem.FinancialStatementSubTypeCde === FinancialStatementSubType.EarningsStatement) { this._router.navigateByUrl('earnings', { state: dataItem }); }
  }
  onFinancialStatementHover (id: any): void {
    const paramsData = {
      financialStatementBID: id
    };
    const apiUrl = environment.baseURI + environment.endpoints.retrieveLastInfo;
    this.restService.post(apiUrl, paramsData).subscribe((data: any) => {
      this.lastTouchUserInfo = data.RetrieveLastChangedInformationByFinanicalStatementBIDResult;
    });
  }
  public onToggle (show?: boolean): void {
    this.show = show !== undefined ? show : !this.show;
  }
}
