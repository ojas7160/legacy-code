import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerHeaderPopupComponent } from './customer-header-popup.component';

describe('CustomerHeaderPopupComponent', () => {
  let component: CustomerHeaderPopupComponent;
  let fixture: ComponentFixture<CustomerHeaderPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerHeaderPopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerHeaderPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
