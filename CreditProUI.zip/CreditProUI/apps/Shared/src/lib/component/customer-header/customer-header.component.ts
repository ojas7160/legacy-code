import { Component, Input, ElementRef, ViewChild, OnInit, OnDestroy } from '@angular/core';
import { AutoCompleteComponent } from '@progress/kendo-angular-dropdowns';
import { of, Observable } from "rxjs";
import { CustomerDetails } from '../../models/customerDetails.model';
import { KendoModalService, SelectedCustomerService } from '../../services';
import { CustomerHeaderPopupComponent } from '../../../lib/component/customer-header/customer-header-popup/customer-header-popup.component';
import { debug } from '../../store';
import { WindowRef } from '@progress/kendo-angular-dialog';
import { OpenedCustomer } from '../../models/customer-search-result.model';




@Component({
  selector: 'lib-customer-header',
  templateUrl: './customer-header.component.html',
  styleUrls: ['./customer-header.component.scss']
})
export class CustomerHeaderComponent implements OnInit, OnDestroy {

  @Input() selectedCustomer: CustomerDetails;
  @Input() refreshSelectedCustomer: boolean;
  @ViewChild("customerHeaderAnchor") public customerHeaderAnchor: ElementRef;
  private popupRef;
  constructor(private kendoModalService: KendoModalService, private _selectedCustomerService: SelectedCustomerService) { }

  ngOnInit(): void {
    // let openedCustomer = this._selectedCustomerService.getCurrentSelectedCustomer();
    // if (openedCustomer != undefined)
    //   this.selectedCustomer = { customerBID: openedCustomer.customerId, customerName: openedCustomer.customerName };
    let openedCustomer: OpenedCustomer;
    this._selectedCustomerService.getCurrentSelectedCustomer().subscribe(data => {
      openedCustomer = data;
    });
  }

  ngOnDestroy(): void {
    if (this.popupRef) {
      this.kendoModalService.close('popup', this.popupRef);
    }
  }


  onClickCustomerEmpower(customerHeaderAnchor: ElementRef, customerBID) {
    let params: any;
    params = {

      anchor: customerHeaderAnchor,
      anchorAlign: {
        horizontal: "right", vertical: "bottom"
      },
      popupAlign: {
        horizontal: 'left',
        vertical: 'top',
        margin: '100px',
        padding: '30px',
        width: '200px',
        height: '300px',
        'max-height': '300px',
        'overflow-y': 'scroll'
      }
    };


    if (this.popupRef) {
      this.kendoModalService.close('popup', this.popupRef);
      this.popupRef=null
    } else {
      this.popupRef = this.kendoModalService.open('popup',
        'customerheaderlist',
        CustomerHeaderPopupComponent,
        params);
       
    }
    // if (this.popupRef) {
    // 	this.kendoModalService.close('popup', this.popupRef);
    // 	this.popupRef = null;
    //   } else{
    // this.popupRef = this.kendoModalService.open('popup','customerheaderlist', CustomerHeaderPopupComponent, {anchor: customerHeaderAnchor,customerid:customerBID})
    // }
  }



}
