import { Component, OnInit } from '@angular/core';
import { aggregateBy } from '@progress/kendo-data-query';
import { products } from '../../../../../CreditPro/src/assets/json/product'

@Component({
  selector: 'lib-adjustment-details',
  templateUrl: './adjustment-details.component.html',
  styleUrls: ['./adjustment-details.component.scss']
})
export class AdjustmentDetailsComponent implements OnInit {

  public aggregates: any[] = [{field: 'UnitPrice', aggregate: 'sum'}];
  public windowTop = 450;
  public windowLeft = 50;
  isShown: boolean = false ; // hidden by default
  public openClose(isOpened: boolean) {
    this.opened = isOpened;
  }


  public gridData: any[] = products;
  public total: any = aggregateBy(products, this.aggregates);
  public dialogOpened = false;
  public windowOpened = false;
  public opened = true;
  public dataSaved = false;
  public closed = true;
   errormsg:any='There are errors on this page.';
  public close() {
    this.opened = false;
  }
  divclose(){
    this.closed = false;
  }
  divangleup(){
    this.isShown = ! this.isShown;
  }
  public open() {
    this.opened = true;
  }

  public submit() {
    this.dataSaved = true;
    this.close();
  }

    constructor(){
  }
  ngOnInit(): void {
    this.gridData;
    console.log(this.gridData);
  }

}
