import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdjustmentDetailsComponent } from './adjustment-details.component';

describe('AdjustmentDetailsComponent', () => {
  let component: AdjustmentDetailsComponent;
  let fixture: ComponentFixture<AdjustmentDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdjustmentDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdjustmentDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
