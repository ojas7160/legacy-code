import { Component, OnInit } from '@angular/core';
import { Align, Offset } from '@progress/kendo-angular-popup';

@Component({
  selector: 'lib-home-information-topic',
  templateUrl: './home-information-topic.component.html',
  styleUrls: ['./home-information-topic.component.scss']
})
export class HomeInformationTopicComponent implements OnInit {
  public offset: Offset = { left: 100, top: 250 };
  public popupAlign: Align = { horizontal: "center", vertical: "center" };

  constructor() { }

  ngOnInit(): void {
  }

 

}
