import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeHelpTopicComponent } from './home-help-topic.component';

describe('HomeHelpTopicComponent', () => {
  let component: HomeHelpTopicComponent;
  let fixture: ComponentFixture<HomeHelpTopicComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HomeHelpTopicComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeHelpTopicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
