import { Component, OnInit } from '@angular/core';
import { Align, Offset } from '@progress/kendo-angular-popup';

@Component({
  selector: 'lib-home-help-topic',
  templateUrl: './home-help-topic.component.html',
  styleUrls: ['./home-help-topic.component.scss']
})
export class HomeHelpTopicComponent implements OnInit {
  public offset: Offset = { left: 100, top: 250 };
  public popupAlign: Align = { horizontal: "center", vertical: "center" };

  // public openedHelp = false;

  // private toggleText = "Show";
  // public show = false;

  constructor() { }

  ngOnInit(): void {
  }
  
  // public toggle(isOpened: boolean) {
  //   this.openedHelp = isOpened;
  // }

  // public onToggle(): void {
  //   this.show = !this.show;
  //   this.toggleText = this.show ? "Hide" : "Show";
  // }

}
