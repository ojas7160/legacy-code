/* eslint-disable dot-notation */
import { Component, OnInit, ElementRef, ViewChild, OnDestroy, ViewChildren, QueryList, ViewEncapsulation } from '@angular/core';
import { Subscription } from 'rxjs';
import { select, Store } from '@ngrx/store';
import { AppState } from '../../store';
import { userCustomers } from '../../store/selectors/customer.selector';
import * as actions from '../../store/actions'
import { CustomerSearchResult, OpenedCustomer } from '../../models/customer-search-result.model';
import { CustomerTasks } from '../../models/customer-tasks.model';
import { cloneDeep } from 'lodash';
import { CustomerDetails } from '../../models/customerDetails.model';
import { HomeHelpTopicComponent } from './home-help-topic/home-help-topic.component';
import { KendoModalService, SelectedCustomerService } from '../../services';
import { HomeInformationTopicComponent } from './home-information-topic/home-information-topic.component';
import { ActivatedRoute, Router } from '@angular/router';
import { FinancialStatementSubType } from '../../enum/financialStatementSubType';
import { TooltipDirective } from '@progress/kendo-angular-tooltip'

// const is = (fileName: string, ext: string) => new RegExp(`.${ext}\$`).test(fileName);

@Component({
  selector: 'lib-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class HomeComponent implements OnInit, OnDestroy {
  @ViewChild('homeHelpTopicAnchor') public homeHelpTopicAnchor: ElementRef;
  @ViewChild('homeInformationAnchor') public homeInformationAnchor: ElementRef;
  // @ViewChildren(TooltipDirective) public tooltipDir: TooltipDirective;
  @ViewChildren(TooltipDirective) public tooltipDir: QueryList<TooltipDirective>;

  private popupRef;
  public selectedCustomerDetails: CustomerDetails = {};
  public data: any[];
  public customerData: CustomerSearchResult = {};
  public customertask: CustomerTasks[] = [];
  searchList: CustomerSearchResult = {};
  searchFilterList: CustomerSearchResult = {};
  public customers: any[];
  public showCustomer: boolean = false;
  public showhelp: boolean = true;
  public showinformation: boolean = true;
  selectedSub: Subscription;

  closeAnchor: any[];

  helpToolTip = 'hover';
  infoToolTip = 'hover';

  constructor (private store: Store<AppState>,
    private kendoModalService: KendoModalService,
    private _router: Router,
    private route: ActivatedRoute,
    private _selectedCustomerService: SelectedCustomerService) { }

  ngOnInit (): void {
    this.store.pipe(select(userCustomers))
      .subscribe(data => {
        this.customerData = cloneDeep(data.customer.RetrieveFavoriteRecentCustomersByUserIDResult);
        if (this.customerData !== undefined) {
          this.customerData.Customers.forEach((customer) => {
            customer.CustomerTasks = [];
            this.customerData.CustomerTasks.forEach(customerTask => {
              if (customer.CustomerBID === customerTask.CustomerBID) {
                customer.CustomerTasks.push(customerTask);
              }
            });
          });
          this.customers = this.customerData.Customers;
          // if (this.customerData.openedCustomers === undefined)
          //   this.customerData.openedCustomers = [];
        }
      });
    this._selectedCustomerService.getCurrentSelectedCustomer().subscribe(data => {
      // if (data !== undefined)
      // let openedCustomer = this._selectedCustomerService.getCurrentSelectedCustomer();
      if (data && data !== null) {
        this.selectedCustomerDetails = { customerBID: data.customerId, customerName: data.customerName };
        this.showCustomer = this.selectedCustomerDetails.customerBID > 0;
      }
    });
  }

  public openSelectedCustomer (customerId, customerName) {
    this._selectedCustomerService.setCustomerOpenedSelectedInfo(customerId, customerName, true, false, false, {}, null);
    this.selectedCustomerDetails = { customerBID: customerId, customerName: customerName };
    this.showCustomer = this.selectedCustomerDetails.customerBID > 0;
  }

  public onClickCustomerEmpower () {

  }

  onClickHomeHelpTopic (homeHelpTopicAnchor: ElementRef) {
    if (this.popupRef) {
      this.kendoModalService.close('popup', this.popupRef);
      this.popupRef = null;
    } else {
      this.popupRef = this.kendoModalService.open('popup', 'homeHelpTopic', HomeHelpTopicComponent, { anchor: homeHelpTopicAnchor })
    }
  }

  onClickHomeInformation (homeInformationAnchor: ElementRef) {
    if (this.popupRef) {
      this.kendoModalService.close('popup', this.popupRef);
      this.popupRef = null;
    } else {
      this.popupRef = this.kendoModalService.open('popup', 'homeInformation', HomeInformationTopicComponent, { anchor: homeInformationAnchor })
    }
  }

  onClickSample () {
    this._router.navigate(['sample'], { relativeTo: this.route });
  }

  OpenStatement (dataItem: any) {
    const customerInfo = this.customerData.Customers.find(cu => cu.CustomerBID === dataItem.CustomerBID);
    this._selectedCustomerService.setCustomerOpenedSelectedInfo(customerInfo.CustomerBID, customerInfo.CustomerName, true, true, true, dataItem, dataItem);
    if (dataItem.FinancialStatementSubTypeCde === FinancialStatementSubType.BalanceSheet ||
      dataItem.FinancialStatementSubTypeCde === FinancialStatementSubType.BalanceSheetConsolidation ||
      dataItem.FinancialStatementSubTypeCde === FinancialStatementSubType.BalanceSheetProjection) {
      this.store.dispatch(actions.initialGridDataLoad({ customerId: 123, gridType: 'balancesheet' }))
      this._router.navigateByUrl('balance-sheet', { state: dataItem });
    } else if (dataItem.FinancialStatementSubTypeCde === FinancialStatementSubType.EarningsStatement) { this._router.navigateByUrl('earnings', { state: dataItem }); }
  }

  // Added to change customer name on click of open from customer
  ngDoCheck (): void {
    // eslint-disable-next-line no-unused-vars
    let openedCustomer: OpenedCustomer;
    this.selectedSub = this._selectedCustomerService.getCurrentSelectedCustomer().subscribe(data => {
      openedCustomer = data;
      if (data !== undefined && data !== null) {
        this.selectedCustomerDetails = { customerBID: data.customerId, customerName: data.customerName };
        this.showCustomer = this.selectedCustomerDetails.customerBID > 0;
      }
    });
  }

  saveSelectedCustomerInStore (selectedCustomer: OpenedCustomer) {
    let openedCustomer;
    if (this.customerData.openedCustomers.length > 0) {
      // eslint-disable-next-line no-unused-vars
      openedCustomer = this.customerData.openedCustomers.find(x => x.selectedCustomerInfo.CustomerBID === selectedCustomer.selectedCustomerInfo.CustomerBID);
      if (selectedCustomer.isSelected === true) {
        this.customerData.openedCustomers.map(x => x.isSelected === false);
      }
      if (selectedCustomer.isOpened === true) {
        this.customerData.openedCustomers.map(x => x.isOpened === false);
      }
    }
  }

  showEnterHelpTooltip (checked) {
    this.helpToolTip = 'none'
    this.showhelp = checked;
  }

  showEnterInfoTooltip (checked) {
    this.infoToolTip = 'none'
    this.showinformation = checked;
  }

  hideHelpToolTip () {
    this.helpToolTip = 'hover';
    this.showhelp = true;
    // this.tooltipDir.toArray()[0].hide();
    // this.tooltipDir.filter((element, index) => index === 0);
    this.tooltipDir.forEach((element) => {
      // eslint-disable-next-line dot-notation
      this.closeAnchor = element['anchor'];
      if (this.closeAnchor['nativeElement'].className === 'help') {
        element.hide();
      }
    });
  }

  hideInfoToolTip () {
    this.infoToolTip = 'hover'
    this.showinformation = true;
    this.tooltipDir.forEach((element) => {
      this.closeAnchor = element['anchor'];
      if (this.closeAnchor['nativeElement'].className === 'info') {
        element.hide();
      }
    });
  }

  ngOnDestroy (): void {
    this.selectedSub && this.selectedSub.unsubscribe();
  }
}
