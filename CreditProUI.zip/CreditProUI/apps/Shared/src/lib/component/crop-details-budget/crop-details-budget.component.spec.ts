import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CropDetailsBudgetComponent } from './crop-details-budget.component';

describe('CropDetailsBudgetComponent', () => {
  let component: CropDetailsBudgetComponent;
  let fixture: ComponentFixture<CropDetailsBudgetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CropDetailsBudgetComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CropDetailsBudgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
