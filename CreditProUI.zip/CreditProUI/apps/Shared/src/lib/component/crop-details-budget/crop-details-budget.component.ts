import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-crop-details-budget',
  templateUrl: './crop-details-budget.component.html',
  styleUrls: ['./crop-details-budget.component.scss']
})
export class CropDetailsBudgetComponent implements OnInit {

  public windowTop = 450;
  public windowLeft = 50;
  isShown: boolean = false ; // hidden by default
  
  public countries: Array<string> = [
    "India"
  ];
  public states: Array<string> = [
    "Uttar Pradesh",
    "Delhi",
    "Maharashtra",
    "Goa",
    "Rajasthan"
  ];
  public dialogOpened = false;
  public windowOpened = false;
  public opened = true;
  public dataSaved = false;
  public closed = true;
   errormsg:any='There are errors on this page.';
   constructor(){
  }
   public openClose(isOpened: boolean) {
    this.opened = isOpened;
  }
  public close() {
    this.opened = false;
  }
  divclose(){
    this.closed = false;
  }
  divangleup(){
    this.isShown = ! this.isShown;
  }
  public open() {
    this.opened = true;
  }

  public submit() {
    this.dataSaved = true;
    this.close();
  }

    
  ngOnInit(): void {
  
  }

}
