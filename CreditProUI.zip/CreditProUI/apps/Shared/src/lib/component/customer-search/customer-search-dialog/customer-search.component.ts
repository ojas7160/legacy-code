import { Component, OnInit } from '@angular/core';
import { KendoModalService } from '../../../services';

@Component({
  selector: 'lib-customer-search',
  templateUrl: './customer-search.component.html',
  styleUrls: ['./customer-search.component.scss']
})
export class CustomerSearchComponent implements OnInit {
  public opened = false;
  customerSearch;
  constructor() { }

  ngOnInit(): void {
    
  }

  public close() {
      this.opened = false;
  }

  public open() {
      this.opened = true;
  }

}
