import { Component, OnInit } from '@angular/core';
import { KendoModalService } from '../../../services';

@Component({
  selector: 'lib-customer-statement-search',
  templateUrl: './customer-statement-search.component.html',
  styleUrls: ['./customer-statement-search.component.scss']
})
export class CustomerStatementSearchComponent implements OnInit {
  public opened = false;
  customersatementSearch;
  constructor() { }

  ngOnInit(): void {
    
  }

  public close() {
      this.opened = false;
  }

  public open() {
      this.opened = true;
  }

}
