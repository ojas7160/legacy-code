import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerStatementSearchComponent } from './customer-statement-search.component';

describe('CustomerStatementSearchComponent', () => {
  let component: CustomerStatementSearchComponent;
  let fixture: ComponentFixture<CustomerStatementSearchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerStatementSearchComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerStatementSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
