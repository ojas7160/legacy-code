import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EarningCopyStatementPopupListComponent } from './earning-copy-statement-popup-list.component';

describe('EarningCopyStatementPopupListComponent', () => {
  let component: EarningCopyStatementPopupListComponent;
  let fixture: ComponentFixture<EarningCopyStatementPopupListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EarningCopyStatementPopupListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EarningCopyStatementPopupListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
