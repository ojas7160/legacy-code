import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-earning-copy-statement-popup-list',
  templateUrl: './earning-copy-statement-popup-list.component.html',
  styleUrls: ['./earning-copy-statement-popup-list.component.scss']
})
export class EarningCopyStatementPopupListComponent implements OnInit {


  @Input() parameters: any[];

  testparameter : string[] = ["aaaa","dddd","ffdfdfdf"];


  constructor() { }

  ngOnInit(): void {
    // alert(this.parameters);
  }

}
