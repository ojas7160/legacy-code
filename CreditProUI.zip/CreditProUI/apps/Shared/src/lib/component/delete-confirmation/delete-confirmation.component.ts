import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ApplicationView } from '../../enum';

@Component({
  selector: 'uc-delete-confirmation',
  templateUrl: './delete-confirmation.component.html',
  styleUrls: ['./delete-confirmation.component.scss']
})
export class DeleteConfirmationComponent {
  @Input() Type
  @Input() IsViewMessage
  @Input() IsViewCancel
  @Output() OnDelete: EventEmitter<any> = new EventEmitter<any>();
  @Output() OnClose: EventEmitter<any> = new EventEmitter<any>();

  constructor() { }
  
  close() {
    if(this.Type == ApplicationView.Reports) {
      this.OnClose.emit()
    }
  }

  delete() {
    if(this.Type == ApplicationView.Reports) {
      this.OnDelete.emit()
    }
  }
   
}
