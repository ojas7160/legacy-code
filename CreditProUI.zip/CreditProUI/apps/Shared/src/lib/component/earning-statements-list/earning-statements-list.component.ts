import { Component, OnInit,Input ,EventEmitter,Output, OnDestroy} from '@angular/core';
import {ShareStatementDataService} from '../../services/earnings/shareStatementDataService'
import { Subject } from 'rxjs';

@Component({
  selector: 'app-earning-statements-list',
  templateUrl: './earning-statements-list.component.html',
  styleUrls: ['./earning-statements-list.component.scss']
})
export class EarningStatementsListComponent implements OnInit,OnDestroy {

  @Input() statementListByCustomerlist : any[];
  earningstatement : any;
  unsubscribe$: Subject<boolean> = new Subject();


  constructor(private dataservice : ShareStatementDataService) { }

  onClickStatement(dataItem)
  {
    this.dataservice.setProfileObs(dataItem);
  }


  ngOnInit(): void {
  }

  ngOnDestroy() {
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }

}
