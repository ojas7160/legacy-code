import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EarningStatementsListComponent } from './earning-statements-list.component';

describe('EarningStatementsListComponent', () => {
  let component: EarningStatementsListComponent;
  let fixture: ComponentFixture<EarningStatementsListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EarningStatementsListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EarningStatementsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
