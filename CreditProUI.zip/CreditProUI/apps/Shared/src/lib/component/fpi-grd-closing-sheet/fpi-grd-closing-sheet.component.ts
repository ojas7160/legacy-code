import { Component, Input, OnInit } from '@angular/core';
import { GridDataResult, PageChangeEvent } from "@progress/kendo-angular-grid";
import { SortDescriptor } from "@progress/kendo-data-query";
import { Observable } from "rxjs";

//Shared Gloab
import { WcfDataService } from "../../services/wcf/wcf-data.service";
//Interface
import { ClosingBalanceSheet } from "../../interface/closing-balance-sheet";

@Component({
  selector: 'lib-fpi-grd-closing-sheet',
  templateUrl: './fpi-grd-closing-sheet.component.html',
  styleUrls: ['./fpi-grd-closing-sheet.component.css']
})
export class FpiGrdClosingSheetComponent implements OnInit {
  public gridClosingBalanceSheet: Observable<ClosingBalanceSheet>;
  public pageSize: number = 10;
  public skip: number = 0;
  public sortDescriptor: SortDescriptor[] = [];
  public filterTerm: number = null;
  public lcaData: any = [];
  //Input Parameter - Template
   @Input() temlateClosingJSONUri: string;

  constructor(
        private wcfstubserv: WcfDataService
  ) { }

  ngOnInit(): void {
    this.initializePageLoad();
  }
  initializePageLoad() {
    this.loadData();
  }
  loadData() {
    this.loadCloseBalanceSheet();
  }
  loadCloseBalanceSheet() {
    const jsonUrl = this.temlateClosingJSONUri;
    this.wcfstubserv.getClosingBalance(jsonUrl).subscribe((data: any) => {
      this.lcaData = data;
      this.gridClosingBalanceSheet = this.lcaData.closingBalanceSheet;
      console.log("gridClosingBalanceSheet", this.gridClosingBalanceSheet);
    });
  }
  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadData();
  }

  public handleSortChange(descriptor: SortDescriptor[]): void {
    this.sortDescriptor = descriptor;
    this.loadData();
  }
}
