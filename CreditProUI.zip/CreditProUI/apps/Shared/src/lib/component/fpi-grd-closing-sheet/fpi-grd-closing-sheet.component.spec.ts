import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpiGrdClosingSheetComponent } from './fpi-grd-closing-sheet.component';

describe('FpiGrdClosingSheetComponent', () => {
  let component: FpiGrdClosingSheetComponent;
  let fixture: ComponentFixture<FpiGrdClosingSheetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FpiGrdClosingSheetComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FpiGrdClosingSheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
