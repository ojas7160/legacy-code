import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GlobalPercentageComponent } from './global-percentage.component';

describe('GlobalPercentageComponent', () => {
  let component: GlobalPercentageComponent;
  let fixture: ComponentFixture<GlobalPercentageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GlobalPercentageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GlobalPercentageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
