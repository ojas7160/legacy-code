import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-global-percentage',
  templateUrl: './global-percentage.component.html',
  styleUrls: ['./global-percentage.component.scss']
})
export class GlobalPercentageComponent implements OnInit {
  public items: any[] = [
    {
        text: 'Percent Eliminations',
        items: [{ text: 'Percent1' }, { text: 'Percent2'}]
    }
];

  constructor() { }

  ngOnInit(): void {
  }

}
