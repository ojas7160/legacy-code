import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerLockInactivityComponent } from './customer-lock-inactivity.component';

describe('CustomerLockInactivityComponent', () => {
  let component: CustomerLockInactivityComponent;
  let fixture: ComponentFixture<CustomerLockInactivityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerLockInactivityComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerLockInactivityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
