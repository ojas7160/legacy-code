import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-customer-lock-inactivity',
  templateUrl: './customer-lock-inactivity.component.html',
  styleUrls: ['./customer-lock-inactivity.component.scss']
})
export class CustomerLockInactivityComponent implements OnInit {

  public opened = false;
  message:any=''
  constructor() { }
  public btnclose(status:any) {
      console.log(`Dialog result: ${status}`);
      this.opened = false;
  }

  public open() {
      this.opened = true;
  }
  public close() {
    this.opened = false;
  }
  ngOnInit(): void {
  } 

}
