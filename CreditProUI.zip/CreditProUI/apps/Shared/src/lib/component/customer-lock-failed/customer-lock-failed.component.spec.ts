import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerLockFailedComponent } from './customer-lock-failed.component';

describe('CustomerLockFailedComponent', () => {
  let component: CustomerLockFailedComponent;
  let fixture: ComponentFixture<CustomerLockFailedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerLockFailedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerLockFailedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
