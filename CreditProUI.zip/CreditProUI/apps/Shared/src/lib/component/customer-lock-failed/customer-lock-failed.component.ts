import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-customer-lock-failed',
  templateUrl: './customer-lock-failed.component.html',
  styleUrls: ['./customer-lock-failed.component.scss']
})
export class CustomerLockFailedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
