import { Component, OnInit } from '@angular/core';
import { TreeItem } from "@progress/kendo-angular-treeview";
import { DropDownTreeComponent } from "@progress/kendo-angular-dropdowns";
import { KendoModalService } from '../../services';

import { WindowRef } from '@progress/kendo-angular-dialog';
import { TreeNode } from '../../models/balanceSheet/TreeNode';
import { BenchmarkService } from '../../services/benchmark/benchmarkDataService';

@Component({
  selector: 'app-conso-new-earnings-links',
  templateUrl: './conso-new-earnings-links.component.html',
    styleUrls: ['./conso-new-earnings-links.component.scss']
})
export class ConsoNewEarningsLinksComponent implements OnInit {

  public earnings3: any;
  public earnings2: any;
  public selectedearnings2: any;
  public selectedearnings3: any;

  public show: boolean = false;
  public selectedBenchmarkData: TreeNode = {
    id: 0,
    desc: '',
    desc2: '',
    data: undefined,
    icon: false,
    iconPath: "",
    iconType: 0,
    children: [],
    nodeLevel: -1,
    parantid: 0,
    parantDesc: '',
    parantDesc2: ''

  };
  constructor(
    private kendoModalService:KendoModalService,
    private benchmarkDataService : BenchmarkService
  ) { }

  ngOnInit(): void {
     this.benchmarkDataService.fetchNewBenchmarkData();
     this.benchmarkDataService.fetchNewConsolidationData();
    this.benchmarkDataService.fetchNewEarningsData();
    this.benchmarkDataService.fetchNewProjectionData();
  }

  public onToggle(): void {
    this.show = !this.show;
  }

}
