import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsoNewEarningsLinksComponent } from './conso-new-earnings-links.component';

describe('ConsoNewEarningsLinksComponent', () => {
  let component: ConsoNewEarningsLinksComponent;
  let fixture: ComponentFixture<ConsoNewEarningsLinksComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsoNewEarningsLinksComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsoNewEarningsLinksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
