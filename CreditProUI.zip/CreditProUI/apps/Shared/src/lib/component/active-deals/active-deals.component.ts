import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-active-deals',
  templateUrl: './active-deals.component.html',
  styleUrls: ['./active-deals.component.scss']
})
export class ActiveDealsComponent implements OnInit {
  
  public dialogOpened = false;
  public windowOpened = false;
  public opened = true;
  public closed = true;
  public windowTop = 450;
  public windowLeft = 50;
  isShown: boolean = false ; // hidden by default
  constructor() { }

  ngOnInit(): void {
  }
  public openClose(isOpened: boolean) {
    this.opened = isOpened;
  }
    public close() {
    this.opened = false;
  }
 
  public open() {
    this.opened = true;
  }

}
