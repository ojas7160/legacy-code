import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolidationStatementComponent } from './consolidation-statement.component';

describe('ConsolidationStatementComponent', () => {
  let component: ConsolidationStatementComponent;
  let fixture: ComponentFixture<ConsolidationStatementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsolidationStatementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsolidationStatementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
