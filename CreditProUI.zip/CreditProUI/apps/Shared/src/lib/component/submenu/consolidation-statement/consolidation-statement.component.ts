import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'uc-consolidation-statement',
  templateUrl: './consolidation-statement.component.html',
  styleUrls: ['./consolidation-statement.component.scss']
})
export class ConsolidationStatementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
