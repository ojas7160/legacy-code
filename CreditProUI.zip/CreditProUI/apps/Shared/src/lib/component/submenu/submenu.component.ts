/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */
import { Component, Input, OnInit, HostListener, TemplateRef, ElementRef, ViewChild, Output, EventEmitter } from '@angular/core';
import { WindowService, DialogService } from '@progress/kendo-angular-dialog';
import { OpenConsolidationComponent } from '../open-consolidation/open-consolidation.component';
import { environment } from '../../../../../CreditPro/src/environments/environment';
import { select, Store } from '@ngrx/store';
import { AppState } from '../../store';
import { AppConstant } from '../../constants/app-constants';
import { ShareStatementDataService } from '../../services/earnings/shareStatementDataService';
import { OpenDeleteConfirmationStatementComponent } from '../open-delete-confirmation-statement/open-delete-confirmation-statement.component';
import { TreeViewModule } from '@progress/kendo-angular-treeview';
import { MenuModule } from '@progress/kendo-angular-menu';
import { KendoModalService, RestService, SelectedCustomerService } from '../../services';
import * as moment from 'moment';
import { MenuItems } from '../../models/menuItem.model';
import { CustomerSearchResult } from '../../models/customer-search-result.model';
import { gridDataSelector } from '../../store/selectors/grid.selector';
import { Router } from '@angular/router';
import { cloneDeep } from 'lodash';
import { ConsolidationStatementCheck } from '../../models/Consolidationstatementcheck.model';
import { TreeNode } from '../../models/balanceSheet/TreeNode';
import { forkJoin, observable, Observable, Subject } from 'rxjs';
import { FinancialStatementSubTypes } from '../../enum/financialStatementSubTypes';
import { OpenProjectedESComponent } from '../earnings/open-projected-es/open-projected-es.component';
import * as balanceSheetAction from '../../store/actions/balanceSheet/balanceSheet.action'
import { loadAllUsersSelector } from '../../store/selectors/balanceSheet/balanceSheet-link-selector';
import * as actions from '../../store/actions'
import { DatePipe } from '@angular/common';
import { ReportExportComponent } from '../uc-reports/report-export/report-export.component'
import { ReportViewPdfComponent } from '../uc-reports/report-view-pdf/report-view-pdf.component';
import { gridDataUpdate } from '../../store/actions';
import { BenchmarkService } from '../../services/benchmark/benchmark.service';
import { Align } from '@progress/kendo-angular-popup';



@Component({
  selector: 'lib-submenu',
  templateUrl: './submenu.component.html',
  styleUrls: ['./submenu.component.scss']
})
export class SubmenuComponent implements OnInit {
  ReportTemplateTreeSource: any[];
  public customerBID = 226363;
  deleteWindowOpened: boolean
  DeleteIsChecked: boolean;
  public selectedKeys: any[] = [];
  changeText: boolean;
  @Input() subMenu = [];
  status: boolean = false;
  customerreportbundle: any
  retrieveReportTemplates: any
  retrieveReportBundle: any
  CBundleBID: number
  position: Align = { horizontal: "left", vertical: "top" };
  anchorPosition: Align = { horizontal: "left", vertical: "bottom" };
  //public balancesheetBenchmarkStatementData:any
  //balancesheetBenchmarkStatementData: any;
  @Input() CustomerReportBundle: any[];
  @Output() performCal: EventEmitter<number> = new EventEmitter();
  @Output() checkedConsolidationStatement = new EventEmitter();
  @Output() selectedWindowOpened = new EventEmitter<number>()
  @Output() NewReport = new EventEmitter()
  @Output() selectedCustomerSearchBundle = new EventEmitter<number>()
  @Output() OpenReportTemplate = new EventEmitter<number>()
  @Output() AddReportTemplateToBundle = new EventEmitter<number>()
  @ViewChild('balanceSheetStatement') balanceSheetStatement: ElementRef;
  @ViewChild('balanceSheetConsolidationStatement') balanceSheetConsolidationStatement: ElementRef;
  @ViewChild('balanceSheetBenchmarkStatement') balanceSheetBenchmarkStatement: ElementRef;
  @ViewChild('balanceSheetConsolidation') balanceSheetConsolidation: ElementRef;
  @ViewChild('balanceSheetProjectedStatement') balanceSheetProjectedStatement: ElementRef;

  @ViewChild('reportTemplate') reportTemplate: ElementRef;

  @ViewChild('projectionsPerAdju') projectionsPerAdju: ElementRef;
  @Input() balanceSheetData: any[];
  columnGroupData: any;
  public percentageValue = 0;
  @ViewChild('earningConsolidationStatement') earningConsolidationStatement: ElementRef;
  @ViewChild('earningProjectedStatement') earningProjectedStatement: ElementRef;
  // @ViewChild('bsConsolidations') balanceSheetConsolidation: ElementRef;
  @ViewChild('newearningProjectedStatement') newearningProjectedStatement: ElementRef;
  @ViewChild('earningBenchmarkStatement') earningBenchmarkStatement: ElementRef
  @ViewChild('earningPrintTrendActions', { static: false, read: TemplateRef }) public earningPrintTrendActions
  date = new Date();
  public showLinkPage = false;
  public showNewPage = false;
  showConsMenu;
  showBalStatement;
  opened;
  openChangesModal;
  isDraggable = true;
  tmpBalanceSheets: any = [];
  windowState = 'default';
  customerpopuplist: any;
  popupRef: any

  columns = AppConstant.secondaryMenu.balanceSheet;
  gdcolumns: any = AppConstant.gridColumns;
  balanceSheets: any[]
  checked: boolean = false;
  consolidatestatememtchecked: ConsolidationStatementCheck = {}
  menuAnchor: any
  selectedSubmenuReport: string
  @Input() ShowDownloadReportStandard: boolean;
  @Input() ShowDownloadReportAlternateWithStatusUpdates: boolean;
  @Input() ShowDownloadReportAlternateParallel: boolean;
  @Input() CanPrintReport: boolean;
  @Output() DownloadSelectedReport = new EventEmitter<string>();
  consolidationdata: any[];
  customerHeadersearchList: any[];
  bSHeaderPriorBSData: any;
  params: any;
  selectedGroup = '';
  groupElements: any;
  onMenuCheck(secondaryMenuName: string): boolean {
    return secondaryMenuName.includes('Create/Print PDF') || secondaryMenuName.includes('View PDF')
  }

  earningBenchmarkStatementData = []
  balancesheetBenchmarkStatementData = []
  tlkpBenchmarkIndustryTemplate: any;
  unsubscribe$: Subject<boolean> = new Subject();
  balancesheetStatementData: any;
  projectedMenuData: any[] = AppConstant.appProjectedMenus;
  windowRef;
  dialogRef;
  public loadingIcon = '';
  public balancesheetConsolidationTreeNode: TreeNode[] = [];
  lastTouchUserInfo: any;
  constructor(private windowService: WindowService, private _selectedCustomerService: SelectedCustomerService,
    private benchMarkService: BenchmarkService,
    private store: Store<AppState>,
    private eRef: ElementRef,
    private restService: RestService,
    private router: Router,
    private kendoModalService: KendoModalService,
    private dataservice: ShareStatementDataService,
    private dialogService: DialogService,
    private datePipe: DatePipe
  ) { }

  public customerID = this._selectedCustomerService.getCurrentSelectedCustomer2();
  @HostListener('document:click', ['$event'])
  public onPageClick(event) {
    // if (!this.eRef.nativeElement.contains(event.target)) {
    //   if (this.popupRef) {
    //     this.kendoModalService.close('popup', this.popupRef)
    //     this.popupRef = null
    //   }
    // }

    if (!this.containsShowColumn(event.target)) {
      this.popupRef && this.kendoModalService.close('popup', this.popupRef)
      this.popupRef = null
      // eslint-disable-next-line no-return-assign
      this.subMenu.forEach(it => it.click = false);
    }
  }

  private containsShowColumn(target: any): boolean {
    return (
      (this.menuAnchor && this.menuAnchor.contains(target)) ||
      (this.popupRef ? this.popupRef.popupElement.contains(target) : false)
    )
  }

  ngOnInit(): void {
    const pageName = this.router.url.includes('balance') ? 'balance' : 'earning'
    this.store.pipe(select(gridDataSelector))
      .subscribe(data => {
        this.balanceSheets = cloneDeep(data.gridData).filter(it => it.type.toLowerCase().includes(pageName))
        // console.log('statement', this.balanceSheets)
      })
    this.consolidationStatement()
  }
  onFinancialStatementHover(id: any): void {
    const paramsData = {
      financialStatementBID: id
    };
    const apiUrl = environment.baseURI + environment.endpoints.retrieveLastInfo;
    this.restService.post(apiUrl, paramsData).subscribe((data: any) => {
      this.lastTouchUserInfo = data.RetrieveLastChangedInformationByFinanicalStatementBIDResult;
    });
  }
  onGroupNameHover(id, item) {
    this.groupElements = item.data.GroupMembers.filter(x => x.GroupBID === id)
  }
  consolidationStatement() {
    this.params = {
      customerBID: this.customerID.customerId,
      includeBS: true,
      includeES: false,
      includeActiveGroupsOnly: true
    }
    this.store.dispatch(balanceSheetAction.consolidationStatement({ params: this.params }))
    this.store.pipe(select(loadAllUsersSelector)).subscribe(val => {
      this.balancesheetStatementData = val.consolidationStatement.RetrieveCustomerConsolidationFinancialStatementHeadersResult
      if (this.balancesheetConsolidationTreeNode.length == 0) {
        this.balancesheetStatementData.forEach(rb => {
          if (rb.FinancialStatements.length > 0) {
            this.balancesheetConsolidationTreeNode.push({
              id: rb.Group.GroupBID,
              desc: rb.Group.GroupNameTxt,
              data: rb.Group,
              nodeLevel: 0,
              children: rb.FinancialStatements.map(x => <TreeNode>{
                data: x,
                id: x.FinancialStatementBID,
                nodeLevel: 1,
                children: [],
                isChecked: false,
                desc3: x.FinancialStatementStartDte,
                desc: x.FinancialStatementEndDte,
                desc2: x.FinancialStatementDesc,
                icon: true,
                iconType: x.FinancialStatementSubTypeCde,
                iconPath: '',
                parantid: rb.Group.GroupBID
              })
            })
          }
        })
      }
    })
  }

  perAdjCalculation() {
    // console.log('balanceSheetData : ',this.balanceSheetData);
    this.performCal.emit(this.percentageValue)
  }


  onDeleteButtonview(ReportBundleBID: number) {
    // this.IsDeleteButtonview = !this.IsDeleteButtonview
    this.DeleteIsChecked = !this.DeleteIsChecked
  }

  onDeletewindowopen(ReportBundleBID: number) {
    this.deleteWindowOpened = true
    this.windowOpen(ReportBundleBID)
    this.DeleteIsChecked = !this.DeleteIsChecked
  }

  windowOpen(ReportBundleBID: number) {
    this.selectedWindowOpened.emit(ReportBundleBID)
  }

  onCustomerBundle(ReportBundleBID: number) {
    this.CustomerBundle(ReportBundleBID)
    this.subMenu.forEach(it => it.click = false);
    this.kendoModalService.close('popup', this.popupRef)
    this.popupRef = null
  }

  CustomerBundle(ReportBundleBID: number) {
    this.selectedCustomerSearchBundle.emit(ReportBundleBID)
  }

  private filterSaerchData(dataToFilter: any) {
    dataToFilter.Customers.forEach((customer) => {
      customer.CustomerTasks = []
      dataToFilter.CustomerTasks.forEach(customerTask => {
        if (customer.CustomerBID === customerTask.CustomerBID) {
          customer.CustomerTasks.push(customerTask)
        }
      })
    })

    return dataToFilter
  }

  onClickDeleteConfirmation() {
    this.windowService.open({
      title: 'Delete Confirmation',
      content: OpenDeleteConfirmationStatementComponent,
      minWidth: 800,
      width: 800,
      minHeight: 275,
      height: 275
    })
  }

  statementCheckboxChanged(e, item) {
    item.hide = !e.target.checked;
    this.store.dispatch(actions.gridDataUpdate({ gridData: [item] }))
  }

  consolidationstatementCheckboxChanged(item) {
    if (item.desc2 && item.id) {
      item = { name: item.desc2, id: item.id, startDate: item.desc, type: AppConstant.typeBalance, hide: !item.hide }
      this.store.dispatch(gridDataUpdate({ gridData: [item] }))
    }
  }

  earningconsolidationstatementCheckboxChanged(item) {
    if (item.desc2 && item.id) {
      item = { name: item.desc2, id: item.id, startDate: item.desc, type: AppConstant.typeEarning, hide: !item.hide }
      this.store.dispatch(gridDataUpdate({ gridData: [item] }))
    }
  }

  onClickBalancesheetNew() {

  }

  OpenBalanceSheetLinkPage() {
    this.showLinkPage = !this.showLinkPage
  }

  OpenBalanceSheetStatment() {
    this.showBalStatement = !this.showBalStatement
  }

  OpenBalanceSheetNewPage() {
    this.showNewPage = !this.showNewPage
  }

  expandToggle() {
    this.showConsMenu = !this.showConsMenu
  }

  openConsolidationModal() {
    this.windowService.open({
      title: 'Open Consolidation',
      content: OpenConsolidationComponent,
      minWidth: 400,
      width: 400,
      minHeight: 400,
      height: 400
    })
  }

  OpenExportWindow() {
    this.windowService.open({
      title: 'Report Viewer',
      content: ReportExportComponent,
      minWidth: 400,
      width: 400,
      minHeight: 400,
      height: 400
    })
  }

  deleteConfirmation(balancesheet) {
    this.dataservice.setProfileObs(balancesheet);

    this.windowService.open({
      title: 'Delete Confirmation',
      content: OpenDeleteConfirmationStatementComponent,
      minWidth: 750,
      width: 750,
      minHeight: 250,
      height: 250
    })
  }

  openSecondaryMenu(column, anchor) {
    // eslint-disable-next-line no-return-assign
    this.subMenu.forEach(it => it.click = false);

    column.click = true; // !column.click

    let content: ElementRef;
    // eslint-disable-next-line no-return-assign
    this.subMenu.forEach(it => it.click = false)

    if (this.onMenuCheck(column.secondaryMenuName)) {
      // eslint-disable-next-line keyword-spacing
      if (this.CanPrintReport) {
        const param = column.secondaryMenuId === 5 ? 'Standard' : column.secondaryMenuId === 6 ? 'AlternateWithStatus' : column.key === 'viewPdf' ? 'viewPdf' : 'AlternateParallel'
        this.DownloadSelectedReport.emit(param)
        return
      } else { return }
    }
    else if (column.secondaryMenuId == '1') {
      this.NewReport.emit();
    }

    column.click = true

    switch (column.key) {
      case 'previewExport':
        this.OpenExportWindow()
        break
      case 'balanceSheetStatement':
        content = this.balanceSheetStatement
        break
      case 'balanceSheetConsolidationStatement':
        content = this.balanceSheetConsolidationStatement
        break
      case 'balanceSheetBenchmarkStatement':
        content = this.balanceSheetBenchmarkStatement
        this.getBenchmarkData(FinancialStatementSubTypes.BalanceSheet)
        break;
      case 'balanceSheetConsolidation':
        content = this.balanceSheetConsolidation
        break
      case 'balanceSheetProjectedStatement':
        content = this.balanceSheetProjectedStatement
        break
      case 'reportTemplate':
        content = this.reportTemplate
        break
      case 'earningStatement':
        // content = '<content element ref for earning statement or any other submenu>'
        break
      case 'projectionsPerAdju':
        content = this.projectionsPerAdju
        break
      case 'earningConsolidationStatement':
        content = this.earningConsolidationStatement
        break;
      case 'earningBenchmarkStatement':
        content = this.earningBenchmarkStatement
        this.getBenchmarkData(FinancialStatementSubTypes.EarningsStatement)

        break;
      case 'earningProjectedStatement':
        content = this.earningProjectedStatement
        break;
      case 'newEarningStatements':
        content = this.newearningProjectedStatement
        break;
      case 'earningPrintTrend':
        this.openEarningPrintTrend(this.earningPrintTrendActions);
        break;
    }

    if (this.popupRef) {
      // eslint-disable-next-line no-return-assign
      this.subMenu.forEach(it => it.click = false);
      this.kendoModalService.close('popup', this.popupRef)
      this.popupRef = null
    } else {
      this.menuAnchor = anchor
      this.popupRef = this.kendoModalService.open('popup', '', content, {
        anchor: anchor,
        // popupClass: column.class,
        popupSettings: `{'popupClass': ${column.class}}`
        // anchorAlign: { horizontal: "right", vertical: "top" },
        // popupAlign: { horizontal: 'left', vertical: 'top' }
      })
    }
  }

  groupBy = function (xs, key) {
    return xs.reduce(function (rv, x) {
      (rv[x[key]] = rv[x[key]] || []).push(x);
      return rv;
    }, {});
  };

  getBenchmarkData(param: number) {
    const benchmarkParam = {
      "selectedFinancialStatementBIDs": [],
      "financialStatementType": param

    };
    this.benchMarkService.fetchBenchmarkData(benchmarkParam).subscribe((data) => {
      if (param === FinancialStatementSubTypes.EarningsStatement)
        this.earningBenchmarkStatementData = data
      else
        this.balancesheetBenchmarkStatementData = data
    });
  }



  LoadBenchmarkNode(tlkpBenchmarkIndustryTemplate: any, data: any, key: string, lastLeafnodes: TreeNode[], ...element): TreeNode[] {
    const benchmarkIndustryTreeNode: TreeNode[] = [];

    for (const e in element) {
      const nodes: TreeNode[] = [];
      data.RetrieveBenchmarkNodesResult.BenchmarkNodes.filter((bn) =>
        bn.BenchmarkGroupBID === element[e].BenchmarkGroupBID).forEach(ele => {
          nodes.push({
            data: ele,
            id: ele.BenchmarkID,
            nodeLevel: 2,
            children: lastLeafnodes.filter(x => x.parantid === ele.BenchmarkID),
            desc: ele.BenchmarkDesc,
            icon: false,
            iconPath: '',
            parantid: ele.BenchmarkGroupBID
          });
        });

      benchmarkIndustryTreeNode.push({
        data: {
          BenchmarkGroupHeader: e,
          BenchmarkNodes: nodes
        },
        id: parseInt(element[e].BenchmarkGroupBID),
        nodeLevel: 1,
        children: nodes,
        desc: element[e].BenchmarkGroupName,
        icon: false,
        iconPath: ''
      });
    }

    return benchmarkIndustryTreeNode;
  }

  restMethodCall(url, paramData): Observable<any> {
    return this.restService.post(url, paramData);
  }

  updateStatements(item) {
    if (item.desc2 && item.id) {
      item = { name: item.desc2, id: item.id, startDate: item.desc, type: 'Earning Benchmark', hide: !item.hide },
        this.store.dispatch(gridDataUpdate({ gridData: [item] }))
    }
  }

  updateBSStatements(item) {
    if (item.desc2 && item.id) {
      item = { name: item.desc2, id: item.id, startDate: item.desc, type: 'BalanceSheet Benchmark', hide: !item.hide },
        this.store.dispatch(gridDataUpdate({ gridData: [item] }))
    }
  }

  // eslint-disable-next-line @angular-eslint/use-lifecycle-interface
  ngOnDestroy() {
    // eslint-disable-next-line no-return-assign
    this.subMenu.forEach(it => it.click = false);
    this.popupRef && this.kendoModalService.close('popup', this.popupRef)
    this.popupRef = null
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }

  openEarningPrintTrend(actionTemplate: TemplateRef<any>) {
    // this.dialogRef=this.kendoModalService.open('dialog', 'openPrintTrend',
    // PrintTrendComponent,{title: "Please confirm",
    //                     actions: actionTemplate,})
    this.dialogRef = this.dialogService.open({
      title: 'Please confirm',
      content: 'Do you want to open or save?',
      actions: actionTemplate
    });
  }

  public close() {
    if (this.dialogRef) {
      this.dialogRef.close();
    }
  }

  public get isLoading(): boolean {
    return this.loadingIcon !== '';
  }

  public savepdf() {
    this.loadingIcon = 'loading';
    this.restService.get(environment.endpoints.earningPrintrend)
      .subscribe((response) => {
        // console.log(response);
        const byteArray = new Uint8Array(atob(response.FileBytes).split('').map(char => char.charCodeAt(0)));
        // return new Blob([byteArray], {type: 'application/pdf'});

        const pdfdate = this.datePipe.transform(this.date, 'yyyyMMdd');
        const pdftime = this.datePipe.transform(this.date, 'HHmmss');
        // var data=response.FileBytes as BlobPart;
        const blob = new Blob([byteArray], { type: 'application/pdf' });
        const objectURL = URL.createObjectURL(blob);
        // console.log('filepath:' + objectURL);
        // window.open(objectURL);
        const asave = document.createElement('a');
        asave.href = objectURL;
        asave.target = '_blank;';
        asave.download = 'QuickPrint_' + pdfdate + '_' + pdftime + '.pdf';
        document.body.appendChild(asave);
        asave.click();
      });
    // Mock async action
    window.setTimeout(() => {
      this.loadingIcon = '';
      this.close();
    }, 3000);
  }

  openpdf() {
    this.loadingIcon = 'loading';
    this.restService.get(environment.endpoints.earningPrintrend)
      .subscribe((response) => {
        console.log(response);
        const byteArray = new Uint8Array(atob(response.FileBytes).split('').map(char => char.charCodeAt(0)));
        // return new Blob([byteArray], {type: 'application/pdf'});

        // var data=response.FileBytes as BlobPart;
        const blob = new Blob([byteArray], { type: 'application/pdf' });
        const objectURL = URL.createObjectURL(blob);
        console.log('filepath :' + objectURL);
        // window.open(objectURL);
        // window.open("file:///c://Users//RAOM//Downloads//QuickPrint_20210722_081726.pdf");
        const a = document.createElement('a');
        a.href = objectURL;
        a.target = '_blank;';
        // a.download='QuickPrint.pdf';
        document.body.appendChild(a);
        a.click();
      },
        err => {
          console.log('error:' + err);
        },
        () => {
          console.log('error1');
        });
    // Mock async action
    window.setTimeout(() => {
      this.loadingIcon = '';
      this.close();
    }, 3000);
  }

  openProjectedES(content) {
    const body = { customerBID: 10110, howMany: 999, includeProjections: true }
    this.restService.post(environment.baseURI + environment.endpoints.baseURLPrefix + environment.endpoints.earningProjectedStatement, body)
      .subscribe(res => {
        console.log(res)
        this.kendoModalService.open('window', '', content, {
          title: 'Projection Selection'
        })
      })
  }
}
