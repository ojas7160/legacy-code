import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeViewPopupComponent } from './change-view-popup.component';

describe('ChangeViewPopupComponent', () => {
  let component: ChangeViewPopupComponent;
  let fixture: ComponentFixture<ChangeViewPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChangeViewPopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeViewPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
