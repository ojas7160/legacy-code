import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-change-view-popup',
  templateUrl: './change-view-popup.component.html',
  styleUrls: ['./change-view-popup.component.scss']
})
export class ChangeViewPopupComponent implements OnInit {
  public toggleText = "Hide";
  show = true;
  columns: string[] = new Array("Indicatiors","Member Value","FCS Value");

  constructor() { }

  ngOnInit(): void {
  }

  public onToggle(): void {
    this.show = !this.show;
    this.toggleText = this.show ? "Hidе" : "Show";
  }
}
