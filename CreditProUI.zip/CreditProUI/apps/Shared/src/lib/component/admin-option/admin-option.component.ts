/* eslint-disable eqeqeq */
/* eslint-disable no-useless-constructor */
import { Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { Store, select } from '@ngrx/store';
import * as fromActions from '../../store/actions';
import * as fromStore from '../../store/reducers/adminOptionsReducer/adminOptions.reducer';
import { loadAllUsersSelector } from '../../store/selectors/admin-options-selector';

import { ListViewComponent } from '@progress/kendo-angular-listview';
import { AlertDialogComponent } from '../alert-dialog/alert-dialog.component';
import { LookupTable, LookupTables } from '../../models/lookupTables';

import { User } from '../../models/User';
import { UserClaim } from '../../models/UserClaim';
import { ClaimDescription } from '../../models/claimDescription';
import { IUser, selectUser } from '../../models/selectedUser';
import { IdentityClaims } from '../../models/IdentityClaims';
import { CustomClaimType, CustomClaimTypeOrder, CustomClaimTypeName, CustomClaimDesc } from '../../enum/CustomClaimType';
import { DTOAction } from '../../enum/DTOAction';
import { environment } from 'apps/CreditPro/src/environments/environment';

import { FormGroup, FormControl, Validators, FormBuilder, FormArray } from '@angular/forms'
import { KendoModalService, RestService } from '../../services';

import { ErrorWindowComponent } from '../error-window/error-window.component';
import { Observable } from 'rxjs';
import { WindowRef } from '@progress/kendo-angular-dialog';

@Component({
  selector: 'lib-admin-option',
  templateUrl: './admin-option.component.html',
  styleUrls: ['./admin-option.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class AdminOptionComponent implements OnInit {
  @ViewChild('listView', { static: false })
  public listView: ListViewComponent;

  @ViewChild('el') el: ElementRef

  adminOptionsForm: FormGroup;

  allUsers: User[] = [];
  selectedUser: User;
  User: IUser;
  claimDescription: ClaimDescription[];
  userClaims: UserClaim[] = [];
  IdentityClaims: IdentityClaims[] = [];
  action: DTOAction;
  errors: any;

  searchedUserIndexes = [];
  userObj: selectUser = <selectUser>{};
  lookupTables: LookupTables;
  lookupTable: LookupTable;
  createNewUserText = 'CREATE NEW USER';

  saveUserURL: string;
  getUserClaimsURL: string;
  userName: string = '';
  currIndex: number;
  filterNewSearchedUsers: boolean;
  disableUserList: boolean;

  expandedKeys = [0, 1];
  selectedKeys = [0, 1];

  public data: any[] = [
    {
      text: 'User Maintenance'
    },
    {
      text: 'Personalization'
    }
  ];

  constructor (private _store: Store<fromStore.AdminOptionsState>, private formBuilder: FormBuilder,
    private restService: RestService, private kendoModalService: KendoModalService, private windowref: WindowRef) {
  }

  ngOnInit (): void {
    this.adminOptionsForm = this.formBuilder.group({
      fullName: ['', Validators.required],
      userLoginExtId: ['', Validators.required],
      email: ['', Validators.required],
      inactivateLogin: false,
      items: this.formBuilder.array([this.formBuilder.group(new UserClaim(0, '', false))])
    });

    this.lookupTable = {
      Action: DTOAction.Nothing,
      UserID: 0,
      TableCde: 110,
      TableName: 'tslkpClaim',
      EmptyOK: false
    }

    this.lookupTables = {
      lookupTables: [this.lookupTable]
    }

    this._store.dispatch(fromActions.getUsers());
    this._store.pipe(select(loadAllUsersSelector)).subscribe(data => {
      this.allUsers = data.GetUsersResult || [];
      // this.allUsers = data.Data || [];
    });

    this.initializeUserClaims();

    if (this.currIndex) {
      this.listView.focus(this.currIndex);
    }
    this.selectedKeys = [];
  }

  initializeUserClaims () {
    this.restService.post(environment.commonBaseURI + environment.endpoints.commonBaseURLPrefix + environment.endpoints.adminOptionsGetUserClaimsURL, this.lookupTables).subscribe(
      (response) => {
        this.claimDescription = response.GetLookupsResult[0].LookupData;
        this.claimDescription.forEach((e, i) => {
          this.userClaims.push(new UserClaim(e.Cde, e.Desc, false));
          this.setfrmCtrlClaimItems(this.userClaims);
        })
      });
  }

  setfrmCtrlClaimItems (uderClaims: any) {
    return this.adminOptionsForm.setControl('items', new FormArray(uderClaims.map(item =>
      new FormGroup({
        claimCde: new FormControl(item.claimCde),
        claimDesc: new FormControl(item.claimDesc),
        claimVal: new FormControl(item.claimVal)
      })
    )));
  }

  currentUser () {
    if (this.currIndex != this.listView.activeIndex && this.adminOptionsForm.dirty) {
      this.currIndex = this.listView.activeIndex;
      this.isCurrentUserSaved(true);
    } else {
      this.currIndex = this.listView.activeIndex;
      this.displayCurrUserDetails(this.listView.activeIndex);
    }
  }

  nextPrevUser (event: Event, user: string) {
    event.preventDefault();
    let index = this.fillSearchedUserIndex(); ;

    // new set of user Search, show first user
    if (this.userName && this.filterNewSearchedUsers) {
      this.displayCurrUserDetails(this.searchedUserIndexes[index]);
      this.filterNewSearchedUsers = false;
    }
    // search on same set of users then move to prev or next user in the list
    else if (this.userName && !this.filterNewSearchedUsers) {
      if (user == 'prev') {
        index = (index == 0) ? this.searchedUserIndexes.length - 1 : (index == -1) ? index : index - 1;
      } else {
        index = (index == this.searchedUserIndexes.length - 1) ? 0 : (index == -1) ? index : index + 1;
      }
      this.displayCurrUserDetails(this.searchedUserIndexes[index]);
    } else {
      this.noUserFound();
    }
  }

  search (directSearch: boolean) {
    if (this.userName) {
      const index = this.fillSearchedUserIndex(directSearch);
      this.displayCurrUserDetails(this.searchedUserIndexes[index]);
    } else {
      this.noUserFound();
    }
  }

  fillSearchedUserIndex (directSearch?: boolean): number {
    let index;
    if (this.filterNewSearchedUsers || directSearch) {
      this.searchedUserIndexes = this.allUsers.reduce((acc, currVal, index) => currVal.UserFullName.indexOf(this.userName) > -1 ? (acc.push(index), acc) : acc, []);
      index = 0;
    } else {
      index = this.searchedUserIndexes.findIndex(x => x == this.listView.activeIndex);
    }
    return index;
  }

  userNameChange (olduserName: string) {
    if (olduserName == undefined || (olduserName != this.userName)) {
      this.filterNewSearchedUsers = true;
    } else {
      this.filterNewSearchedUsers = false;
    }
  }

  displayCurrUserDetails (activeIndex?: number) {
    const currentIndex = activeIndex ?? this.allUsers.findIndex(x => x.UserFullName == this.userName);
    if (currentIndex == 0) {
      // eslint-disable-next-line no-useless-return
      return;
    } else if (currentIndex != -1) {
      this.listView.focus(currentIndex);
      this.selectedUser = this.allUsers[currentIndex];
      this.action = DTOAction.Update;
      // this.clearUserClaims(this.userClaims);
      const userClaims = this.displayCurrUserClaims(this.selectedUser);
      this.setfrmCtrlClaimItems(userClaims);

      this.adminOptionsForm.patchValue({
        fullName: this.selectedUser.UserFullName,
        userLoginExtId: this.selectedUser.UserLoginEID,
        email: this.selectedUser.PrimaryEmailAddr ?? '',
        inactivateLogin: this.selectedUser.InactiveInd ?? false
      });
    } else {
      this.noUserFound();
    }
  }

  changeCheckbox (a:Event) {
    this.allUsers[this.listView.activeIndex].IdentityClaims = this.updateIdentityClaims(this.userClaims);
    this.displayCurrUserClaims(this.allUsers[this.listView.activeIndex]);
  }

  displayCurrUserClaims (selectUser: User) {
    this.clearUserClaims(this.userClaims);
    if (selectUser.IdentityClaims != null) {
      let i = 0;
      const iClaims = selectUser?.IdentityClaims.filter(x => x.Value == 'True');
      const readOnlyClaim = iClaims.find(x => x.Type == CustomClaimTypeName.User_IsReadOnly);
      this.claimDescription.forEach((element, index) => {
        if (readOnlyClaim?.Value == 'True' && this.claimDescription[index].Desc != CustomClaimDesc.UserIsReadOnly &&
          this.claimDescription[index].Desc != CustomClaimDesc.AdminClaimType && this.claimDescription[index].Desc != CustomClaimDesc.MaintainUsers) {
          this.userClaims.push(new UserClaim(this.claimDescription[index].Cde, this.claimDescription[index].Desc, false, false));
        } else if (iClaims[i]?.Type == CustomClaimTypeOrder[index].toString()) {
          this.userClaims.push(new UserClaim(this.claimDescription[index].Cde, this.claimDescription[index].Desc, true));
          i++;
        } else {
          this.userClaims.push(new UserClaim(this.claimDescription[index].Cde, this.claimDescription[index].Desc, false));
        }
      });
    }
    return this.userClaims;
  }

  isCurrentUserSaved (existingUser?: boolean) : Observable<boolean> {
    let responseValue;
    if (this.adminOptionsForm.dirty) {
      const params = {
        title: 'Unsaved Changes to User',
        width: 380,
        height: 160
      }
      const dialog: any = this.kendoModalService.open('dialog', 'alertDialog', AlertDialogComponent, params)
      const dialogBodyContent = dialog.content.instance;
      dialogBodyContent.body = 'There are unsaved changes to this user. Save your changes now?';

      dialog.result.subscribe((response) => {
        responseValue = response == 'ok';
        this.reset(responseValue, existingUser);
      });
    }
    return responseValue;
  }

  createUserObj (action: DTOAction, selectedUserInfo?: User) {
    if (action == DTOAction.Update) {
      this.selectedUser.Action = action;
      return this.selectedUser;
    } else if (action == DTOAction.Insert) {
      this.selectedUser = new User();
      this.selectedUser.UserID = 0;
      this.selectedUser.Action = action;
      this.selectedUser.AdminInd = false;
      this.selectedUser.AlternateUserLoginEID = '';
      this.selectedUser.AssociationID = 0;
      this.selectedUser.BranchID = 0;
      this.selectedUser.PersonalizationAttributeFileName = '';
      return this.selectedUser;
    }
  }

  updateUser () : boolean {
    if (this.action == DTOAction.Insert || this.action == DTOAction.Update) {
      this.selectedUser = Object.assign(this.createUserObj(this.action), {
        UserFullName: this.adminOptionsForm.get('fullName').value,
        UserLoginEID: this.adminOptionsForm.get('userLoginExtId').value,
        PrimaryEmailAddr: this.adminOptionsForm.get('email').value,
        InactiveInd: this.adminOptionsForm.get('inactivateLogin').value
      });
    }

    this.userObj = {
      UserInfo: this.selectedUser,
      UserClaim: this.userClaims
    }
    this.userObj.UserInfo.IdentityClaims = this.updateIdentityClaims(this.userObj.UserClaim);

    // root object sent to api
    this.User = {
      User: this.userObj.UserInfo
    }

    return this.saveUser(this.User);
  }

  updateIdentityClaims (userClaims: UserClaim[]) : IdentityClaims[] {
    // reset Identity Claims to avoid duplicacy
    this.IdentityClaims.length = 0;

    // set UserClaims i.e Identity Claims
    userClaims.forEach((element, index) => {
      this.IdentityClaims.push({
        Issuer: null,
        OriginalIssuer: null,
        Type: CustomClaimType[element.claimCde].toString(),
        Value: element.claimVal ? 'True' : 'False',
        ValueType: null
      });
    });

    return this.IdentityClaims;
  }

  saveUser (user: IUser) : boolean {
    let returnValue;
    this.restService.post(environment.commonBaseURI + environment.endpoints.adminOptionsSaveUserURL, user)
      .subscribe(
        result => {
          this.errors = result;
          if (this.errors?.Errors?.ErrorMessage) {
            this.openErrorWindow(this.errors?.Errors?.ErrorMessage);
            returnValue = false;
          } else {
            returnValue = true;
            this.listView.focus(this.listView.activeIndex);
          }
        },
        _error => {
          returnValue = false;
        }
      );

    return returnValue;
  }

  noUserFound () {
    const params = {
      title: 'No match found!',
      width: 275,
      height: 150
    }
    const dialog: any = this.kendoModalService.open('dialog', 'alertDialog', AlertDialogComponent, params)
    const dialogBodyContent = dialog.content.instance;
    dialogBodyContent.body = `No match found for: %${this.userName}`;
  }

  openErrorWindow (error: any) {
    const params = {
      width: 400
    }
    const dialog: any = this.kendoModalService.open('dialog', 'error', ErrorWindowComponent, params)
    const errorOccured = dialog.content.instance;
    errorOccured.error = error;
  }

  reset (save: boolean, existingUser?: boolean) {
    if (save && existingUser) {
      this.adminOptionsForm.markAsPristine();
      this.updateUser();
      this.displayCurrUserDetails(this.listView.activeIndex);
      return;
    } else if (save && !existingUser) {
      this.updateUser();
      this.userClaims.forEach(element => { element.claimVal = false; });
      this.disableUserList = true;
      this.action = DTOAction.Insert;
    }
    this.adminOptionsForm.markAsPristine();
    this.adminOptionsForm.reset();
    // enabling/resting all checkboxes on cancel button trigger
    this.userClaims.forEach((el) => { el.enableCheckbox = true; })
  }

  cancelUser (event: Event) {
    event.preventDefault();
    this.disableUserList = false;
    // this.windowref.close();
  }

  closeAdminOption () {
    this.windowref.close();
  }

  okClick () {
    if (this.adminOptionsForm.valid) {
      this.updateUser();
    }
    this.windowref.close();
  }

  clearUserClaims (userClaims: UserClaim[]) {
    userClaims.length = 0;
  }
}
