import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'lib-connection-status-signal-r',
  templateUrl: './connection-status-signal-r.component.html',
  styleUrls: ['./connection-status-signal-r.component.scss']
})
export class ConnectionStatusSignalRComponent implements OnInit {

  @Input() opened;
  isDraggable = true;
  windowState = 'default';

  constructor() { }

  ngOnInit(): void {
  }

}
