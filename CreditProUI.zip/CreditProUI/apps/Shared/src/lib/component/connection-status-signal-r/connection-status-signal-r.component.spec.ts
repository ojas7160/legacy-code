import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConnectionStatusSignalRComponent } from './connection-status-signal-r.component';

describe('ConnectionStatusSignalRComponent', () => {
  let component: ConnectionStatusSignalRComponent;
  let fixture: ComponentFixture<ConnectionStatusSignalRComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConnectionStatusSignalRComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConnectionStatusSignalRComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
