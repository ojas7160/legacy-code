import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpiOpeningSheetComponent } from './fpi-opening-sheet.component';

describe('FpiOpeningSheetComponent', () => {
  let component: FpiOpeningSheetComponent;
  let fixture: ComponentFixture<FpiOpeningSheetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FpiOpeningSheetComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FpiOpeningSheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
