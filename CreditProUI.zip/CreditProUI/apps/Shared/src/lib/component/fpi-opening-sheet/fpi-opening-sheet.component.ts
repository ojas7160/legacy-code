import { Component, Input, OnInit } from '@angular/core';
import { GridDataResult, PageChangeEvent } from "@progress/kendo-angular-grid";
import { SortDescriptor } from "@progress/kendo-data-query";
import { Observable } from "rxjs";

//Shared Gloab
import { WcfDataService } from "../../services/wcf/wcf-data.service";
//Interface
import { OpeningBalanceSheet } from "../../interface/opening-balance-sheet";

@Component({
  selector: 'lib-fpi-opening-sheet',
  templateUrl: './fpi-opening-sheet.component.html',
  styleUrls: ['./fpi-opening-sheet.component.css']
})
export class FpiOpeningSheetComponent implements OnInit {

  public gridOpeningBalanceSheet: Observable<OpeningBalanceSheet>;
  public pageSize: number = 10;
  public skip: number = 0;
  public sortDescriptor: SortDescriptor[] = [];
  public filterTerm: number = null;
  public lcaData: any = [];
  //Input Parameter - Template
  @Input() temlateOpeningJSONUri: string;


  constructor(
       private wcfstubserv: WcfDataService
  ) { }

  ngOnInit(): void {
    this.initializePageLoad();
  }
  initializePageLoad() {
    this.loadData();
  }
  loadData() {
    this.loadOpenBalanceSheet();
  }
  loadOpenBalanceSheet() {
    const jsonUrl = this.temlateOpeningJSONUri;
    this.wcfstubserv.getOpeningBalance(jsonUrl).subscribe((data: any) => {
      this.lcaData = data;
      this.gridOpeningBalanceSheet = this.lcaData.openingBalanceSheet;
      console.log("gridClosingBalanceSheet", this.gridOpeningBalanceSheet);
    });
  }

  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadData();
  }

  public handleSortChange(descriptor: SortDescriptor[]): void {
    this.sortDescriptor = descriptor;
    this.loadData();
  }

}
