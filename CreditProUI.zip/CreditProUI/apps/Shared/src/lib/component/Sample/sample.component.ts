/* eslint-disable no-unused-vars */
/* eslint-disable no-tabs */
/* eslint-disable no-mixed-spaces-and-tabs */
import { Component, ElementRef, OnInit, ViewChild, OnDestroy, AfterViewInit } from '@angular/core';
import { DialogCloseResult, DialogService, WindowCloseResult, WindowRef, WindowService } from '@progress/kendo-angular-dialog';
import { AdminOptionComponent } from '../admin-option/admin-option.component';
import { OpenConsolidationComponent } from '../open-consolidation/open-consolidation.component';
import { LoggerService, SignalRService, KendoModalService } from '../../services';
import { CropDetailsBudgetComponent } from '../crop-details-budget/crop-details-budget.component';
import { CustomerLockInactivityComponent } from '../customer-lock-inactivity/customer-lock-inactivity.component';
import { CustomerLockAcquiredComponent } from '../customer-lock-acquired/customer-lock-acquired.component';
import { ConsolidationsNewPopupComponent } from '../consolidations/consolidations-new-popup/consolidations-new-popup.component';
import { ActionsComponent } from '../actions/actions.component';
import { ActiveDealsComponent } from '../active-deals/active-deals.component';
import { AdminCoaRowPropertiesComponent } from '../admin/admin-coa-row-properties/admin-coa-row-properties.component';
import { ConsolidationsNoComponentAlertComponent } from '../consolidations/consolidations-no-component-alert/consolidations-no-component-alert.component';
import { CustomerLockAvailableComponent } from '../customer-lock-available/customer-lock-available.component';
import { CustomerLockFailedComponent } from '../customer-lock-failed/customer-lock-failed.component';
import { DeleteConfirmationComponent } from '../delete-confirmation/delete-confirmation.component';
import { EarningsStatementHeaderComponent } from '../earnings/earnings-statement-header/earnings-statement-header.component';
import { CopyLogicPopupComponent } from '../copy-logic-popup/copy-logic-popup.component';
import { ExportOptionsPopupComponent } from '../export-options-popup/export-options-popup.component';
import { ChangeViewPopupComponent } from '../change-view-popup/change-view-popup.component';
//  import { sampleProducts } from '../assets/json/balancesheet';
import { AppConstant } from '../../constants/app-constants';
import { select, Store } from '@ngrx/store';
import { AppState } from '../../store';
import { gridDataSelector } from '../../store/selectors/grid.selector';

import { ErrorWindowComponent } from '../error-window/error-window.component';
import { AlertDialogComponent } from '../alert-dialog/alert-dialog.component';
import { AdminMenuComponent } from '../admin-menu/admin-menu.component';
import { NewEditBalanceSheetComponent } from '../balancesheet/new-edit-balance-sheet/new-edit-balance-sheet.component';
import { AdjustmentDetailsComponent } from '../adjustment-details/adjustment-details.component';
import { MessageDebugComponent } from '../message-debug/message-debug.component';
import { CustomerStatementSearchComponent } from '../customer-search/customer-statement-search/customer-statement-search.component';
import { CustomerSearchComponent } from '../customer-search/customer-search-dialog/customer-search.component';
import { OpenStatementComponent } from '../open-statements/open-statements.component';
import { StatementSelectionReportComponent } from '../uc-reports/statement-selection-report/statement-selection-report.component';
import { CommentEditor } from '../common/comments-editor/comments-editor.component';
import { ReportOptionsComponent } from '../uc-reports/report-options/report-options.component';
import { ReportListComponent } from '../uc-reports/report-list/report-list.component';
import { ReportBottomGridComponent } from '../uc-reports/report-bottom-grid/report-bottom-grid.component';
import { ExcludeSpecDetailsComponent } from '../uc-reports/exclude-spec-details/exclude-spec-details.component';
import * as gridActions from '../../store/actions/grid.action';
import { cloneDeep } from 'lodash';
import { ModalContentComponent } from '../coa/equity-in-corporation/modal-content/modal-content.component';
import { GridCustomerStatementSearchComponent } from '../coa/grid-copy-statement/grid-customer-statement-search/grid-customer-statement-search.component';
import { CashSavingsComponent } from '../coa/cash-savings/cash-savings.component';
import { GridCommonModalComponent } from '../coa/grid-common-modal/grid-common-modal.component';
// import { WindowService } from '@progress/kendo-angular-dialog';

@Component({
  selector: 'lib-Sample',
  templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.scss']
})
export class SampleComponent implements OnInit, OnDestroy, AfterViewInit {
// public gridData: any[] = sampleProducts;
balanceSheetData: any[];
opened: boolean = false;
customer = { name: '', branch: '', address1: '', type: '', city: '', state: '', country: '', zip: '', ext: '', phone: '' };
public customers: any[];
public showCustomer: boolean = false;
missingData = [];
columns: any = AppConstant.gridColumns;
@ViewChild('copyLogicAnchor') public copyLogicAnchor: ElementRef;
@ViewChild('exportOptionAnchor') public exportOptionAnchor: ElementRef;
@ViewChild('changeViewAnchor') public changeViewAnchor: ElementRef;
@ViewChild(CommentEditor) commentEditor: any;

private popupRef;
balanceSheetMenus = AppConstant.secondaryMenu.balanceSheet
columnGroupData: any;
windowRef: any;

constructor (
	private loggerService: LoggerService,
	private signalRService: SignalRService,
	private store: Store<AppState>,
	private kendoModalService: KendoModalService,
		private windowService: WindowService,
		private eRef: ElementRef,
		private dialogService:DialogService
) {

}

ngOnInit (): void {
	  this.store.dispatch(gridActions.initialGridDataLoad({ customerId: 123, gridType: 'balancesheet' }))

	  this.store.pipe(select(gridDataSelector))
	    .subscribe(data => {
	      this.columnGroupData = cloneDeep(data.gridData).filter(it => it.type.toLowerCase().includes('balance'))
	      this.columns = cloneDeep(data.columnData)
	      this.balanceSheetData = this.transformCoa(cloneDeep(data.coa))
	    })
	  // this.openStatementWindow();
	  /**
		 * commenting signalR configuration until its up and running to use.
		 */

	  // this.signalRService.startConnection();
	  // this.signalRService.dataListener();

	  /**
		 *
		 * code for tunneling the api data after connection to signalR
		 * like hitting the restful service/api for some data.
		 */
}

transformCoa (coa) {
	  return coa.map(it => {
	    this.columns.forEach(column => {
	      column.coas && column.coas.length && column.coas.forEach(columnCoa => {
	        if (it.coaCde === columnCoa.coaCde) {
	          it = Object.assign({}, { ...it, [column.dataBindingName]: columnCoa.value, cellTemplateSelector: columnCoa.cellTemplateSelector })
	        }
	      })
	    })
	    if (it.children && it.children.length) {
	      it.children = this.transformCoa(it.children)
	    }

	    return { ...it }
	  })
}

ngAfterViewInit () {
	  // this.commentEditor.value = "This is passed from parent into child"
}

save () {
	  this.missingData = []
	  for (const c in this.customer) {
	    if (!this.customer[c].length) {
	      this.missingData.push(`${c} is missing here.`)
	    }
	  }
}

openCommentEditor () {
	  const dialog: any = this.kendoModalService.open('dialog', 'commentEditor', CommentEditor);
}

openStatementWindow () {
	  this.windowRef = this.windowService.open({
	    title: 'Open Statements',
	    content: OpenStatementComponent,
	    minWidth: 400,
	    width: 400,
	    minHeight: 400,
	    height: 400
	  })
}

ngOnDestroy () {
	  this.windowRef && this.kendoModalService.close('window', this.windowRef);
	  this.windowRef = null;
}

openErrorWindow () {
	  const dialog: any = this.kendoModalService.open('dialog', 'error', ErrorWindowComponent)
	  const abc = dialog.content.instance;
	  abc.test = 'ojas';
}

openAlertDialog () {
	  const dialog: any = this.kendoModalService.open('dialog', 'alertDialog', AlertDialogComponent)
	  // const dialog: DialogRef = this.dialogService.open()
	  const abc = dialog.content.instance;
	  abc.test = 'ojas';

  //   dialog.result.subscribe((data) => {
  //     if (data instanceof DialogCloseResult) {
  //     }
  //   });
}

openAdminMenu () {
	  // this.dialogService.open()
	  const dialog: any = this.kendoModalService.open('dialog', 'adminMenu', AdminMenuComponent)
}

openCustomerStatementSearch () {
	  const dialog: any = this.kendoModalService.open('dialog', 'customerStatementSearch', CustomerStatementSearchComponent)
}

openCustomerSearch () {
	  const dialog: any = this.kendoModalService.open('dialog', 'customerSearch', CustomerSearchComponent)
}

openCropDetil () {
	  // this.windowService.open()
	  const window: any = this.kendoModalService.open('window', 'cropDetail', CropDetailsBudgetComponent)
}

balanceSheetForm (windowTitleBar) {
	  this.opened = true;
	  const window: any = this.kendoModalService.open('window', 'balanceSheetForm', NewEditBalanceSheetComponent, { titleBarContent: windowTitleBar })
	  window.result.subscribe((result) => {
	    if (result instanceof WindowCloseResult) {
			  this.opened = false;
	    }
		  });
}

openAdminOptions () {
	  const params = {
	    width: 800,
	    height: 600
	  }
	  const window: any = this.kendoModalService.open('window', 'adminOptions', AdminOptionComponent, params)
}

openAdjustmentDetails () {
	  // this.windowService.open({
	  // 	// appendTo: this.containerRef,

	  // })
	  const window: any = this.kendoModalService.open('window', 'adjustmentDetails', AdjustmentDetailsComponent);
}

openStatementSelection () {
	  // this.windowService.open({
	  // 	// appendTo: this.containerRef,

	  // })
	  const window: any = this.kendoModalService.open('window', 'statementSelection', StatementSelectionReportComponent);
}

messageDebug () {
	  // this.windowService.open({
	  // 	// appendTo: this.containerRef,

	  // })
	  const window: any = this.kendoModalService.open('window', 'messageDebug', MessageDebugComponent)
}

cropDetailBudget () {
	  // this.windowService.open({
	  // 	// appendTo: this.containerRef,

	  // })
	  const window: any = this.kendoModalService.open('window', 'cropDetailBudget', CropDetailsBudgetComponent)
}

openCustomerLockInactive () {
	  // this.windowService.open()
	  const window: any = this.kendoModalService.open('window', 'customerLockInactive', CustomerLockInactivityComponent)
}

openCustomerLockAcquired () {
	  // this.windowService.open()
	  const window: any = this.kendoModalService.open('window', 'customerLockAcquired', CustomerLockAcquiredComponent)
}

openNewConsolidationsWindow () {
	  const window: any = this.kendoModalService.open('window', 'newConsolidationWindow', ConsolidationsNewPopupComponent)
}

openConsolidationsWindow () {
	  const window: any = this.kendoModalService.open('window', 'openConsolidations', OpenConsolidationComponent)
}

openActionsWindow () {
	  const window: any = this.kendoModalService.open('window', 'openActionWindow', ActionsComponent)
}

openActiveDealsWindow () {
	  const window: any = this.kendoModalService.open('window', 'activeDeals', ActiveDealsComponent)
}

openCOARowPropertiesWindow () {
	  const window: any = this.kendoModalService.open('window', 'coaRowProps', AdminCoaRowPropertiesComponent)
}

openConsolidationNoComponentAlert () {
	  const window: any = this.kendoModalService.open('window', 'consolidationAlert', ConsolidationsNoComponentAlertComponent)
}

openCustomerLockAvailable () {
	  const window: any = this.kendoModalService.open('window', 'customerLockAvailable', CustomerLockAvailableComponent)
}

openCustomerLockFailed () {
	  const window: any = this.kendoModalService.open('window', 'customerLockFailed', CustomerLockFailedComponent)
}

openDeleteConfirmation () {
	  const window: any = this.kendoModalService.open('window', 'deleteConfirmation', DeleteConfirmationComponent)
}

openEarningsStatementHeader () {
	  const window: any = this.kendoModalService.open('window', 'earningHeader', EarningsStatementHeaderComponent)
}

openCopylogicpopup (copyLogicAnchor: ElementRef) {
	  if (this.popupRef) {
	    this.kendoModalService.close('popup', this.popupRef);
	    this.popupRef = null;
	  } else {
	    this.popupRef = this.kendoModalService.open('popup', 'copyLogicPopup', CopyLogicPopupComponent, { anchor: copyLogicAnchor })
	  }
}

onExportOption (exportOptionAnchor: ElementRef) {
	  if (this.popupRef) {
	    this.kendoModalService.close('popup', this.popupRef);
	    this.popupRef = null;
	  } else {
	    this.popupRef = this.kendoModalService.open('popup', 'exportOptions', ExportOptionsPopupComponent, { anchor: exportOptionAnchor })
	  }
}

onChangeView (changeViewAnchor: ElementRef) {
	  if (this.popupRef) {
	    this.kendoModalService.close('popup', this.popupRef);
	    this.popupRef = null;
	  } else {
	    this.popupRef = this.kendoModalService.open('popup', 'changeView', ChangeViewPopupComponent, { anchor: changeViewAnchor })
	  }
}

openReportOptions () {
	  const window: any = this.kendoModalService.open('window', 'reportOptions', ReportOptionsComponent)
}

reportlist () {
	  const window: any = this.kendoModalService.open('window', 'reportlist', ReportListComponent)
}

excludedetails () {
	  const window: any = this.kendoModalService.open('window', 'excludedetails', ExcludeSpecDetailsComponent)
}

openBottomGrid () {
	  const window: any = this.kendoModalService.open('window', 'bottomGrid', ReportBottomGridComponent)
}

openSimpleGrid () {
	  const popUpParams = {
	    title: ' Equity In Corporation',
	    draggable: true,
	    minHeight: 200,
	    width: 700
		  }
	  const window: WindowRef = this.windowService.open({ ...popUpParams, content: ModalContentComponent })
}

	openCopyStatement ()
	{
		const param = {
			title: 'Copy statement/Customer statement',
			height: 'auto',
			width: 250
		}
		const window: any = this.kendoModalService.open('dialog','alertDialogs' ,GridCustomerStatementSearchComponent,param)
		

		// dialogRef.result.subscribe(result=>{
		// 	console.log("statement data",result);
		// 	if (result instanceof DialogCloseResult) {
		// 		console.log('close');
		// 	  } else {
		// 		console.log('action', result);
		// 	  }
		// });
	}

	openCashSavingGrid () {
		const popUpParams = {
		  title: ' Cash & Saving',
		  draggable: true,
		  minHeight: 200,
		  width: 700
			}
		const window: WindowRef = this.windowService.open({ ...popUpParams, content: GridCommonModalComponent })

		let gridId = window.content.instance;
		gridId.columns = AppConstant.gridColumns.cashSaving;
  }
  openNewEditForm()
  {	
	  const popUpParams = {
		title: ' Form New Edit',
		draggable: true,
		minHeight: 200,
		width: 700
		}
		const window: WindowRef = this.windowService.open({ ...popUpParams, content: 'FormEarningProjectionComponent' })

		let gridId = window.content.instance;
		gridId.columns = AppConstant.gridColumns.cashSaving;
	}
}
