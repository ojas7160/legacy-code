import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-message-debug',
  templateUrl: './message-debug.component.html',
  styleUrls: ['./message-debug.component.scss']
})
export class MessageDebugComponent implements OnInit {

  public opened = false;
  isDisabledContent = false;

  debugMessagesList = [{ "Id": "1", "Name": "Ujjaval", "Email": "ujjaval@gmail.com" }]
  constructor() { }


  //Enable & disable data on the basis of enable button
  enableButton(evt: any) {
    
    if (evt.target.checked == true) {
      this.isDisabledContent = true;
    }
    else {
      this.isDisabledContent = false;
    }
  }
  
  //Clear the data on the clear button
  clearButton() {
    this.isDisabledContent = false;
  }

  // Do not initially show the Window
  public close() {
    this.opened = false;
  }
  public open() {
    this.opened = true;
  }
  ngOnInit(): void {
  }

}
