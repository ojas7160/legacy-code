import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MessageDebugComponent } from './message-debug.component';

describe('MessageDebugComponent', () => {
  let component: MessageDebugComponent;
  let fixture: ComponentFixture<MessageDebugComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MessageDebugComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MessageDebugComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
