import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-admin-menu',
  templateUrl: './admin-menu.component.html',
  styleUrls: ['./admin-menu.component.scss']
})
export class AdminMenuComponent implements OnInit {
  public dialogOpened = false;

  constructor() { }

  ngOnInit(): void {
  }

  public close() {
    this.dialogOpened = false;
  }

  public open() {
    this.dialogOpened = true;
  }

  public action() {
    this.dialogOpened = false;
  }

  public listItems: Array<string> = [
    "",
    "Baseball",
    "Basketball",
    "Cricket",
    "Field Hockey",
    "Football",
    "Table Tennis",
    "Tennis",
    "Volleyball",
  ];

}
