import { Component, OnInit, HostListener, ElementRef, Input, SimpleChanges, } from '@angular/core'
import { select, Store } from '@ngrx/store'
import { AppState } from '../../store'
// import { gridDataLoad, openStatements, updateGridDataSuccess } from '../../store/actions';
import * as openStatementAction from '../../store/actions'
import { KendoModalService } from '../../services/kendo-modal/kendo-modal.service'
import { WindowRef } from '@progress/kendo-angular-dialog'
import { RestService } from '../../services'
import { AppConstant } from '../../constants/app-constants'
import { environment } from '../../../../../CreditPro/src/environments/environment'
import { consolidationData } from '../../models/consolidationData'
import { OpenBalancesheet } from '../../models/openBalancesheet'
import { Router } from '@angular/router'
import { forkJoin, Observable, Subject } from 'rxjs'
import { TreeNode } from '../../models/balanceSheet/TreeNode'
import { FinancialStatementSubTypes } from '../../enum/financialStatementSubTypes'
import { TreeItem } from '@progress/kendo-angular-treeview'
import { openStatementSelector } from '../../store/selectors/balanceSheet/openStatement-selector'

@Component({
  selector: 'lib-open-statement',
  templateUrl: './open-statements.component.html',
  styleUrls: ['./open-statements.component.scss']
})
export class OpenStatementComponent implements OnInit {
  public opened = false;
  selectedAll: any;
  checkedStatement = [];
  balanceSheets;
  model: any = {};
  tmpBalanceSheets: any = [];
  response: any = [];
  public selected: boolean = true;
  public selectedText: String = 'Select All'
  consolidationDataView: consolidationData[];
  openBalancesheet: OpenBalancesheet[];
  openStatementData: any;
  openBalanceSheetIteam: any;
  parameterList: any[];
  tabTtitle:any;
  /*Added by Maninder Kalra*/
  selectAllCustomer: any;
  customerEmitData: any;

  public dialogOpened = false;

  public consolidationTreeNode: TreeNode[] = [];
  public batchMode = false;
  public checkedKeys: string[] = [];
  dataItem: any = [];

  public isChecked: boolean;

  selectedBenchmarkData: any;
  public selectedKeys: any[] = [];
  public tlkpBenchmarkIndustryTemplate: any[];
  public show: boolean = false;
  public expandedNodes: number[] = [];
  public expandedKeys: any[] = [];
  public benchmarkTreeNodes: TreeNode[] = [];
  inputType = 'checkbox';
  customerIDValue: any;
  data$ = this.store.pipe(select(openStatementSelector));

  @Input() windowRef: any;

  constructor (private store: Store<AppState>, private eRef: ElementRef,
    private kendoModalService: KendoModalService, private window: WindowRef,
    private restService: RestService, private _router: Router
  ) { }

  public close () {
    this.window.close()
  }

  public open () {
    this.opened = true
  }

  public onTabSelect (e) {
    this.tabTtitle = e.title
    if(this.tabTtitle.includes('Customer'))
    {

    }
    else if (this.tabTtitle.includes('Consolidation') && this.consolidationTreeNode.length === 0) {
      this.getConsolidation();
    }
  }

  public selectAll (checked: boolean) {
    if(this.tabTtitle === undefined || this.tabTtitle.includes('Customer'))
    {
      this.selectAllCustomer = checked;
      //console.log("tes: " + this.selectAllCustomer);
    }
    else if (this.tabTtitle.includes('Consolidation') && this.consolidationTreeNode.length > 0) {
      console.log("consol: ", JSON.stringify(this.consolidationTreeNode));
      this.consolidationTreeNode.filter(x => x.children.forEach(e => {
        e.isChecked = checked
      }))
    }
  }

  //need to ask why we are using this?
  public get cCount (): number {
    let count: number = 0
    this.consolidationTreeNode.map(x => x.children.filter(y => {
      if (y.isChecked)
        count++
    }))
    return count
  }

  public clickOk () {
    var ct = []
    this.consolidationTreeNode.filter(x => x.children.filter(y => {
      if (y.isChecked)
        ct.push(y)
    }))

    var gt = []
    this.benchmarkRecursiveData(this.benchmarkTreeNodes, gt)
    console.log('ctttt', ct)
    console.log('Gttt', gt)
  }

  benchmarkRecursiveData (dataItem: any, gt: any): boolean {
    if (dataItem && dataItem.length > 0) {
      dataItem.forEach(element => {
        if (this.benchmarkRecursiveData(element.children, gt))
          if (element.isChecked)
            gt.push(element)
      })
    } else
      return true
    return false
  }

  onConsolidationChange (param, dataItem: any) {
    dataItem.isChecked = param.target.checked
    // console.log('changed', param.target.checked)
    // console.log('data', dataItem)
  }

  onBechmarkChange (datanew, dataItem: any) {
    dataItem.isChecked = datanew.target.checked
    // console.log('AgainChanged', dataItem)
    // console.log('changed', datanew.target.checked)
  }

  ngOnInit (): void {
    //get customer data then get consolidation and then benchmark
    this.getCurrentCustomer();
    this.store.dispatch(openStatementAction.openStatementData());
    this.getBenchmarkData();
  }

  /*Aded by Maninder Kalra*/ 
  getCurrentCustomer()
  {
    var selectedCustomer = JSON.parse(localStorage.getItem('openCustomers')).openCustomers.find(item => item.isSelected === true)
    this.customerIDValue = selectedCustomer.customerId
  }
  /* end by Maninder Kalra*/

  getConsolidation () {
    console.log('this.consolidationTreeNode XXXXXX : ', this.data$);
    this.data$.subscribe(val => {
      //this.openStatementData = val.openStatementData
      val.openStatementData.forEach(rb => {
        if (rb.FinancialStatements && rb.FinancialStatements.length > 0) {
          this.consolidationTreeNode.push({
            id: rb.Group.GroupBID,
            desc: rb.Group.GroupNameTxt,
            data: rb.Group,
            nodeLevel: 0,
            children: rb.FinancialStatements.map(x => <TreeNode>{
              data: x,
              id: x.FinancialStatementBID,
              nodeLevel: 1,
              children: [],
              isChecked: false,
              desc: x.FinancialStatementEndDte,
              desc2: x.FinancialStatementDesc,
              icon: true,
              iconType: x.FinancialStatementSubTypeCde,
              iconPath: '',
              parantid: rb.Group.GroupBID
            })
          })
        }
      })
    })

    //console.log('YYY')
  }

  groupBy = function (xs, key) {
    return xs.reduce(function (rv, x) {
      (rv[x[key]] = rv[x[key]] || []).push(x)
      return rv
    }, {})
  };

  //hardcode static value just provide dynamic value
  getBenchmarkData () {
    let paramsData: any = {
      lookupTables: [
        {
          TableCde: 103,
          TableName: 'tlkpBenchmarkIndustryTemplate',
          EmptyOK: true
        }]
    }
    const lookupData: Observable<any> = this.restService.post(environment.commonBaseURI + AppConstant.endpoints.getLookups, paramsData)

    paramsData =
      { selectedFinancialStatementBIDs: [] }
    const benchmarkData: Observable<any> = this.restService.post(environment.baseURI + AppConstant.endpoints.retrieveBenchmarkNodes, paramsData)

    forkJoin([lookupData, benchmarkData]).subscribe((data: any[]) => {
      this.tlkpBenchmarkIndustryTemplate = data[0].GetLookupsResult
      const groubedByBenchmarkIndustryTemplateCde = this.groupBy(data[1].RetrieveBenchmarkNodesResult.BenchmarkGroupNodes, 'BenchmarkIndustryTemplateCde')

      paramsData = {
        benchmarkIDs: data[1].RetrieveBenchmarkNodesResult.BenchmarkNodes.map(val => val.BenchmarkID),
        financialStatementType: FinancialStatementSubTypes.BalanceSheet,
        Error: []
      }
      let lastLeafnodes: TreeNode[] = []
      const benchmarkLastLeafNodeData = this.restService.post(environment.baseURI + AppConstant.endpoints.retrieveBenchmarkStatementNodesAll, paramsData).subscribe((e: any) => {
        const fhsCollections = e.RetrieveBenchmarkStatementNodesAllResult.flatMap((elem) => elem.FinancialSheetHeaders)

        lastLeafnodes = fhsCollections.map(leafchild => <TreeNode>{
          data: leafchild,
          id: leafchild.FinancialStatementBID,
          nodeLevel: 3,
          children: [],
          desc: leafchild.FinancialStatementEndDte,
          desc2: leafchild.FinancialStatementDesc,
          icon: true,
          iconType: leafchild.FinancialStatementSubTypeCde,
          iconPath: '',
          parantid: leafchild.DefaultBenchmarkID
        })

        this.benchmarkTreeNodes = []

        for (const key in groubedByBenchmarkIndustryTemplateCde) {
          const industryTemplate = this.tlkpBenchmarkIndustryTemplate[0].LookupData.find((x) => parseInt(x.Cde) === parseInt(key))
          const industryTemplatesData = this.LoadBenchmarkNode(data[1], lastLeafnodes, ...groubedByBenchmarkIndustryTemplateCde[key])
          this.benchmarkTreeNodes.push({
            data: industryTemplate,
            id: parseInt(industryTemplate.Cde),
            nodeLevel: 0,
            children: industryTemplatesData,
            desc: industryTemplate.Desc,
            icon: false,
            iconPath: '',
            parantid: 0
          })
        }

        benchmarkLastLeafNodeData.unsubscribe()
        this.benchmarkTreeNodes.sort((a, b) => a.desc < b.desc ? -1 : a.desc > b.desc ? 1 : 0)
      })
    })
  }

  public handleCollapse (args: TreeItem): void {
    this.expandedNodes = this.expandedNodes.filter(
      (id) => id !== args.dataItem.id
    )
  }

  public isNodeExpanded = (node: any): boolean => {
    return this.expandedNodes.indexOf(node.id) !== -1
  };

  public handleExpand (args: any): void {
    this.expandedNodes = this.expandedNodes.concat(args.dataItem.id)
  }

  public handleSelection ({ index }: any): void {
    const selectedIndex = String(index).split('_')
    if (selectedIndex.length === 4) {
      this.selectedBenchmarkData = this.benchmarkTreeNodes[selectedIndex[0]].children[selectedIndex[1]].children[selectedIndex[2]].children[selectedIndex[3]]
      this.selectedBenchmarkData.parantDesc = this.benchmarkTreeNodes[selectedIndex[0]].desc
      this.selectedBenchmarkData.parantDesc2 = this.benchmarkTreeNodes[selectedIndex[1]].desc
      // this.show = !this.show
    } else {
      this.selectedBenchmarkData = {
        id: 0,
        desc: '',
        desc2: '',
        data: undefined,
        icon: false,
        iconPath: '',
        iconType: 0,
        children: [],
        nodeLevel: -1,
        parantid: 0,
        parantDesc: '',
        parantDesc2: ''
      }
    }
  }

  LoadBenchmarkNode (data: any, lastLeafnodes: TreeNode[], ...element): TreeNode[] {
    const benchmarkIndustryTreeNode: TreeNode[] = []
    for (const e in element) {
      const nodes: TreeNode[] = []
      data.RetrieveBenchmarkNodesResult.BenchmarkNodes.filter((bn) =>
        bn.BenchmarkGroupBID === element[e].BenchmarkGroupBID).forEach(ele => {
        nodes.push({
          data: ele,
          id: ele.BenchmarkID,
          nodeLevel: 2,
          children: lastLeafnodes.filter(x => x.parantid === ele.BenchmarkID),
          desc: ele.BenchmarkDesc,
          icon: false,
          iconPath: '',
          parantid: ele.BenchmarkGroupBID
        })
      })

      benchmarkIndustryTreeNode.push({
        data: {
          BenchmarkGroupHeader: e,
          BenchmarkNodes: nodes
        },
        id: parseInt(element[e].BenchmarkGroupBID),
        nodeLevel: 1,
        children: nodes,
        desc: element[e].BenchmarkGroupName,
        icon: false,
        iconPath: ''
      })
    }

    return benchmarkIndustryTreeNode
  }

  getCustomerChangeValue(event)
  {
    this.customerEmitData = event;
    //console.log("count ",this.customerEmitData?.length)
  }

}
