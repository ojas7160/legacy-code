import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OpenStatementComponent } from './open-statements.component';

describe('OpenConsolidationComponent', () => {
  let component: OpenStatementComponent;
  let fixture: ComponentFixture<OpenStatementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OpenStatementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OpenStatementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
