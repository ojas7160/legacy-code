import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OpenConsolidationComponent } from './open-consolidation.component';

describe('OpenConsolidationComponent', () => {
  let component: OpenConsolidationComponent;
  let fixture: ComponentFixture<OpenConsolidationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OpenConsolidationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OpenConsolidationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
