import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-open-consolidation',
  templateUrl: './open-consolidation.component.html',
  styleUrls: ['./open-consolidation.component.scss']
})
export class OpenConsolidationComponent implements OnInit {
  
  public opened = false;
  constructor() { }

  public close() {
    this.opened = false;
  }

  public open() {
    this.opened = true;
  }

  ngOnInit(): void {
  }

}
