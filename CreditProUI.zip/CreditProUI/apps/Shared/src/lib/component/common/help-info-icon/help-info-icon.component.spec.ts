import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HelpInfoIconComponent } from './help-info-icon.component';

describe('HelpInfoIconComponent', () => {
  let component: HelpInfoIconComponent;
  let fixture: ComponentFixture<HelpInfoIconComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HelpInfoIconComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HelpInfoIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
