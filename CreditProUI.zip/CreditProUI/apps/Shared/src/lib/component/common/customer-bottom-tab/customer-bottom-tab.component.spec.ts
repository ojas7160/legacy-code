import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerBottomTabComponent } from './customer-bottom-tab.component';

describe('CustomerBottomTabComponent', () => {
  let component: CustomerBottomTabComponent;
  let fixture: ComponentFixture<CustomerBottomTabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerBottomTabComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerBottomTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
