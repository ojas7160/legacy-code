/*This component is used to show financial statement of the customer*/

import { Component, Input, Output, ViewChild,EventEmitter, OnChanges, ViewEncapsulation } from '@angular/core';
import { ListViewComponent } from '@progress/kendo-angular-listview';
import { environment } from 'apps/CreditPro/src/environments/environment';
import { AppConstant } from '../../../constants/app-constants';
import { RestService } from '../../../services';

@Component({
  selector: 'uc-customer-financial-statement',
  templateUrl: './customer-financial-statement.component.html',
  styleUrls: ['./customer-financial-statement.component.scss'],
  encapsulation: ViewEncapsulation.None 
})
export class CustomerFinancialStatementComponent implements OnChanges {
  
  //variable list
  //@Input() customerId?:any;
  @Input() financialList;
  @Input() statement;
  @Input() financialHeading;
  @Input() apiUrl;
  @Input() apiUrlJsonKey;
  @Input() imgSrc;
  @Input() financialHeadingCSS?:any;
  @Input() financialFilter?:any;
  @Input() isActiveStartDate;
  @Input() isActiveEndDate?: boolean = false;
  @Input() financialNoStatementHeading?: any = 'No Financials'
  @Output() selectedFinancialData= new EventEmitter();
  @ViewChild('listView',{static:false})
  financialListView:ListViewComponent;
  lastTouchUserInfo:any;
  dateFormat = AppConstant.dateFormat
  //end variable list

  //life cycle hook
  constructor(private restService:RestService) { }

  // ngOnInit(): void {
  // }

  
  ngOnChanges(change)
  {
    if(change['financialList'])
    {
      this.getBalanceSheetByCustomerBID(this.statement);
    }
  }

  //end life cycle hook

  //custom function
  getSelectedIndex()
  {
    this.selectedFinancialData.emit(this.financialList[this.financialListView.activeIndex]);
  }

  getBalanceSheetByCustomerBID (statementName){
    if(statementName){
      let param = {customerBID: this.financialList.CustomerBID, howMany: 999, includeConsolidations: true, includeProjections: true };
      this.restService.post(environment.baseURI + this.apiUrl, param)
        .subscribe(
          result => {
            this.financialList = result[this.apiUrlJsonKey];
            if(this.financialFilter)
            { 
              var filter="";
              for(var i=0;i<this.financialFilter.length;i++)
                {
                  if(i === 0)
                  {
                    filter = "(x.FinancialStatementSubTypeCde == " + this.financialFilter[i] +")"
                  }
                  else
                  {
                    filter += "|| (x.FinancialStatementSubTypeCde == " + this.financialFilter[i] +")"
                  }
                }
              this.financialList = this.financialList.filter(x => eval(filter))
            }
          })
      }
      else
      {
        this.financialList = '';
      }
  }

  onFinancialStatementHover (id: any): void {
    const paramsData = {
      financialStatementBID: id
    };
    const apiUrl = environment.baseURI + environment.endpoints.retrieveLastInfo;
    this.restService.post(apiUrl, paramsData).subscribe((data: any) => {
      this.lastTouchUserInfo = data.RetrieveLastChangedInformationByFinanicalStatementBIDResult;
    });
  }
  //end custom function

}
