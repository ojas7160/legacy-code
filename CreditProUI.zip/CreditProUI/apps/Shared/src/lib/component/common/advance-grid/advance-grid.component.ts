/* eslint-disable array-callback-return */
import { ElementRef, OnDestroy, SimpleChanges, TemplateRef, HostListener, ViewChild, Component, Input, OnInit } from '@angular/core'
import { Store } from '@ngrx/store'
import { CellCloseEvent, SelectableSettings, TreeListComponent, TreeListItem } from '@progress/kendo-angular-treelist'
import { AppState } from '../../../store'
import { CalculatorComponent } from '../../calculator/calculator.component'
import { gridDataUpdate } from '../../../store/actions'
import { KendoModalService } from '../../../services/kendo-modal/kendo-modal.service'
import { sortBy, cloneDeep } from 'lodash';
import { GridService } from '../../../services/grid/grid.service'
import { TooltipDirective } from '@progress/kendo-angular-tooltip'
import { PercentAdjustComponent } from '../../consolidations/percentage-adjustment/percent-adjust.component'
import { SelectedCustomerService } from '../../../services'
import { WindowCloseResult } from '@progress/kendo-angular-dialog'

@Component({
  selector: 'lib-advance-grid',
  templateUrl: './advance-grid.component.html',
  styleUrls: ['./advance-grid.component.scss']
})
export class AdvanceGridComponent implements OnInit, OnDestroy {
  @Input() data = null
  @Input() columnGroupData: any[]
  @Input() columns: any[]
  @Input() statementActions: any = {}

  @ViewChild('changeViewContent') changeColumnPopup: TemplateRef<any>;
  @ViewChild('productionStatementAction') productionStatementAction: TemplateRef<any>
  // @ViewChild('copyButtonContent') copyColumnPopup: TemplateRef<any>;
  // @ViewChild('thirOptionContent') thirdOptionPopup: TemplateRef<any>;

  @ViewChild('anchor') public anchor: ElementRef
  @ViewChild('treelist') public treeList: TreeListComponent
  @ViewChild('popup', { read: ElementRef }) public popup: ElementRef
  @ViewChild('changeViewImg') changeViewImg: ElementRef
  @ViewChild('specialScheculeAnchor') specialScheculeAnchor: ElementRef
  @ViewChild('copyButtonImg') copyButtonImg: ElementRef
  @ViewChild('thirdOptionImg') thirdOptionImg: ElementRef
  @ViewChild('calcAnchor') calcAnchor: ElementRef
  @ViewChild('cellTemplate') cellTemplate: TemplateRef<any>;
  @ViewChild('prodActionTitleBar') prodActionTitleBar: TemplateRef<any>
  @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;

  public filteredData: any[]
  public expandRows: boolean = false
  public show = false
  public selected: any[]
  coaSearch = ''
  selectedArray: any[] = []
  prevSelection: number
  collapseRow: any[]
  popupRef: any
  calcPopupRef;
  tempColumns = []
  tempData = []
  test;
  calculatorAnchor;
  showDidYouKnow;
  infoToolTip = 'hover';
  prevColumn;
  currentColumn;
  initialValue;
  public selectableSettings: SelectableSettings;
  public allIds: any[] = []
  public settings: SelectableSettings = {
    mode: 'row',
    multiple: false,
    drag: true,
    enabled: true,
    readonly: false
  }

  todayDate = new Date().toDateString()
  sort;
  balanceSheets = []
  isChangeViewOptionOpen = false;
  isCopyButtonOpen = false;
  isThirdOptionOpen = false;
  currentYear;
  currentBs;
  previousYears = []
  omit;
  selectedCell: any;
  specialSchedulePopup: any
  tableViewOption: any = { tableViewPopup: null, copyButtonPopup: null, thirdOptionPopup: null }
  selectedRow: any
  selectedColumnIndex;
  selectedCellEvent: any
  selectedCalcInstance;
  actionPopupRef: any
  selectedCustomer: any

  @HostListener('keydown', ['$event'])
  public keydown (event: any): void {
    if (event.keyCode === 27) {
      this.show = false
    }
    if (event.ctrlKey && event.keyCode === 13) {
      if (this.selectedColumnIndex) {
        this.openCalc(this.calcAnchor && this.calcAnchor.nativeElement)
      }
    }
  }

  @HostListener('document:click', ['$event'])
  public documentClick (event: any): void {
    if (!this.contains(event.target)) {
      this.show = false
    }

    if (!this.containsStatementAction(event.target)) {
      this.specialSchedulePopup && this.kendoModalService.close('popup', this.specialSchedulePopup)
      this.specialSchedulePopup = null
    }

    // if (this.cellTemplate && !this.cellTemplate.elementRef.nativeElement.contains(event.target)) {
    //   if (this.selectedCellEvent && this.selectedCellEvent.column && this.calcPopupRef) {
    //     this.selectedCalcInstance = this.calcPopupRef.content.instance
    //     this.selectedCellEvent.dataItem[this.selectedCellEvent.column.field] = this.calcPopupRef && this.selectedCalcInstance.result
    //     this.selectedCalcInstance = null
    //   }
    //   this.selectedColumnIndex = ''
    // }

    if (!this.containsShowColumn(event.target)) {
      this.tableViewOption.tableViewPopup && this.kendoModalService.close('popup', this.tableViewOption.tableViewPopup)
      this.tableViewOption.copyButtonPopup && this.kendoModalService.close('popup', this.tableViewOption.copyButtonPopup)
      this.tableViewOption.thirdOptionPopup && this.kendoModalService.close('popup', this.tableViewOption.thirdOptionPopup)

      this.tableViewOption = { tableViewPopup: null, copyButtonPopup: null, thirdOptionPopup: null }

      this.isChangeViewOptionOpen = !!this.tableViewOption.tableViewPopup
      this.isCopyButtonOpen = !!this.tableViewOption.copyButtonPopup
      this.isThirdOptionOpen = !!this.tableViewOption.thirdOptionPopup
    }

    if (!this.containsCalc(event.target)) {
      this.calcPopupRef && this.kendoModalService.close('popup', this.calcPopupRef)
      if (this.selectedCellEvent && this.selectedCellEvent.column && this.calcPopupRef) {
        this.selectedCalcInstance = this.calcPopupRef.content.instance
        this.selectedCellEvent.dataItem[this.selectedCellEvent.column.field] = this.calcPopupRef && this.selectedCalcInstance.result
        this.selectedCalcInstance = null
      }

      this.calcPopupRef = null;
    }
  }

  constructor (
    private store: Store<AppState>,
    private kendoModalService: KendoModalService,
    private gridService: GridService,
    private eRef: ElementRef,
    private _selectedCustomerService: SelectedCustomerService
  ) {
    this.setSelectableSettings()
  }

  ngOnInit (): void {
    console.log(this.statementActions)
    this.selectedCustomer = this._selectedCustomerService.getCurrentSelectedCustomer2().customerName;
    this.filteredData = this.data && this.data.length ? JSON.parse(JSON.stringify(this.data)) : null
    const dates = sortBy(this.columnGroupData, ['startDate'])
    this.currentYear = dates[0]
    this.previousYears = dates.slice(1, dates.length)
    this.currentYear.columns = this.currentYear && this.currentYear.columns && this.currentYear.columns.length ? this.currentYear.columns.map(it => { return { ...it, _hide: !it.hide } }) : null
    this.tempColumns = this.previousYears && this.previousYears.length && this.previousYears[0].columns.map(it => { return { ...it, _hide: !it.hide } })
    this.currentBs = this.columnGroupData.find(it => it.id === this.currentYear.id)
    this.tempData = !this.omit ? cloneDeep(this.data) : null
  }

  public setSelectableSettings (): void {
    this.selectableSettings = {
      mode: 'cell',
      // cell: true,
      multiple: false,
      drag: true,
      enabled: true,
      readonly: false
    };
  }

  checkAllStatements (checked) {
    this.columnGroupData.forEach(val => { val.checked = checked });
  }

  containsStatementAction (target) {
    return (this.specialScheculeAnchor && this.specialScheculeAnchor.nativeElement.contains(target)) || (this.specialSchedulePopup && this.specialSchedulePopup.popupElement.contains(target))
  }

  ngOnDestroy () {
    // this.popupRef && this.kendoModalService.close('popup', this.popupRef)

    this.tableViewOption.tableViewPopup && this.kendoModalService.close('popup', this.tableViewOption.tableViewPopup)
    this.tableViewOption.thirdOptionPopup && this.kendoModalService.close('popup', this.tableViewOption.thirdOptionPopup)
    this.tableViewOption.copyButtonPopup && this.kendoModalService.close('popup', this.tableViewOption.copyButtonPopup)
    this.tableViewOption = {}
    this.calcPopupRef && this.kendoModalService.close('popup', this.calcPopupRef)
    this.calcPopupRef = null
    this.actionPopupRef && this.kendoModalService.close('window', this.actionPopupRef)
    this.actionPopupRef = null
    this.specialSchedulePopup && this.kendoModalService.close('popup', this.specialSchedulePopup)
    this.specialSchedulePopup = null
  }

  private containsShowColumn (target: any): boolean {
    return (
      ((this.changeViewImg ? this.changeViewImg.nativeElement.contains(target) : false) ||
      (this.tableViewOption.tableViewPopup ? this.tableViewOption.tableViewPopup.popupElement.contains(target) : false)) ||
      ((this.thirdOptionImg ? this.thirdOptionImg.nativeElement.contains(target) : false) ||
      (this.tableViewOption.thirdOptionPopup ? this.tableViewOption.thirdOptionPopup.popupElement.contains(target) : false)) ||
      ((this.copyButtonImg ? this.copyButtonImg.nativeElement.contains(target) : false) ||
      (this.tableViewOption.copyButtonPopup ? this.tableViewOption.copyButtonPopup.popupElement.contains(target) : false))
    )
  }

  exportStatements (selectedAll) {
    let csvData: any;
    if (selectedAll) {
      csvData = this.ConvertToCSV(this.columnGroupData);
    } else {
      csvData = this.ConvertToCSV(this.columnGroupData.filter(it => it.checked === true));
    }

    const a = document.createElement('a');
    a.setAttribute('style', 'display:none;');
    document.body.appendChild(a);
    const blob = new Blob([csvData], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    a.href = url;
    a.download = 'ETPHoldReview.csv';
    a.click();
  }

  ConvertToCSV (objArray: any): string {
    const array = typeof objArray !== 'object' ? JSON.parse(objArray) : objArray;
    let str = '';
    let row = ''

    for (const index in objArray[0]) {
      // Now convert each value to string and comma-separated
      row += index + ',';
    }
    row = row.slice(0, -1);
    // append Label row with line break
    str += row + '\r\n';

    for (let i = 0; i < array.length; i++) {
      let line = '';
      for (const index in array[i]) {
        if (line !== '') line += ','

        line += array[i][index];
      }
      str += line + '\r\n';
    }
    return str;
  }

  containsCalc (target) {
    return (
      (this.calculatorAnchor && this.calculatorAnchor.contains(target)) || (this.calcPopupRef && this.calcPopupRef.popupElement.contains(target))
    )
  }

  hideColumn (whichSide, field, index, balancesheet, flag?) {
    if (flag && index >= 0) {
      whichSide === 'left' ? balancesheet.columns[index - 1].hide = false : balancesheet.columns[index + 1].hide = false
      this.resetCheckbox(balancesheet, field, true);
      return
    }
    const _columns = balancesheet.columns.filter(it => !it.hide)
    if (_columns.length > 1) {
      field.hide = true
      this.resetCheckbox(balancesheet, field, false);
    }
    this.selectedColumnIndex = null
  }

  resetCheckbox (balancesheet, field, checked) {
    if (balancesheet.id === this.currentYear.id) {
      this.currentYear.columns = this.currentYear.columns.map(it => {
        if (it.columnName === field.columnName) {
          it._hide = checked
        }
        return it
      })
    }

    if (this.previousYears.map(it => it.id).indexOf(balancesheet.id) > -1) {
      this.tempColumns = this.tempColumns.map(it => {
        if (it.columnName === field.columnName) {
          it._hide = checked
        }
        return it
      })
    }
  }

  isLast (balancesheet) {
    const _hiddenColumns = balancesheet.columns.filter(it => !it.hide)

    return _hiddenColumns.length && _hiddenColumns.length === 1
  }

  showNextRightColumnIcon (balancesheet, column) {
    if (balancesheet.columns && balancesheet.columns.length) {
      const columnIndex = balancesheet.columns.findIndex(it => it.columnName.toLowerCase() === column.columnName.toLowerCase())
      if (columnIndex > -1) {
        if (balancesheet.columns[columnIndex + 1] && balancesheet.columns[columnIndex + 1].hide) {
          const c = balancesheet.columns.slice(columnIndex + 1)
          const d = c && c.length && c.filter(it => !it.hide)
          if (!d || !d.length) {
            return true
          }
        }
      }
    }
    return false
  }

  showRightColumnIcon (balancesheet, column) {
    return !this.isLast(balancesheet)
  }

  showLeftColumnIcon (balancesheet, column) {
    if (balancesheet.columns && balancesheet.columns.length) {
      const columnIndex = balancesheet.columns.findIndex(it => it.columnName.toLowerCase() === column.columnName.toLowerCase())
      if (columnIndex > 0) {
        if (balancesheet.columns[columnIndex - 1] && balancesheet.columns[columnIndex - 1].hide) {
          return true
        }
      }
    }
    return false
  }

  ngOnChanges (changes: SimpleChanges): void {
    // Called before any other lifecycle hook. Use it to inject dependencies, but avoid any serious work here.
    // Add '${implements OnChanges}' to the class.
  }

  setStyle (first, last) {
    return { border: '1px solid black' }
  }

  public trackBy (index: number, item: TreeListItem): any {
    return index
  }

  public toggle (show?: boolean): void {
    this.show = !this.show
    this.coaSearch = ''
    this.selectedArray = []
  }

  private contains (target: any): boolean {
    return (
      (this.anchor ? this.anchor.nativeElement.contains(target) : false) ||
        (this.popup ? this.popup.nativeElement.contains(target) : false)
    )
  }

  onItemChange (value) {
    if (value === 'dataRows') {
      this.filteredData = this.filteredData.filter((d) => {
        d.contents = d.contents.filter(content => {
          if (content.size != null || content.size !== undefined) {
            return content
          }
        })
        if (d.contents.length > 0) {
          return d
        }
      })
    }
    if (value === 'allCoa') {
      this.filteredData = JSON.parse(JSON.stringify(this.data))
    }
  }

  onCollapseExpand (value) {
    if (value === 'expandRows') {
      this.allIds = this.filteredData.map(item => item.id)
    } else {
      this.allIds = []
    }
  }

  onSearch (value) {
    this.selectedArray = []
    const flattenArray = this.expandHieraarchy(this.filteredData, [])
    flattenArray.forEach(it => {
      if (it.name.toLowerCase().includes(value.toLowerCase())) {
        this.selectedArray.push(it)
      }
    })
  }

  onNext (value) {
    this.selected = []
    if (this.selectedArray.length === 0) {
      this.onSearch(value)
    }
    if (this.prevSelection) {
      if (this.prevSelection < this.selectedArray[this.selectedArray.length - 1].id) {
        for (let i = 0; i < this.selectedArray.length; i++) {
          if (this.selectedArray[i].id > this.prevSelection) {
            this.selected.push({ itemKey: this.selectedArray[i].name })
            this.expandOnSearch(this.selectedArray[i])
            this.prevSelection = this.selectedArray[i].id
            break
          }
        }
      } else if (this.prevSelection >= this.selectedArray[this.selectedArray.length - 1].id) {
        for (let i = 0; i < this.selectedArray.length; i++) {
          this.selected.push({ itemKey: this.selectedArray[i].name })
          this.expandOnSearch(this.selectedArray[i])
          this.prevSelection = this.selectedArray[i].id
          // break
        }
      }
    } else {
      for (let i = 0; i < this.selectedArray.length; i++) {
        this.selected.push({ itemKey: this.selectedArray[i].name })
        this.expandOnSearch(this.selectedArray[i])
        this.prevSelection = this.selectedArray[i].id
        // break
      }
    }
  }

  onPrevious (value) {
    this.selected = []
    if (this.selectedArray.length === 0) {
      this.onSearch(value)
    }
    if (this.prevSelection) {
      if (this.prevSelection > this.selectedArray[0].id) {
        for (let i = this.selectedArray.length - 1; i >= 0; i--) {
          if (this.selectedArray[i].id < this.prevSelection) {
            this.selected.push({ itemKey: this.selectedArray[i].name })
            this.expandOnSearch(this.selectedArray[i])
            this.prevSelection = this.selectedArray[i].id
            break
          }
        }
      } else if (this.prevSelection <= this.selectedArray[0].id) {
        for (let i = this.selectedArray.length - 1; i >= 0; i--) {
          this.selected.push({ itemKey: this.selectedArray[i].name })
          this.expandOnSearch(this.selectedArray[i])
          this.prevSelection = this.selectedArray[i].id
          // break
        }
      }
    } else {
      for (let i = this.selectedArray.length - 1; i <= 0; i--) {
        this.selected.push({ itemKey: this.selectedArray[i].name })
        this.expandOnSearch(this.selectedArray[i])
        this.prevSelection = this.selectedArray[i].id
        // break
      }
    }
  }

  public cellClickHandler (e: any): void {
    if (this.selectedCellEvent && this.selectedCellEvent.column && this.selectedCalcInstance) {
      this.selectedCellEvent.dataItem[this.selectedCellEvent.column.field] = this.selectedCalcInstance && this.selectedCalcInstance.result
      this.selectedCalcInstance = null
    }
    this.selectedCellEvent = e;
    this.prevColumn = this.currentColumn || e
    this.currentColumn = e
    if (this.initialValue) {
      this.prevColumn.dataItem[this.prevColumn.column.field] = this.initialValue
      this.initialValue = ''
    }
    this.selectedColumnIndex = !e.dataItem?.children?.length ? e.rowIndex + '' + e.columnIndex : null

    this.prevSelection = e.dataItem.id
    // e.dataItem.showTemplate = true;
    this.selectedRow = e.dataItem
    // this.selectedCell = dataItem;
  }

  public cellCloseHandler (e: CellCloseEvent): void {
    const { formGroup, dataItem } = e;
    if (!formGroup.valid) {
      // Prevent closing the edited cell if the form is invalid.
      e.preventDefault();
    } else if (formGroup.dirty) {
      // Reflect changes immediately
      Object.assign(dataItem, formGroup.value);

      // this.editService.update(dataItem);
    }
  }

  expandOnSearch (searchedArray) {
    this.allIds = []
    this.filteredData.forEach(fd => {
      if (searchedArray.type === fd.type) {
        // this.treeList.expand(fd)
        this.allIds.push(fd.id)
      }
    })
  }

  expandHieraarchy (hierarchy, array) {
    hierarchy.forEach(row => {
      array.push(row)
      if (row.contents && row.contents.length) {
        this.expandHieraarchy(row.contents, array)
      }
    })
    return array
  }

  // public onChange (e: SelectionChangeEvent): void {
  //   e.action === 'add' || e.action === 'select'
  // }

  openCalc (anchor) {
    if (this.calcPopupRef) {
      this.kendoModalService.close('popup', this.calcPopupRef)
      if (this.selectedCellEvent && this.selectedCellEvent.column && this.calcPopupRef) {
        this.selectedCalcInstance = this.calcPopupRef.content.instance
        this.selectedCellEvent.dataItem[this.selectedCellEvent.column.field] = this.calcPopupRef && this.selectedCalcInstance.history.result
      }
      this.calcPopupRef = null
      this.calculatorAnchor = null
    } else {
      this.calculatorAnchor = anchor
      this.calcPopupRef = this.kendoModalService.open('popup', '', CalculatorComponent, {
        anchor: anchor,
        anchorAlign: { horizontal: 'right', vertical: 'top' },
        popupAlign: { horizontal: 'center', vertical: 'bottom' },
        content: CalculatorComponent
      })
    }
  }

  removeBalanceSheet (index, item) {
    const _nonHiddenColumns = this.columnGroupData.filter(it => !it.hide)
    if (_nonHiddenColumns && _nonHiddenColumns.length === 1) return;
    // this.columnGroupData = this.columnGroupData.map(it => {
    //   if(it.name == item.name) {
    //     return { ...it, hide: true }
    //   }
    //   return {...it }
    // })
    item.hide = true;
    this.store.dispatch(gridDataUpdate({ gridData: [item] }))
  }

  check (d: TreeListItem, c, i) {
  }

  checkRowIndex (i) {

  }

  openThisBalancesheet (balancesheet) {

  }

  specialSchedule (balancesheet, content, anchor) {
    if (this.specialSchedulePopup) {
      this.kendoModalService.close('popup', this.specialSchedulePopup)
      this.specialSchedulePopup = null;
    } else {
      this.specialSchedulePopup = this.kendoModalService.open('popup', '', content, { anchor: anchor, popupClass: 'popupcontent' })
    }
  }

  checkBalancesheetsCount () {
    const _bs = this.columnGroupData && this.columnGroupData.length && this.columnGroupData.filter(it => !it.hide)
    return _bs && _bs.length === 1
  }

  onDblClick (event) {
    if (this.selectedRow && this.selectedRow.children && this.selectedRow.children.length) {
      if (this.allIds && this.allIds.length && this.allIds.indexOf(this.selectedRow.id) > -1) {
        const i = this.allIds.findIndex(it => it === this.selectedRow.id)
        this.allIds.splice(i, 1)
      } else {
        this.allIds.push(this.selectedRow.id)
      }
      this.allIds = cloneDeep(this.allIds)
    } else {
      // for opening the window on double click
      // this.kendoModalService.open('window', '', content)
    }
    // this.percentAdjust();
  }

  percentAdjust () {
    const params = {
      title: 'Percentage Adjustment',
      width: 400,
      height: 300
    }

    const dialog: any = this.kendoModalService.open('dialog', 'alertDialog', PercentAdjustComponent, params)
    const percentAdj = dialog.content.instance;
    // percentAdj.body = 'Please select a customer.';
    percentAdj.showCancelbtn = true;
  }

  onNavigationCell (e) {
  }

  tableViewOptionPop (anchor, content, type?) {
    if (this.tableViewOption.tableViewPopup) {
      this.kendoModalService.close('popup', this.tableViewOption.tableViewPopup)
      this.tableViewOption.tableViewPopup = null
      this.isChangeViewOptionOpen = false
    }

    if (this.tableViewOption.copyButtonPopup) {
      this.kendoModalService.close('popup', this.tableViewOption.copyButtonPopup)
      this.tableViewOption.copyButtonPopup = null
      this.isCopyButtonOpen = false
    }

    if (this.tableViewOption.thirdOptionPopup) {
      this.kendoModalService.close('popup', this.tableViewOption.thirdOptionPopup)
      this.tableViewOption.thirdOptionPopup = null
      this.isThirdOptionOpen = false
    }

    this.tableViewOption[type] = this.kendoModalService.open('popup', '', content, {
      anchor: anchor,
      popupClass: 'popupcontent popup-margin',
      anchorAlign: { horizontal: 'bottom', vertical: 'bottom' },
      popupAlign: { horizontal: 'left', vertical: 'top' }
    })
  }

  updateColumnView (column, whichYear, checked?) {
    if (whichYear === 'previous') {
      this.columnGroupData = this.columnGroupData.map(originalData => {
        this.previousYears.forEach(it => {
          if (!this.isLast(originalData) || checked) {
            if (originalData.id === it.id) {
              originalData.columns = originalData.columns.map(_column => {
                if (_column.columnName === column.columnName) {
                  _column.hide = !checked
                }
                return _column
              })
            }
          }
        })
        return originalData
      })
    } else {
      this.columnGroupData = this.columnGroupData.map(bs => {
        if (!this.isLast(bs) || checked) {
          if (bs.id === this.currentYear.id) {
            bs.columns = bs.columns.map(it => {
              if (column.columnName === it.columnName) {
                it.hide = !checked
              }
              return it;
            })
          }
        }
        return bs;
      })
    }
    this.store.dispatch(gridDataUpdate({ whichGrid: 'balance', gridData: this.columnGroupData }))
  }

  checkIfColumnHidden (column) {
    return column.hide;
  }

  isLastColumn (type) {
    if (type === 'previous') {
      const _hiddenColumns = this.previousYears && this.previousYears.length && this.previousYears[0].columns.filter(it => !it.hide)
      return _hiddenColumns.length && _hiddenColumns.length === 1
    } else {
      const _hiddenColumns = this.currentYear.columns.filter(it => !it.hide)
      return _hiddenColumns.length && _hiddenColumns.length === 1
    }
  }

  omitted (checked) {
    if (checked) {
      this.data = cloneDeep(this.tempData)
      this.data = this.data.map(d => {
        d.memberValue = d.memberValue ? Math.floor(parseFloat(d.memberValue) / 1000) : ''
        d.fcsValue = d.fcsValue ? Math.floor(parseFloat(d.fcsValue) / 1000) : ''

        if (d.children && d.children.length) {
          d.children = d.children.map(child => {
            child.memberValue = child.memberValue ? Math.floor(parseFloat(child.memberValue) / 1000) : ''
            child.fcsValue = child.fcsValue ? Math.floor(parseFloat(child.fcsValue) / 1000) : ''
            child.source = child.source ? Math.floor(parseFloat(child.source) / 1000) : ''
            child.calculated = child.calculated ? Math.floor(parseFloat(child.calculated) / 1000) : ''
            child.adjusted = child.adjusted ? Math.floor(parseFloat(child.adjusted) / 1000) : ''
            return child
          })
        }
        return d
      })
    } else {
      // this.data = this.tempData
      this.gridService.setGridData(this.tempData)
    }
  }

  applySetting () {
    if (this.currentYear && this.currentYear.columns && this.currentYear.columns.length) {
      this.columnGroupData = this.columnGroupData.map(originalData => {
        if (originalData.id === this.currentYear.id) {
          originalData.columns = originalData.columns.map(originalColumn => {
            this.currentYear.columns.forEach(currentColumn => {
              if ((originalColumn.columnName === currentColumn.columnName) && !this.isLast(originalData)) {
                originalColumn.hide = !currentColumn._hide
              }
            })
            return originalColumn
          })
        }
        return originalData;
      })
    }

    if (this.tempColumns && this.tempColumns.length && this.previousYears && this.previousYears.length) {
      this.columnGroupData = this.columnGroupData.map(originalData => {
        this.previousYears.forEach(it => {
          if (originalData.id === it.id) {
            originalData.columns = originalData.columns.map(originalColumn => {
              this.tempColumns.forEach(currentColumn => {
                if ((originalColumn.columnName === currentColumn.columnName) && !this.isLast(originalData)) {
                  originalColumn.hide = !currentColumn._hide
                }
              })
              return originalColumn
            })
          }
        })
        return originalData;
      })
    }

    this.store.dispatch(gridDataUpdate({ whichGrid: 'balance', gridData: this.columnGroupData }))
  }

  showDidYouKnowTooltip (checked) {
    if (this.infoToolTip === 'none') return
    if (checked) this.infoToolTip = 'hover'
    this.showDidYouKnow = checked
  }

  hideToolTip () {
    this.tooltipDir.hide();
    this.infoToolTip = 'hover';
    this.showDidYouKnow = false;
  }

  openAction (link) {
    let content = null;
    let configs = ''
    let additionalParams = {}
    switch (link.name) {
      case 'Production':
        content = this.productionStatementAction
        configs = 'productionStatementAction'
        additionalParams = { titleBarContent: this.prodActionTitleBar }
        break;
    }
    if (this.actionPopupRef) {
      this.kendoModalService.close('window', this.actionPopupRef)
      this.actionPopupRef = null
    } else if (content) {
      this.actionPopupRef = this.kendoModalService.open('window', configs, content, additionalParams);
    }

    this.actionPopupRef.result.subscribe(res => {
      if (res instanceof WindowCloseResult) {
        this.kendoModalService.close('window', this.actionPopupRef)
        this.actionPopupRef = null
      }
    })
  }
}
