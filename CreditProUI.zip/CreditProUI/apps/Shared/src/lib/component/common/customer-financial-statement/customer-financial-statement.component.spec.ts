import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerFinancialStatementComponent } from './customer-financial-statement.component';

describe('CustomerFinancialStatementComponent', () => {
  let component: CustomerFinancialStatementComponent;
  let fixture: ComponentFixture<CustomerFinancialStatementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerFinancialStatementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerFinancialStatementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
