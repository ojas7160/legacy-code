import { Component, OnInit, ViewChild, ElementRef, OnDestroy, HostListener } from '@angular/core';
import { Store } from '@ngrx/store'
import { AppState } from '../../../store'
import * as customerActions from '../../../store/actions/open.customer.actions'
import { openCustomersSelector } from '../../../store/selectors/open.customer.selector'
import { Router } from '@angular/router';
import { KendoModalService, SelectedCustomerService } from '../../../services';
import { omit } from 'lodash';
import { FinancialStatementSubType } from '../../../enum/financialStatementSubType';

@Component({
  selector: 'uc-customer-bottom-tab',
  templateUrl: './customer-bottom-tab.component.html',
  styleUrls: ['./customer-bottom-tab.component.scss']
})
export class CustomerBottomTabComponent implements OnInit, OnDestroy {
  @ViewChild('anchor') public anchor: ElementRef
  @ViewChild('popup', { read: ElementRef }) public popup: ElementRef;

  showbottompopup:boolean;
  public selectedCustomerId:number;
  public selectedCustomerName:string;
  customerBottomMenu= [];
  clickedIndex: number = 0
  margin = { horizontal: 0, vertical: 60 };
  isClose = false;
  openCustomersUpdated = [];
  selectedCustomerTab: any;

  @HostListener('keydown', ['$event'])
  public keydown (event: any): void {
    if (event.keyCode === 27) {
      this.toggle(false);
    }
  }

  @HostListener('document:click', ['$event'])
  public documentClick (event: any): void {
    if (!this.contains(event.target)) {
      this.toggle(false);
    }
  }

  constructor (private store: Store<AppState>,
    private router:Router,
    private kendoModalService:KendoModalService,
    private selectedCustomerService: SelectedCustomerService) {}

  ngOnInit (): void {
    this.store
      .select(openCustomersSelector)
      .subscribe(data => {
        if (data && data !== null) {
          this.customerBottomMenu = data.openCustomers.filter(customer => customer.isOpened === true)
          this.openCustomersUpdated = this.modifyOpenCustomers();
        }
      });
  }

  // Added canClose property to all openCustomers
  modifyOpenCustomers () {
    return this.customerBottomMenu.map(item => {
      item.canClose = false;
      if (item && item.isSelected) {
        this.selectedCustomerId = item.customerId
        this.selectedCustomerName = item.customerName
        this.selectedCustomerTab = this.getSelectedCustomerTab(item.customerId);
      }
      return item;
    });
  }

  isCustomerSelected (customer) {
    return customer.isSelected;
  }

  // Function to check if a customer tab can be closed or not
  canClose (customer, e) {
    e.stopPropagation();
    const updatedCustomerArr = this.openCustomersUpdated.map(item => {
      if (item.customerId === customer.customerId) {
        if (customer.canClose) {
          item.canClose = false;
        } else {
          item.canClose = true;
        }
      }
      return item;
    });
    this.openCustomersUpdated = updatedCustomerArr.slice();
  }

  // Function to remove closed customer tab
  closeCustomer (column) {
    const customer = omit(column, 'canClose');
    this.store.dispatch(customerActions.openCustomerRemove({ data: customer }));
    if (column.isSelected && this.selectedCustomerTab && this.selectedCustomerTab.length === 1) {
      this.router.navigate(['home']);
    }
  }

  // Function to remove particular sheet
  closeCustomerSheet (customerTaskId) {
    this.store.dispatch(customerActions.openCustomerRemoveSheet({ customerId: this.selectedCustomerId, customerTaskId: customerTaskId }));
    if (this.selectedCustomerTab === undefined) {
      if ((this.openCustomersUpdated && this.openCustomersUpdated.length === 1)) {
        this.router.navigate(['home']);
      }
    }
  }

  // Function to get selected customer tab
  getSelectedCustomerTab (customerId) {
    this.selectedCustomerId = customerId;
    const bottomTabInfo = this.openCustomersUpdated.map(val => {
      if (val.customerId === customerId) {
        return val.bottomTabCustomerInfo;
      }
      return null;
    }).filter(val => val !== null)

    if (bottomTabInfo[0] && bottomTabInfo[0].length === 0) {
      this.showbottompopup = false
    }
    const data = this.setBottomTabInfoDetails(bottomTabInfo);
    // return bottomTabInfo[0];
    return data[0];
  }

  setBottomTabInfoDetails (info) {
    const data = info.map(item => {
      if (item) {
        item.map(key => {
          const tabDetails = this.getDisplayName(key.TaskDescription, key.FinancialStatementDesc)
          key.displayName = tabDetails.name
          key.icon = tabDetails.icon
          return key
        })
        return item
      }
      return null;
    })
    return data;
  }

  getDisplayName (taskDesc, label) {
    switch (taskDesc) {
      case 'Balance Sheet': {
        const data = {
          name: 'BS Trend',
          icon: 'balance_icon'
        }
        return data
      }
      case 'Earnings Statement': {
        const data = {
          name: 'ES Trend',
          icon: 'Earnings_icon'
        }
        return data
      }
      case 'BS Consolidation': {
        const data = {
          name: label,
          icon: 'consol_bs'
        }
        return data
      }
      case 'ES Consolidation': {
        const data = {
          name: label,
          icon: 'consol_es'
        }
        return data
      }
      case 'Projection': {
        const data = {
          name: label,
          icon: 'Projection_icon'
        }
        return data
      }
      case 'Projection Simple': {
        const data = {
          name: label,
          icon: 'thumbnail_proforma'
        }
        return data
      }
      case 'Projection Advanced': {
        const data = {
          name: label,
          icon: 'thumbnail_postclose'
        }
        return data
      }
      default: {
        return taskDesc
      }
    }
  }

  openBalanceSheet (customerInfo) {
    this.selectedCustomerService.setCustomerOpenedSelectedInfo(this.selectedCustomerId, this.selectedCustomerName, true, true, true, customerInfo);
    if (customerInfo.FinancialStatementSubTypeCde === FinancialStatementSubType.BalanceSheet ||
      customerInfo.FinancialStatementSubTypeCde === FinancialStatementSubType.BalanceSheetConsolidation ||
      customerInfo.FinancialStatementSubTypeCde === FinancialStatementSubType.BalanceSheetProjection) {
      this.router.navigateByUrl('balance-sheet', { state: customerInfo });
    } else if (customerInfo.FinancialStatementSubTypeCde === FinancialStatementSubType.EarningsStatement) {
      this.router.navigateByUrl('earnings', { state: customerInfo });
    }
    this.showbottompopup = false;
  }

  toggle (show?: boolean) {
    this.showbottompopup = show !== undefined ? show : !this.showbottompopup;
  }

  private contains (target: any): boolean {
    return (
      (this.anchor ? this.anchor.nativeElement.contains(target) : false) ||
      (this.popup ? this.popup.nativeElement.contains(target) : false)
    );
  }

  showBottomSelectedUser (data, event) {
    event.stopPropagation();
    this.toggle();
    this.selectedCustomerId = data.customerId;
    this.selectedCustomerName = data.customerName;
    this.selectedCustomerTab = this.getSelectedCustomerTab(data.customerId);
  }

  checkCurrentRoute (route) {
    if (this.router.url.includes(route)) {
      return true;
    }
    return false;
  }

  ngOnDestroy () {}
}
