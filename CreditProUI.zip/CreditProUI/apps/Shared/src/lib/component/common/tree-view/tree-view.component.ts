import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { of, Observable } from 'rxjs';
import { environment } from '../../../../../../CreditPro/src/environments/environment';
import { RestService } from '../../../services';
import { AppConstant } from '../../../constants/app-constants';
const is = (fileName: string, ext: string) =>
  new RegExp(`.${ext}\$`).test(fileName);

@Component({
  selector: 'uc-tree-view',
  templateUrl: './tree-view.component.html',
  styleUrls: ['./tree-view.component.scss']
})
export class UcTreeViewComponent implements OnInit {
  selectedKeys: any[] = [];
  selected: any[] = [];
  @Input() data: any[] = [];
  @Input() multiple: boolean = false;
  @Input() childAttribute: string = 'children';
  @Input() description: string = '';
  @Input() text = 'text';
  @Input() text2 = '';
  @Input() dateDesc = 'desc2';
  @Input() showIcon;
  @Input() showCheckbox;
  @Output() output = new EventEmitter<any>()
  //dateformat:
  /**
   * The field that holds the keys of the expanded nodes.
  */
  public keys: string[] = [];
  lastTouchUserInfo: any;
  dateFormat = AppConstant.dateFormat
  timeFormat = AppConstant.timeFormat
  constructor(private restService: RestService) { }

  ngOnInit() {
  }




  /**
   * A function that checks whether a given node index exists in the expanded keys collection.
   * If the index can be found, the node is marked as expanded.
   */
  public isExpanded = (dataItem: any, index: string) => {
    return this.keys.indexOf(index) > -1;
  }

  public children = (dataitem: any): Observable<any[]> => of(dataitem[this.childAttribute]);
  public hasChildren = (dataitem: any): boolean => dataitem[this.childAttribute] && dataitem[this.childAttribute].length;

  /**
   * A `collapse` event handler that will remove the node hierarchical index
   * from the collection, collapsing its children.
   */
  public handleCollapse(node: any) {
    this.keys = this.keys.filter(k => k !== node.index);
  }

  /**
   * An `expand` event handler that will add the node hierarchical index
   * to the collection, expanding the its children.
   */
  public handleExpand(node: any) {
    this.keys = this.keys.concat(node.index);
  }

  public handleSelection(event: any) {

    this.selected.indexOf(event) > -1 ?
      this.selected.splice(event) : this.selected.push(event);

    this.output.emit(this.multiple === true ? this.selected : event);
  }

  public isItemSelected = (_: any, index: string) =>
    this.selectedKeys.indexOf(index) > -1;

  public iconClass({ text, items }: any): any {

    return {
      "k-i-file-pdf": is(text, "pdf"),
      "k-i-folder": items == undefined,
      "k-i-html": is(text, "html"),
      "k-i-image": is(text, "jpg|png"),
      "k-icon": true,
    };
  }




  updateStatements(item) {
    // console.log(item)
    this.output.emit(item)
  }

  onFinancialStatementHover(id: any): void {   
    if (id != undefined) {
      const paramsData = {
        financialStatementBID: id
      };
      const apiUrl = environment.baseURI + environment.endpoints.retrieveLastInfo;
      this.restService.post(apiUrl, paramsData).subscribe((data: any) => {
        this.lastTouchUserInfo = data.RetrieveLastChangedInformationByFinanicalStatementBIDResult;
      });
    }
  }
}
