import { Component, Input, OnInit, Output, EventEmitter, HostListener, OnDestroy, SimpleChanges, ViewEncapsulation } from '@angular/core'
import { FormArray, FormBuilder, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { IColumn, IGrid } from '../../../interface/grid'
import { KendoModalService } from '../../../services';
import { CalculatorComponent } from '../../calculator/calculator.component';
import { CommentEditor } from '../comments-editor/comments-editor.component';
import { isEqual } from 'lodash';
import { ColumnFieldType } from '../../../enum/columnFieldType';
import { aggregateBy } from '@progress/kendo-data-query';
import { RowArgs } from '@progress/kendo-angular-grid';

@Component({
  selector: 'uc-simple-grid',
  templateUrl: './simple-grid.component.html',
  styleUrls: ['./simple-grid.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class SimpleGridComponent implements OnInit, OnDestroy {
  @Input() dataSource: IGrid[];
  @Input() columns: IColumn[];
  @Input() allowSelection = true;

  @Output() onGridDataChanged = new EventEmitter();
  @Output() selectedColumnData = new EventEmitter();

  gridForm: FormArray;
  gridFormSub: Subscription;
  calculatorRef: any;
  selectedCell: any;
  gridData: any;
  formData: any;
  calcAnchor: any;
  selectedCalcInstance: any;
  isSelected = false;
  totalSum;
  public aggregates: any[];

  @HostListener('document:click', ['$event'])
  public documentClick (event: any): void {
    if (!this.containsCalc(event.target)) {
      this.calculatorRef && this.kendoModalService.close('popup', this.calculatorRef)
      if (this.selectedCell && this.selectedCell.column && this.calculatorRef) {
        this.selectedCalcInstance = this.calculatorRef.content.instance
        this.updateFormData(this.selectedCalcInstance.result);
      }

      this.calculatorRef = null;
    }
  }

  constructor (private fb: FormBuilder, private kendoModalService: KendoModalService) { }

  ngOnInit (): void { }

  ngOnChanges (changes: SimpleChanges) {
    if (changes.dataSource && changes.dataSource.firstChange) {
      this.createFormArray();
    }
    if (changes.dataSource && !changes.dataSource.firstChange && !isEqual(changes.dataSource.currentValue, changes.dataSource.previousValue)) {
      this.createFormArray()
    }
  }

  public createFormArray () {
    this.gridForm = this.fb.array([])
    this.dataSource.forEach((item, i) => {
      this.gridForm.insert(i, this.createDataFormGroup(item));
    });

    this.gridFormSub = this.gridForm.valueChanges.subscribe(val => {
      this.formData = val;
    })

    this.setGridData(this.gridForm.controls);
  }

  createDataFormGroup (item?) {
    const obj = {
      isSelected: false,
      id: null,
      isEnabled: false
    };
    this.columns.forEach(field => {
      if (item && item.data) {
        [obj[field.dataMemberBindingName]] = [{ value: item.data[field.dataMemberBindingName], disabled: field.isDisabled }, this.formValidations(field)]
      } else {
        [obj[field.dataMemberBindingName]] = [{ value: '', disabled: field.isDisabled }, this.formValidations(field)]
      }
    })
    if (item) {
      obj.isSelected = item.isSelected
      obj.id = item.id
    }
    return this.fb.group(obj);
  }

  onSelect(index){
      this.unselect(index);
      this.gridForm.controls[index].get('isSelected').patchValue(true);
  }

  formValidations (field) {
    const arr = [];
    if (field.isRequired) {
      arr.push(Validators.required);
    }
    return arr;
  }

  setGridData (data: any) {
    this.gridData = {
      data: data,
      total: data.length
    }

    const total = this.setTotal(this.gridData.data);
    this.aggregates = this.setAggregates();
    this.totalSum = aggregateBy(total, this.aggregates);
  }

  setTotal (data) {
    const arr = [];
    data.forEach(item => {
      arr.push(item.value);
    })
    return arr;
  }

  setAggregates () {
    const arr = [];
    this.columns.forEach(item => {
      if (item.columnType === ColumnFieldType.Calculator) {
        arr.push({ field: item.dataMemberBindingName, aggregate: 'sum' })
      }
    })
    return arr;
  }

  updateFormData (data) {
    this.gridForm.controls[this.selectedCell.rowIndex].get(this.selectedCell.column.field).patchValue(data);
  }

  unselect (rowIndex: number) {
    const data = this.gridForm.controls.map((data, key) => {
      if (rowIndex !== key) {
        data.value.isSelected = false;
      }
      else {
       
        data.value.isSelected = true;
      }
      return data;
    })
    this.setGridData(data);
  }

  containsCalc (target) {
    return (
      (this.calcAnchor && this.calcAnchor.contains(target)) || (this.calculatorRef && this.calculatorRef.popupElement.contains(target))
    )
  }

  isRowSelected (context: RowArgs) {
     return context.dataItem.value.isSelected === true
  }

  openCalculator (anchor) {
    if (this.calculatorRef) {
      this.kendoModalService.close('popup', this.calculatorRef)
      if (this.selectedCell && this.selectedCell.column && this.calculatorRef) {
        this.selectedCalcInstance = this.calculatorRef.content.instance
        this.updateFormData(this.selectedCalcInstance.result);
      }
      this.calculatorRef = null
      this.calcAnchor = null
    } else {
      this.calcAnchor = anchor
      this.calculatorRef = this.kendoModalService.open('popup', '', CalculatorComponent, {
        anchor: anchor,
        anchorAlign: { horizontal: 'right', vertical: 'top' },
        popupAlign: { horizontal: 'center', vertical: 'bottom' },
        content: CalculatorComponent
      })
    }
  }

  openCommentEditor (column, value, index, type?) {
    this.onSelect(index);
    if ((type === 'delete') && value) {
      this.patchFormValues(column,index, '');
      return;
    }
    const dialog: any = this.kendoModalService.open('window', 'commentEditor', CommentEditor)
    if (value && value[column]) {
      dialog.content.instance.value = value[column];
    }

    dialog.result.subscribe((response) => {
      if (response.action === 'OK') {
        this.patchFormValues(column, index, response.comment);
      }
    })
  }

  patchFormValues (column, index, comment) {
      this.onSelect(index);
      this.gridForm.controls[index].get(column).patchValue(comment);
  }

  public cellClickHandler (event : any) {    
    this.selectedCell = event
    if (this.selectedCell && this.selectedCell.column) {
      if (this.selectedCalcInstance) {
        this.selectedCell.dataItem[this.selectedCell.column.field] = this.selectedCalcInstance && this.selectedCalcInstance.result
        this.selectedCalcInstance = null
      }
    }
    if (!event.isEdited) {
      this.onSelect(this.selectedCell.rowIndex);
      event.sender.editCell(event.rowIndex, event.columnIndex, this.createFormGroup(event.rowIndex, event.dataItem));
    }
  }

  public createFormGroup (rownum, dataItem?: any) {
    if (rownum < (this.gridData.total - 1)) {
      return this.fb.group(dataItem);
    }
    this.gridForm.push(this.createDataFormGroup());
    this.setGridData(this.gridForm.controls);
    return this.gridForm;
  }

  public cellCloseHandler (args: any) {
    const { formGroup } = args;
    if (formGroup.dirty) {
      this.onGridDataChanged.emit(this.formData);
    }
  }

  onColumnClicked (fieldName, value = null) {
    this.selectedColumnData.emit({
      fieldName: fieldName,
      value: this.selectedCell.dataItem.value
    });
  }

  ngOnDestroy () {
    if (this.gridFormSub) {
      this.gridFormSub.unsubscribe();
    }
  }
}
