import { Component, OnInit, OnDestroy, ViewEncapsulation, Input, ViewChild, Output, EventEmitter } from '@angular/core'
import { TooltipDirective } from '@progress/kendo-angular-tooltip';

@Component({
  selector: 'uc-help-info-icon',
  templateUrl: './help-info-icon.component.html',
  styleUrls: ['./help-info-icon.component.scss'],
  encapsulation: ViewEncapsulation.None 
})
export class HelpInfoIconComponent implements OnInit, OnDestroy {
  @Input() header: string;
  @Input() helpIcon = true;
  @Input() infoIcon = true;
  @Input() helpPosition = 'bottom';
  @Input() infoPosition = 'bottom';
  @Input() bgColorHelp = '';
  @Input() bgColorInfo = '';
  @Output() helpInfoToolTipChangeValue: EventEmitter<any> = new EventEmitter<any>();

  helpToolTip = 'hover';
  infoToolTip = 'hover';
  infoPopupClass = "k-animation-container k-animation-container-fixed k-tooltip-wrapper k-animation-container-shown info-margin"

  @ViewChild('helpInstance') public helpInstance: TooltipDirective;
  @ViewChild('infoInstance') public infoInstance : TooltipDirective;
  
  ngOnInit (): void {
  }

  showTooltip (type: string) {
    if(type === 'help'){
      this.helpToolTip = 'none';
    } else {
      this.infoToolTip = 'none';
      this.infoInstance.popupRef.popupElement.className = this.infoPopupClass;
    }
    this.helpInfoToolTipChangeValue.emit({type: type, value: 'none'});
  }

  closeInfoToolTip () {
    this.infoToolTip = 'hover';
    this.infoInstance.hide()
  }

  closeHelpToolTip () {
    this.helpToolTip = 'hover';
    this.helpInstance.hide()
  }

  ngOnDestroy () { }
}
