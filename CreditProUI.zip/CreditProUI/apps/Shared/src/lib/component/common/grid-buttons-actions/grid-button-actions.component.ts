import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Align } from '../../../enum';

@Component({
  selector: 'uc-grid-button-actions',
  templateUrl: './grid-button-actions.component.html',
  styleUrls: ['./grid-button-actions.component.scss']
})

export class GridButtonActionsCommponent implements OnInit {
  left:any[] = [];
  right:any[] = [];

  @Input()
  set options (value:any[]) {
    this.left = value
      .filter(l => l.align === Align.Left)
      .sort((a, b) => { return a.index - b.index });
    this.right = value
      .filter(l => l.align === Align.Right)
      .sort((a, b) => { return a.index - b.index });
  }

  @Output() onButtonClicked = new EventEmitter();

  constructor () { }

  ngOnInit () { }

  buttonClicked (buttonData) {
    this.onButtonClicked.emit(buttonData.controlName)
  }
}
