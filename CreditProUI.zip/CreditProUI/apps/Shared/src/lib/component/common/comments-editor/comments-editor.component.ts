import { Component, Input, OnInit, ViewEncapsulation } from "@angular/core";
import { select, Store } from "@ngrx/store";
import { WindowRef } from "@progress/kendo-angular-dialog";
import * as commentsActions from '../../../store/actions/comments.action';
import { DcComment } from "../../../models/comment";
import { AppState } from "../../../store";
import { commentsSelector } from '../../../store/selectors/comments.selector';

@Component({
  selector: 'uc-comment-editor',
  templateUrl: './comments-editor.component.html',
  styleUrls:['./comments-editor.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CommentEditor implements OnInit {

 public value :string;
 comments: DcComment;

  constructor(private store: Store<AppState>,private dialog: WindowRef) {
  }

  ngOnInit() {
    this.store.pipe(select(commentsSelector))
    .subscribe(data => {
      if (data?.type === commentsActions.COMMENTS_LOAD_DATA) {
      this.comments = data?.RetrieveCommentResult;
      this.value = this.comments?.Comment;
      }
    });
  }

  close(controlName: string) {
    let params = {
      comment: this.value,
      action: controlName,
    }
    this.dialog.close(params);
  }
}
