/* eslint-disable no-undef */
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvanceGridComponent } from './advance-grid.component';

describe('AdvanceGridComponent', () => {
  let component: AdvanceGridComponent;
  let fixture: ComponentFixture<AdvanceGridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AdvanceGridComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvanceGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
