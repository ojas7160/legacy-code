/* eslint-disable no-useless-constructor */
/* eslint-disable semi */
/* eslint-disable eqeqeq */
import { Component, EventEmitter, forwardRef, Input, OnInit, Output, SimpleChange, ViewChild } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { DropDownListComponent } from '@progress/kendo-angular-dropdowns';

@Component({
  selector: 'uc-drop-down',
  templateUrl: './drop-down.component.html',
  styleUrls: ['./drop-down.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => DropDownComponent),
      multi: true
    }
  ]
})
export class DropDownComponent implements ControlValueAccessor, OnInit {
  @Input() data : any;
  @Input() text = 'text';
  @Input() value = 'value';
  @Input() whichComponent;
  @Input() ngModelValue: any = '';
  @Input() fControlName;
  @Input() defaultItem: any;
  @Input() defaultPrimitive = true;
  @Input() placeHolder = '';
  @Output() triggerControl: EventEmitter<any> = new EventEmitter<any>();
  @Output() ngModelValueChange: EventEmitter<any> = new EventEmitter<any>();

  // @Input() deafultPrimitive:boolean = false;
  @Input() imageIcon:string = undefined;
  @Input() addNone:string = '';
  @Input() selectedItem: number;
  @ViewChild('dropDown', { static: false })
  public dropDown: DropDownListComponent;

  _value: any;

  constructor () { }

  ngOnInit (): void {
    if (this.defaultItem == true) {
      const _dateItem = { text: '<None>', value: 0 };
      this.data.unshift(_dateItem);
    }
    
  }

  close (e): void {
    // e.preventDefault()
    if (this._value == '<None>') { this.triggerControl.emit({ response: false, control: this.fControlName }); }
  }

  protected onChange: any = (): void => { };
  registerOnChange (fn): void {
    this.onChange = fn;
  }

  change (params: any) {
    this._value = params?.text;
    params?.text == '<None>' ? this.onChange() : this.onChange(true);
    params?.text == '<None>'
      ? this.triggerControl.emit({ response: true, control: this.fControlName, value: params })
      : this.triggerControl.emit({ response: false, control: this.fControlName, value: params });
  }

  writeValue (selectedItem: number) {
    isNaN(selectedItem) ? this.onChange() : this.onChange(true);
  }

  registerOnTouched (fn: any) {

  }

  ngOnChanges (changes: SimpleChange) {
    const changedValue = changes.currentValue ? changes.currentValue : changes.previousValue
    this.ngModelValueChange.emit(changedValue)
  }

  public itemDisabled (itemArgs: { dataItem: any; index: number }) {
    // console.log(itemArgs.dataItem)
    return false
  }
}
