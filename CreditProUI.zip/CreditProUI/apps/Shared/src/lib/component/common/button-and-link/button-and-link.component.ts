import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'uc-button-and-link',
  templateUrl: './button-and-link.component.html',
  styleUrls: ['./button-and-link.component.scss']
})
export class ButtonAndLinkComponent implements OnInit {

  @Input() controlType;
  @Input() controlName;
  @Input() whichComponent;
  @Input() style;
  @Input() class;
  @Input() hasIcon: boolean;
  @Input() iconDetails;
  @Input() isKendoControl: boolean;

  @Output() triggerControl: EventEmitter<any> = new EventEmitter<any>();

  constructor() { }

  ngOnInit(): void {
  }

  clickControl(control: string) {
    this.triggerControl.emit(control);
  }

}
