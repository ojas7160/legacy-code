import { Component, EventEmitter, forwardRef, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { DatePickerComponent } from '@progress/kendo-angular-dateinputs';

@Component({
  selector: 'lib-date-input',
  templateUrl: './date-input.component.html',
  styleUrls: ['./date-input.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => DateInputComponent),
      multi: true
    }
  ]
})
export class DateInputComponent implements ControlValueAccessor, OnInit {
  @Input() value: Date;
  @Input() fControlName = "";
  @Output() triggerControl: EventEmitter<any> = new EventEmitter<any>();
  @ViewChild("datepicker", { static: false })
  public datepicker: DatePickerComponent;

  min = new Date(1900, 1, 1);
  max = new Date(2100, 2, 2);

  constructor() { }

  ngOnInit(): void {
    console.log(this.value)
    if (this.value && this.datepicker)
      this.writeValue(this.value);
  }

  protected onChange: any = (): void => {
  };
  registerOnChange(fn): void { this.onChange = fn; }

  writeValue(value: any) {
    if (value != null || this.datepicker.input.inputValue == "month/day/year") {
      this.onChange(value);
    }
    else {
      this.onChange(this.datepicker.input.inputValue);
    }
    value == null ? this.triggerControl.emit({ response: true, control: this.fControlName,date: value })
      : this.triggerControl.emit({ response: false, control: this.fControlName,date: value });
  }

  registerOnTouched(fn: any) {

  }
  onClose (e){
    //e.preventDefault();
  }

  dateIsValid() {
    return this.value && this.value instanceof Date;
  }

}
