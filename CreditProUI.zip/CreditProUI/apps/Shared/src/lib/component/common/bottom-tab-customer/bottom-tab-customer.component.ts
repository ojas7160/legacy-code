/* eslint-disable no-useless-constructor */
import { Component, OnInit } from '@angular/core'
import { Store } from '@ngrx/store'
import { Observable } from 'rxjs'
import { AppState } from '../../../store'
import * as openCustomersActions from '../../../store/actions/open.customer.actions'
import { openCustomersSelector } from '../../../store/selectors/open.customer.selector'

@Component({
  selector: 'uc-bottom-tab',
  templateUrl: 'bottom-tab-customer.component.html',
  styleUrls: ['./bottom-tab-customer.component.scss']
})

export class UcBottomTabComponent implements OnInit {
  openCustomers$: Observable<any>;
  toggleLinkIcon = "<li><span class='k-icon k-i-close-circle'></span> .k-i-close-circle<br /> .k-i-x-circle</li>"
  constructor (private store: Store<AppState>) {
    // this.store
    //   .select(openCustomersSelector)
    //   .subscribe(data => {
    //     this.openCustomers$ = data
    //   })
  }

  ngOnInit () { }

  removeCustomer (index) {
    this.store.dispatch(openCustomersActions.openCustomerRemove(index))
  }
}
