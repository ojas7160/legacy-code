import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ButtonAndLinkComponent } from './button-and-link.component';

describe('ButtonAndLinkComponent', () => {
  let component: ButtonAndLinkComponent;
  let fixture: ComponentFixture<ButtonAndLinkComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ButtonAndLinkComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ButtonAndLinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
