import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { CommonService } from '../../../services/common/common.service';

@Component({
  selector: 'uc-error-component',
  templateUrl: './error-component.component.html',
  styleUrls: ['./error-component.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ErrorComponentComponent implements OnInit {
  @Input() errorData;
  errorMessageData;
  @Input() whichComponent;

  IsErrorActive: boolean = true
  showErrors: boolean = true;

  constructor (private commonService: CommonService) { }

  ngOnInit (): void {
    this.commonService.getErrorData.subscribe((res) => {
      if (res.errorTitle === 'Errors') {
        this.errorData = res.errorObj
        this.IsErrorActive = true
      } else {
        this.errorMessageData = res.errorObj
        if (!(this.errorData && this.errorData.length)) {
          this.IsErrorActive = false
        }
      }
    });
    console.log(this.errorData)
  }

  onClear () {
    if (this.errorData) {
      this.errorData.length = 0;
    }
    if (this.errorMessageData) {
      this.errorMessageData.length = 0;
    }
    this.commonService.errorObjs = [];
    this.commonService.errorMessageObjs = [];
  }
}
