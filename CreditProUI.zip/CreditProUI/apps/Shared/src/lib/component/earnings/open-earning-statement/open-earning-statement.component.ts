/* eslint-disable no-unused-vars */
import { Component, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { TreeNode, TreeNodeFinancialConsolidation } from '../../../models/balanceSheet/TreeNode';
import { AppState } from '../../../store';
import { environment } from 'apps/CreditPro/src/environments/environment';
import { RestService, SelectedCustomerService } from '../../../services';
import { AppConstant } from '../../../constants/app-constants';
import { CachedLookups } from '../../../enum/cachedLookups';
import { FinancialStatementSubTypes } from '../../../enum/financialStatementSubTypes';
import { commonSelector } from '../../../store/selectors/common.selector';
import { Align, controlType } from '../../../enum';

@Component({
  selector: 'uc-open-earning-statement',
  templateUrl: './open-earning-statement.component.html',
  styleUrls: ['./open-earning-statement.component.scss']
})
export class OpenEarningStatementComponent implements OnInit {

  /*local variable starts*/
  consolidationTreeNode: TreeNode[] = [];
  showCheckbox: true;
  currentSelectedCustomerId: any;
  tlkpBenchmarkIndustryTemplate: any;
  benchmarkIndustryTreeNodes: TreeNode[] = [];
  lookUps: any;

  btnOptions = [
    { controlType: controlType.Button, controlName: 'New', align: Align.Left, index: 1, class: 'btn btn-primary btn-custom-size3' },
    { controlType: controlType.Button, controlName: 'Unselect All', align: Align.Left, index: 2, class: 'btn btn-primary btn-custom-size4' },
    { controlType: controlType.HyperLink, controlName: 'Cancel', align: Align.Right, index: 1, class: '' },
    { controlType: controlType.Button, controlName: 'OK', align: Align.Right, index: 2, class: 'btn btn-primary btn-custom-size3' },
  ];
  /*local variable end*/

  /*life cycle hook*/
  constructor(private store: Store<AppState>, private restService: RestService,
    private selectedCustomerService: SelectedCustomerService) { }
  /*end life cycle*/

  ngOnInit(): void {
    this.currentSelectedCustomerId = this.selectedCustomerService.getCurrentSelectedCustomer2().customerId;
    this.loadLookUps();
    this.getConsolidation();
    this.getBenchmarkData();
  }

  //get consolidation details for tab
  getConsolidation() {

    const paramsData = {
      "customerBID": this.currentSelectedCustomerId,
      "includeBS": false,
      "includeES": true,
      "includeActiveGroupsOnly": true
    };


    this.restService.post(environment.baseURI + environment.endpoints.openStatementComponent, paramsData).subscribe((val: any) => {
      val.RetrieveCustomerConsolidationFinancialStatementHeadersResult.forEach(rb => {
        if (rb.FinancialStatements && rb.FinancialStatements.length > 0) {
          this.consolidationTreeNode.push({
            id: rb.Group.GroupBID,
            desc: rb.Group.GroupNameTxt.split(", ")[1],
            data: rb.Group,
            nodeLevel: 0,
            children: rb.FinancialStatements.map(x => <TreeNodeFinancialConsolidation>{
              data: x,
              id: x.FinancialStatementBID,
              nodeLevel: 1,
              children: [],
              isChecked: false,
              desc: x.FinancialStatementEndDte,
              desc2: x.FinancialStatementDesc,
              desc3: x.FinancialStatementStartDte,
              icon: true,
              iconType: x.FinancialStatementSubTypeCde,
              iconPath: '',
              parantid: rb.Group.GroupBID
            })
          })
        }
      })
    });
  }

  //get benchmark
  loadLookUps() {
    this.store.pipe(select(commonSelector))
      .subscribe(res => {
        this.lookUps = res.GetLookupsResult?.length && res.GetLookupsResult;
      })
  }

  //get benchmark details for tab
  getBenchmarkData() {
    let paramsData: any = { "selectedFinancialStatementBIDs": [] };
    this.restService.post(environment.baseURI + AppConstant.endpoints.retrieveBenchmarkNodes, paramsData)
      .subscribe(data => {
        let benchamrkLookUp = this.lookUps.find(it => it.Table.TableCde == CachedLookups.tlkpBenchmarkIndustryTemplate)
        this.tlkpBenchmarkIndustryTemplate = benchamrkLookUp?.LookupData;
        let groubedByBenchmarkIndustryTemplateCde = this.groupBy(data.RetrieveBenchmarkNodesResult.BenchmarkGroupNodes, 'BenchmarkIndustryTemplateCde');

        paramsData = {
          "benchmarkIDs": data.RetrieveBenchmarkNodesResult.BenchmarkNodes.map(val => val.BenchmarkID),
          "financialStatementType": FinancialStatementSubTypes.BalanceSheet,
          "Error": []
        };

        let lastLeafnodes: TreeNode[] = [];
        let benchmarkLastLeafNodeData = this.restService.post(environment.baseURI + AppConstant.endpoints.retrieveBenchmarkStatementNodesAll, paramsData).subscribe((e: any) => {

          let fhsCollections = e.RetrieveBenchmarkStatementNodesAllResult.flatMap((elem) => elem.FinancialSheetHeaders)


          lastLeafnodes = fhsCollections.map(leafchild => <TreeNode>{
            data: leafchild,
            id: leafchild.FinancialStatementBID,
            nodeLevel: 3,
            children: [],
            desc: leafchild.FinancialStatementEndDte,
            desc2: leafchild.FinancialStatementDesc,
            desc3:leafchild.FinancialStatementStartDte,
            icon: true,
            iconType: leafchild.FinancialStatementSubTypeCde,
            iconPath: "",
            parantid: leafchild.DefaultBenchmarkID,
            parent: leafchild
          });

          this.benchmarkIndustryTreeNodes = [];

          for (let key in groubedByBenchmarkIndustryTemplateCde) {
            let industryTemplate = this.tlkpBenchmarkIndustryTemplate.find((x) => parseInt(x.Cde) === parseInt(key));
            let industryTemplatesData = this.LoadBenchmarkNode(this.tlkpBenchmarkIndustryTemplate, data, key, lastLeafnodes, ...groubedByBenchmarkIndustryTemplateCde[key]);

            this.benchmarkIndustryTreeNodes.push({
              data: industryTemplate,
              id: parseInt(industryTemplate?.Cde),
              nodeLevel: 0,
              children: industryTemplatesData,
              desc: industryTemplate?.Desc,
              icon: false,
              iconPath: "",
              parantid: 0
            });
          }

          benchmarkLastLeafNodeData.unsubscribe();
          this.benchmarkIndustryTreeNodes.sort((a, b) => a.desc < b.desc ? -1 : a.desc > b.desc ? 1 : 0);
        })
      });
  }

  LoadBenchmarkNode(tlkpBenchmarkIndustryTemplate: any, data: any, key: string, lastLeafnodes: TreeNode[], ...element): TreeNode[] {
    let benchmarkIndustryTreeNode: TreeNode[] = [];
    for (let e in element) {
      let nodes: any[] = [];
      let _d = data.RetrieveBenchmarkNodesResult.BenchmarkNodes.filter((bn) => bn.BenchmarkGroupBID === element[e].BenchmarkGroupBID)
      _d?.length && _d.forEach(ele => {
        nodes.push({
          data: ele,
          id: ele.BenchmarkID,
          nodeLevel: 2,
          children: lastLeafnodes.filter(x => x.parantid === ele.BenchmarkID),
          desc: ele.BenchmarkDesc,
          icon: false,
          iconPath: "",
          parantid: ele.BenchmarkGroupBID,
        });
      });

      benchmarkIndustryTreeNode.push({
        data: {
          BenchmarkGroupHeader: e,
          BenchmarkNodes: nodes
        },
        id: parseInt(element[e].BenchmarkGroupBID),
        nodeLevel: 1,
        children: nodes,
        desc: element[e].BenchmarkGroupName,
        icon: false,
        iconPath: ""
      });
    }
    return benchmarkIndustryTreeNode;
  }

  groupBy = function (xs, key) {
    return xs.reduce(function (rv, x) {
      (rv[x[key]] = rv[x[key]] || []).push(x);
      return rv;
    }, {});
  };

  /*this method call in our button click and get the name of the button
  and perform an action on the basis of the name*/
  btnClickEvent (event) {
    const controlName = event;
  }

  handleSelection(item, tabName) {
    if (item.desc2 && item.id) {
      item = { name: item.desc2, id: item.id, startDate: item.desc, type: 'Earning Statement', hide: !item.hide }
    }
  }


}
