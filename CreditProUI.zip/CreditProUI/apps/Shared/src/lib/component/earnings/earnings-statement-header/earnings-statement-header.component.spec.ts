import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EarningsStatementHeaderComponent } from './earnings-statement-header.component';

describe('EarningsStatementHeaderComponent', () => {
  let component: EarningsStatementHeaderComponent;
  let fixture: ComponentFixture<EarningsStatementHeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EarningsStatementHeaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EarningsStatementHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
