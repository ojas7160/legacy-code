import { Component, ElementRef, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { WindowRef } from '@progress/kendo-angular-dialog';
import { environment } from 'apps/CreditPro/src/environments/environment';
import { rotatedState, slide } from '../../../animations/animations';
import { DcComment } from '../../../models/comment';
import { ErrorDesc, ErrorObj } from '../../../models/errorDescription';
import { KendoModalService, RestService, SelectedCustomerService } from '../../../services';
import { CommentEditor } from '../../common/comments-editor/comments-editor.component';
import { EarningCopyStatementPopupComponent } from '../../earning-copy-statement-popup/earning-copy-statement-popup.component';
import { EarningsLinkStatementComponent } from '../earnings-link-statement/earnings-link-statement.component';

@Component({
  selector: 'uc-earnings-statement-projection',
  templateUrl: './earnings-statement-projection.component.html',
  styleUrls: ['./earnings-statement-projection.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: [rotatedState, slide]
})
export class EarningsStatementProjectionComponent implements OnInit {
  fControlName: string;
  displayError: string | undefined;
  newEditProjESForm: FormGroup;
  errorDesc: ErrorDesc[];
  includeDetail:boolean;
  fControlError: "";
  errorObj: ErrorObj[] = [];
  submitted: boolean;
  public startDate: Date = new Date();
  public endDate: Date = new Date();
  selectedCustomerBid;
  showIcon: boolean;
  sumDesc_state = 'default';
  custFacCmmnt_state = 'default';
  sumDesc_slider = "enter";
  custFacCmmnt_slider = "enter";
  comment: DcComment;
  private popupRef;
  copyPopUpRef;
  openingBSData:Array<any>=[
    {
     CustomerBID: -1,
     CustomerTaskBID: -1,
     CustomerTaskCde: -1,
     FinancialStatementBID: -1, 
     FinancialStatementDesc: 'Select opening balance sheet',
     FinancialStatementEndDte: '',
     FinancialStatementStartDte: '',
     FinancialStatementSubTypeCde: -1,
     LastViewedDate: '',
     OwnerUserID: -1,
     TaskDescription: ''
  }
  ];

  closingBSData: any={
   CustomerBID: -1,
   CustomerTaskBID: -1,
   CustomerTaskCde: -1,
   FinancialStatementBID: -1, 
   FinancialStatementDesc: '',
   FinancialStatementEndDte: 'Select closing balance sheet',
   FinancialStatementStartDte: '',
   FinancialStatementSubTypeCde: -1,
   LastViewedDate: '',
   OwnerUserID: -1,
   TaskDescription: ''
}

public defaultOpenBSList: { FinancialStatementDesc: string; CustomerTaskBID: string } = {
  FinancialStatementDesc: "Select opening balance sheet",
  CustomerTaskBID: "-1",
};

public defaultClosingBSList: { FinancialStatementDesc: string; CustomerTaskBID: string } = {
  FinancialStatementDesc: "Select closing balance sheet",
  CustomerTaskBID: "-1",
}; 
  // closeDailog: boolean;
  public toggleLinkArrowStyle = "<span class='k-icon k-i-arrow-60-right pl-2'></span>";
  public typeList:Array<{ text: string; value: number }> = [
    { text: "Projection(Advanced)", value: 2 },
    { text: "Projection(Simple)", value: 3 },
  ];

  public averageValuesList:Array<{ text: string; value: number }> = [
    { text: "Cash", value: 2 },
    { text: "Accrual", value: 3 },
  ];

  public projValueHeldList:Array<{ text: string; value: number }> = [
    { text: "Modified", value: 1 },
    { text: "Adjustment", value: 2 },
    { text: "Percent", value: 3 },
  ];

  map = new Map<string, string>();
  showIncludeInAverage: boolean = false;
  
  constructor(private fb: FormBuilder, private kendoModalService: KendoModalService,private windowRef:WindowRef,
    private restService: RestService, private selectedCustomerService: SelectedCustomerService) { }

  ngOnInit(): void {
    this.selectedCustomerBid = this.selectedCustomerService.getCurrentSelectedCustomer2().customerId;
    this.createFormGroup();
    this.initializeFormLoad();
  }

  createFormGroup() {
    this.newEditProjESForm = this.fb.group({
      projLabel: ['', [Validators.required, Validators.maxLength(5)]],
      startDate: [this.startDate, Validators.required],
      endDate: [this.endDate, Validators.required],
      includeDetails: [this.includeDetail]

      // type: ['', Validators.required],
      // activeTemplate: ['', Validators.required]
    });
  }

  validateControl(params: any) {
    if (params.response == true) {
      this.fControlName = params.control;
      let fControldesc = this.map.get(params.control);
      this.setErrorDesc(params.control, fControldesc, params.response);
    }
    else {
      this.fControlError = "";
      params.control == 'startDate' ? this.displayError = "" : '';
    }
  }

  setErrorDesc(control: any, desc: string, fControlValue?: boolean, dateError?: boolean) {
    let _errorObj;
    if (this.newEditProjESForm.controls[control].hasError('required') || fControlValue) {
      _errorObj = {
        key: this.map.get(control),
        value: `${desc} is required for: ${this.errorDesc[0].RequiredFieldTypeDesc}.`
      }
      fControlValue ? this.fControlError = _errorObj.value : this.errorObj.push(_errorObj);
      if (control == 'bsDate') {
        this.displayError = `${desc} is not in the correct format. The correct format is: Date (e.g. "02/02/1993")`;
      }
      else if (dateError == false && control == 'Balance Sheet Date') {
        this.displayError = "";
      }

    }

    else if (this.newEditProjESForm.controls[control].hasError('maxlength')) {
      _errorObj = {
        key: this.map.get(control),
        value: `${desc} must be : ${this.newEditProjESForm.controls[control].errors.maxlength.requiredLength} character(s) long.`
      }
      this.errorObj.push(_errorObj);
    }
  }

  get f() { return this.newEditProjESForm.controls; }

  openComentEditor(category: string) {
    const dialog: any = this.kendoModalService.open('window', 'commentEditor', CommentEditor);
    dialog.result.subscribe((response) => {
      if (response.action = "Ok")
        this.saveComment(category, response);
    });
  }

  saveComment(category, response: any) {
    this.showIcon = true;
    if (category == 'SD') {
      this.sumDesc_slider = 'left';
      this.comment = {
        Action: null,
        Comment: response.comment,
        CommentBID: null,
        CommentPlainTxt: response.action,
        TableName: null,
        UserID: 1931
      }
    }
    else {
      this.custFacCmmnt_slider = 'left';
    }
  }

  deleteSDComment(param: any) {
    this.sumDesc_slider = "enter";
  }

  toggleIcon(category: string) {
    if (category == 'SD') {
      this.sumDesc_state = (this.sumDesc_state === 'default' ? 'rotated' : 'default');
      this.sumDesc_slider = this.sumDesc_slider === 'left' ? 'right' : 'left';
    }else {
      this.custFacCmmnt_state = (this.custFacCmmnt_state === 'default' ? 'rotated' : 'default');
      this.custFacCmmnt_slider = this.custFacCmmnt_slider === 'left' ? 'right' : 'left';
    }
  }

  deleteCFComment(param: any) {
    this.custFacCmmnt_slider = "enter";
  }

  getSelectedtype(data:any) {
    if(data.value === 2){
        this.showIncludeInAverage = true;
    } else {
        this.showIncludeInAverage = true;
    }
  }

  closePopUp() {
    this.popupRef ? this.closeAdditionalPopup(this.popupRef) : this.closeAdditionalPopup(this.copyPopUpRef);
    this.popupRef=null;
    this.copyPopUpRef=null;
    this.windowRef.close();
  }

  closeAdditionalPopup(refPopUp: any) {
    if (refPopUp) {
      this.kendoModalService.close('popup', refPopUp);
      this.toggleLinkArrowStyle = "<span class='k-icon k-i-arrow-60-right pl-2'></span>";
    }

  }

  copyEarningForm(copyEarningComponentAnchorFirst: ElementRef) {
    let params: any;

    params = {
      anchor: copyEarningComponentAnchorFirst,
      anchorAlign: {
        horizontal: "right", vertical: "top"
      },
      popupAlign: {
        horizontal: 'left', vertical: 'top', margin: '50px'
      }
    }
    
    if (this.copyPopUpRef) {
     this.closeAdditionalPopup(this.copyPopUpRef);
      this.copyPopUpRef = null;
    } else {
      this.closeAdditionalPopup(this.popupRef);
      this.popupRef = null;
      this.copyPopUpRef = this.kendoModalService.open('popup',
      'copyEarningForm',
      EarningCopyStatementPopupComponent,
      params);
    }
  }

  toggleLinkEarningStatements(linkEarningAnchor: ElementRef) {
    let params: any;
    params = {

      anchor: linkEarningAnchor,
      anchorAlign: {
        horizontal: "right", vertical: "top"
      },
      popupAlign: {
        horizontal: 'left', vertical: 'top', margin: '50px'
      }
    }
    if (this.popupRef) {
      this.closeAdditionalPopup(this.popupRef);
      this.popupRef = null;
    } else {
      this.closeAdditionalPopup(this.copyPopUpRef);
      this.copyPopUpRef = null;
      this.popupRef = this.kendoModalService.open('popup',
        'earningsStatementNewLinkForm',
        EarningsLinkStatementComponent,
        params);
      this.toggleLinkArrowStyle = "<span class='k-icon k-i-arrow-60-left pl-2'></span>";
    }

	}

  initializeFormLoad(): void {
    this.retreiveBalanceSheets();
  }

  retreiveBalanceSheets(): void {
    this.restService.post(environment.baseURI + environment.endpoints.retrieveBalanceSheet, { customerBID:this.selectedCustomerBid, howMany: 999, includeConsolidations: true, includeProjections: true })
    .subscribe(
      data => {
        // this.openingBSData = data
      }
    )
  }

  submit (event?) {
    this.submitted = true
    // this.tooltip?.hide()
    // this.validateAll()
    // if (this.newEditBSForm.invalid) {
    //   return
    // }
    // this.dataSaved = true
    // this.close()
  }
}
