import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EarningsStatementProjectionComponent } from './earnings-statement-projection.component';

describe('EarningsStatementProjectionComponent', () => {
  let component: EarningsStatementProjectionComponent;
  let fixture: ComponentFixture<EarningsStatementProjectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EarningsStatementProjectionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EarningsStatementProjectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
