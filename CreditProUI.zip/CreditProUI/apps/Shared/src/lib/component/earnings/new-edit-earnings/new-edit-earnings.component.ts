import { Component, OnInit, ElementRef, ViewChild, ViewEncapsulation, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { EarningCopyStatementPopupComponent } from '../../earning-copy-statement-popup/earning-copy-statement-popup.component'
import { RestService, KendoModalService, SelectedCustomerService } from '../../../services';
import { environment } from 'apps/CreditPro/src/environments/environment';
import { EarningsLinkStatementComponent } from '../earnings-link-statement/earnings-link-statement.component';
import { ShareStatementDataService } from '../../../services/earnings/shareStatementDataService'
import { EMPTY, Observable, Subject, Subscription } from 'rxjs';
import { WindowCloseResult, WindowRef } from '@progress/kendo-angular-dialog';
import { DTOAction, Icons } from '../../../enum'
import { DateTransformPipe } from '../../../pipes/dateTransform.pipe'
import { ErrorDesc, ErrorObj } from '../../../models/errorDescription';
import { CommentEditor } from '../../common/comments-editor/comments-editor.component';
import { DcComment } from '../../../models/comment';
import { UtilityService } from '../../../services/utility/utility.service';
import { CachedLookups } from '../../../enum/cachedLookups';
import { ListControl } from '../../../models/listControl';
import { FinancialStatementTypes } from '../../../enum/financialStatementTypes';
import { LookupTable, LookupTables } from '../../../models/lookupTables';
import { FinancialSheetHeader } from '../../../models/financialSheetHeader';
import { TooltipDirective } from '@progress/kendo-angular-tooltip';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DateValidator } from '../../../customValiadtions/dateValidation';
import * as moment from 'moment';
import { AppConstant } from '../../../constants/app-constants';
import { CommonService } from '../../../services/common/common.service';

@Component({
  selector: 'lib-new-edit-earnings',
  templateUrl: './new-edit-earnings.component.html',
  styleUrls: ['./new-edit-earnings.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class NewEditEarningsComponent implements OnInit, OnDestroy {
  public _icons = Icons;
  title = 'FPI';
  copyPopUpRef;
  fControlName: string;
  lookupTable: LookupTable[];
  lookupTables: LookupTables;
  public opened = true;

  public dataSaved = false;
  newEditEarningsForm: FormGroup;
  public earningStatement: any = 'earningStatement';
  errors: Array<string> = [];
  private popupRef;
  public toggleLinkArrowStyle = '<span class=\'k-icon k-i-arrow-60-right pl-2\'></span>';
  errorDesc: ErrorDesc[];
  errorObj: ErrorObj[] = [];
  submitted: boolean;
  comment: DcComment;
  showSumDescIcon: boolean;
  showCFSIcon: boolean;
  cFSDelRoatated: boolean;
  sumDescDelRoatated: boolean;
  spanClass: string = '<span class=\'k-icon k-i-arrow-60-right pl-2\'></span>';
  public value: Date = new Date();
  typeList: ListControl[] = [];
  activeTemplateList: ListControl[] = [];
  finQualityList: ListControl[] = [];
  sourceDataList: ListControl[] = [];
  selectedItem;


  closeDailog: boolean;

  messageShow = false;

  @ViewChild('copyEarningComponentAnchorFirst') public copyEarningComponentAnchorFirst: ElementRef;
  @ViewChild('linkEarningAnchor') public linkEarningAnchor: ElementRef;
  unsubscribe$: Subject<boolean> = new Subject();
  earningstatement: any;
  earingsOpeningBSData: FinancialSheetHeader[] = [];
  earingsClosingOpeningBSData: FinancialSheetHeader[] = [];
  public selectedEaringsOpeningBSData: any;
  public selectedEaringsClosingOpeningBSData: any;
  // eslint-disable-next-line new-cap
  newEarningStatement: FinancialSheetHeader;
  public defaultOpenBSList: { FinancialStatementDesc: string; CustomerTaskBID: string } = {
    FinancialStatementDesc: 'Select opening balance sheet',
    CustomerTaskBID: '-1'
  };

  public defaultClosingBSList: { FinancialStatementDesc: string; CustomerTaskBID: string } = {
    FinancialStatementDesc: 'Select closing balance sheet',
    CustomerTaskBID: '-1'
  };
  selectedType: any;
  selectedCustomerBid: any;
  imgSDActivate: boolean = false;
  imgCFCActivate: boolean = false;
  sdDelBtn: boolean = false;
  cfcDelBtn: boolean = false;
  sdComment: any;
  cfcComment: any;
  map = new Map<string, string>();
  fControlError: string | undefined;
  @ViewChild(TooltipDirective) tooltip: TooltipDirective;
  @ViewChild('first') first: ElementRef;
  @ViewChild('second') second: ElementRef;
  @ViewChild('third') third: ElementRef;
  @ViewChild('fourth') fourth: ElementRef;
  @ViewChild('fifth') fifth: ElementRef;
  earningsDataSub: Subscription;

  lastTouchUserInfo: Observable<any>;
  public startDate: Date;
  public endDate: Date;
  earninglable: string = '';
  selectedSourceData;
  selectedFinanceQuality;
  selectedActiveTemplate;
  selectedOpeningBS;
  selectedClosingBs

  constructor(private utiltyService: UtilityService, private router: Router,
    private restService: RestService,
    private kendoModalService: KendoModalService,
    private dataservice: ShareStatementDataService,
    private windowRef: WindowRef,
    private selectedCustomerService: SelectedCustomerService,
    private fb: FormBuilder,
    private utilService: UtilityService, private commonService: CommonService) {


  }

  ngOnInit(): void {
    this.selectedCustomerBid = this.selectedCustomerService.getCurrentSelectedCustomer2().customerId;
    this.getESLookUps();
    this.validationRequiements();
    this.createFormGroup();
    this.copyStatement();
    this.setWindowTitle();
    this.retrieveOpeningClosingBS();
    this.setEarningsValues();
  }

  copyStatement() {
    this.earningsDataSub = this.dataservice.getProfileObs().subscribe(earningstatement => {
      this.earningstatement = earningstatement;
      if (this.earningstatement) {
        const filterPipe = new DateTransformPipe();
        this.startDate = new Date(filterPipe.transform(this.earningstatement.FinancialStatementStartDte, AppConstant.dateFormat));
        this.startDate.setFullYear(this.startDate.getFullYear() + 1);
        this.endDate = new Date(filterPipe.transform(this.earningstatement.FinancialStatementEndDte, AppConstant.dateFormat));
        this.endDate.setFullYear(this.endDate.getFullYear() + 1);
        this.selectedSourceData = this.earningstatement.FinancialSourceTypeCde;
        this.selectedFinanceQuality = this.earningstatement.FinancialQualityCde;
        this.selectedActiveTemplate = this.earningstatement.FinancialStatementTemplateCde;
        this.selectedOpeningBS = this.earningstatement.OpeningBSFinancialStatementBID ? this.earningstatement.OpeningBSFinancialStatementBID : ''
        this.selectedClosingBs = this.earningstatement.ClosingBSFinancialStatementBID ? this.earningstatement.ClosingBSFinancialStatementBID : ''

        this.newEditEarningsForm.patchValue({
          sourceData: this.selectedSourceData,
          endDate: this.endDate,
          startDate: this.startDate,
          type: this.selectedType,
          activeTemplate: this.selectedActiveTemplate
        });

        this.selectedEaringsOpeningBSData = {
          FinancialStatementBID: this.earningstatement.OpeningBSFinancialStatementBID,
          FinancialStatementEndDte: this.earningstatement.FinancialStatementEndDte,
          FinancialStatementDesc: this.earningstatement.FinancialStatementDesc,
          FinancialStatementStartDte: this.earningstatement.FinancialStatementStartDte,
          FinancialStatementSubTypeCde: this.earningstatement.FinancialStatementSubTypeCde,
          FinancialStatementTemplateCde: this.earningstatement.FinancialStatementTemplateCde,
          IsDefault: false
        };

        this.selectedEaringsClosingOpeningBSData = {
          FinancialStatementBID: this.earningstatement.ClosingBSFinancialStatementBID,
          FinancialStatementEndDte: this.earningstatement.FinancialStatementEndDte,
          FinancialStatementDesc: this.earningstatement.FinancialStatementDesc,
          FinancialStatementStartDte: this.earningstatement.FinancialStatementStartDte,
          FinancialStatementSubTypeCde: this.earningstatement.FinancialStatementSubTypeCde,
          FinancialStatementTemplateCde: this.earningstatement.FinancialStatementTemplateCde,
          IsDefault: false
        };
      }
    });
  }

  updateESForm(val) {
    this.selectedActiveTemplate = val.FinancialStatementTemplateCde;
    this.selectedSourceData = val.FinancialSourceTypeCde;
    this.selectedFinanceQuality = val.FinancialQualityCde;
    let updatedDate = this.modifyDate(val.FinancialStatementStartDte);
    this.startDate = updatedDate;
    updatedDate = this.modifyDate(val.FinancialStatementEndDte);
    this.endDate = updatedDate;
    this.newEditEarningsForm.patchValue({
      date: updatedDate,
      spouseStmt: val.CombinedStatementWithSpouseInd,
      collateral: val.CollateralStatementInd
    });
  }

  modifyDate(date) {
    const filterPipe = new DateTransformPipe();
    const d = new Date(filterPipe.transform(date, AppConstant.dateFormat));
    return new Date(d.getFullYear() + 1, d.getMonth(), d.getDate());
  }

  setEarningsValues(): void {
    if (this.earningstatement != null) {
      const filterPipe = new DateTransformPipe();
      this.startDate = new Date(filterPipe.transform(this.earningstatement.FinancialStatementStartDte, AppConstant.dateFormat));
      this.endDate = new Date(filterPipe.transform(this.earningstatement.FinancialStatementEndDte, AppConstant.dateFormat));
      this.newEditEarningsForm.setValue({
        sourceData: this.earningStatement?.FinancialSourceTypeCdeField,
        labelValue: this.earningStatement?.FinancialStatementDescField,
        endDate: this.endDate,
        startDate: this.startDate,
        type: this.earningStatement?.FinancialStatementSubTypeCdeField,
        activeTemplate: this.earningStatement?.FinancialStatementTemplateCdeField,
        combStat: this.earningStatement?.CombinedStatementWithSpouseIndField,
        finQty: this.earningStatement?.FinancialQualityCdeField,
        earingsopeningBSData: this.earningStatement?.OpeningBSFinancialStatementBIDField,
        earingsclosingBSData: this.earningStatement?.ClosingBSFinancialStatementBIDField
      });
    }
  }



  setWindowTitle() {
    this.utilService.dialogStatus.subscribe((response) => {
      this.closeDailog = response;
      if (this.closeDailog) { this.popupRef ? this.closeAdditionalPopup(this.popupRef) : this.closeAdditionalPopup(this.copyPopUpRef) }
    })
  }

  createFormGroup() {
    this.newEditEarningsForm = this.fb.group({
      sourceData: ['', Validators.required],
      labelValue: ['', Validators.compose([Validators.required, Validators.maxLength(100)])],
      endDate: ['', Validators.compose([Validators.required, DateValidator.dateValidator])],
      startDate: ['', Validators.compose([Validators.required, DateValidator.dateValidator])],
      type: [this.selectedType, Validators.required],
      activeTemplate: ['', Validators.required],
      combStat: [true],
      finQty: [],
      earingsopeningBSData: [],
      earingsclosingBSData: []
    })
  }


  get f() { return this.newEditEarningsForm.controls }

  copyEarningForm(copyEarningComponentAnchorFirst: ElementRef) {
    const params: any = {
      anchor: copyEarningComponentAnchorFirst,
      anchorAlign: {
        horizontal: 'right', vertical: 'top'
      },
      popupAlign: {
        horizontal: 'left', vertical: 'top', margin: '50px'
      }
    };

    if (this.copyPopUpRef) {
      this.closeAdditionalPopup(this.copyPopUpRef);
      this.copyPopUpRef = null;
    } else {
      this.closeAdditionalPopup(this.popupRef);
      this.popupRef = null;
      this.copyPopUpRef = this.kendoModalService.open('popup',
        'copyEarningForm',
        EarningCopyStatementPopupComponent,
        params);

      this.spanClass = '<span class=\'k-icon k-i-arrow-60-left pl-2\'></span>';
      let instance = this.copyPopUpRef.content.instance    
      instance.page = "Earning"
      
    }



    this.copyPopUpRef.content.instance.onFinancialSelected.subscribe(val => {
      this.updateESForm(val);
    });
  }



  toggleLinkEarningStatements(linkEarningAnchor: ElementRef) {
    const params: any = {
      anchor: linkEarningAnchor,
      anchorAlign: {
        horizontal: 'right', vertical: 'top'
      },
      popupAlign: {
        horizontal: 'left', vertical: 'top', margin: '60px'
      }
    };
    if (this.popupRef) {
      this.closeAdditionalPopup(this.popupRef);
      this.popupRef = null;
    } else {
      this.closeAdditionalPopup(this.copyPopUpRef);
      this.copyPopUpRef = null;
      this.popupRef = this.kendoModalService.open('popup',
        'earningsStatementNewLinkForm',
        EarningsLinkStatementComponent,
        params);
      this.toggleLinkArrowStyle = '<span class=\'k-icon k-i-arrow-60-left pl-2\'></span>';
    }
  }

  ngOnDestroy() {
    if (this.popupRef) {
      this.closeAdditionalPopup(this.popupRef);
      this.popupRef = null;
    } else if (this.copyPopUpRef) {
      this.closeAdditionalPopup(this.copyPopUpRef);
      this.popupRef = null;
    }
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
    this.dataservice.setProfileObs(null);
    this.dataservice.setEarningsLinkedStatment(null);
  }

  validateAll() {
    this.errorObj.length = 0
    Object.keys(this.newEditEarningsForm.controls).forEach((key, index) => {
      if (this.errorDesc[index]) {
        this.setErrorDesc(key, this.errorDesc[index].DictionaryObjectDesc);
      }
    })
  }

  onSubmit(event?: any): void {
    this.submitted = true;
    this.tooltip?.hide();
    this.validateAll();
    let multiYearAvgValidation = this.multiYearValidation();
    if (this.newEditEarningsForm.invalid || multiYearAvgValidation) {
      return
    } else {
      this.mapFormDataToSave();
      this.dataservice.setNewEarningStatment(this.newEarningStatement);
      this.router.navigate(['/earnings']);
      this.windowRef.close();
    }
    this.dataSaved = true;
    this.earningWindowClose();
  }

  //added by maninder kalra
  multiYearValidation() {
    let _errorObj; let isValid = false;
    const data: Observable<any> = this.dataservice.getEarningsLinkedStatement();
    data.subscribe(res => {
      if (res) {
        let earning2CusId = res.earnings2 ? (res.earnings2.CustomerBID != 0 ? res.earnings2.CustomerBID : null) : null
        let earning3CusId = res.earnings3 ? (res.earnings3.CustomerBID != 0 ? res.earnings3.CustomerBID : null) : null
        if ((!earning2CusId && earning3CusId) || (earning2CusId && !earning3CusId)) {
          _errorObj = {
            key: 'Multi-Year Average',
            value: 'Multi-Year Average requires two linked statements.'
          }
          let errorKeyFind = this.errorObj.find(x => x.key == 'Multi-Year Average');
          !errorKeyFind ? this.errorObj.push(_errorObj) : isValid = true;
        }
      }
    })
    return isValid;
  }

  public earningWindowClose() {
    this.windowRef.close()
  }

  closeAdditionalPopup(refPopUp: any) {
    if (refPopUp) {
      this.kendoModalService.close('popup', refPopUp);
      this.toggleLinkArrowStyle = '<span class=\'k-icon k-i-arrow-60-right pl-2\'></span>';
      this.spanClass = '<span class=\'k-icon k-i-arrow-60-right pl-2\'></span>';
    }
  }

  openFile() {
    const uploder = document.getElementById('fileUpload');
    uploder.click()
  }

  handle(e) {
  }

  openComentEditor(category: string) {
    const dialog: any = this.kendoModalService.open('window', 'commentEditor', CommentEditor)
    if (category === 'SD' && this.sdComment) {
      dialog.content.instance.value = this.sdComment.Comment;
    }
    if (category === 'CFC' && this.cfcComment) {
      dialog.content.instance.value = this.cfcComment.Comment;
    }
    dialog.result.subscribe((response) => {
      if (response.action == 'OK') { this.saveComment(category, response) }
    })
  }

  saveComment(category, response: any) {
    if (category === 'SD') {
      this.imgSDActivate = true;
      this.sdComment = {
        Action: null,
        Comment: response.comment,
        CommentBID: null,
        CommentPlainTxt: response.action,
        TableName: null,
        UserID: 1931
      }
    } else {
      this.imgCFCActivate = true;
      this.cfcComment = {
        Action: null,
        Comment: response.comment,
        CommentBID: null,
        CommentPlainTxt: response.action,
        TableName: null,
        UserID: 1931
      }
    }
  }

  showDeletBtn(param) {
    if (param === 'SD') {
      this.sdDelBtn = !this.sdDelBtn;
    }
    else {
      this.cfcDelBtn = !this.cfcDelBtn;
    }
  }

  deleteComment(param) {
    if (param === 'SD') {
      this.sdComment = null;
      this.imgSDActivate = false;
      this.sdDelBtn = false;
    }
    else {
      this.cfcComment = null;
      this.imgCFCActivate = false;
      this.cfcDelBtn = false;
    }
  }

  fetchEsControlDetails(lookUpDetails: any[]) {
    lookUpDetails.forEach((element) => {
      this.fillEsControls(element)
    })
    this.activeTemplateList = this.activeTemplateList.sort((a, b) => (a.text < b.text ? -1 : 1))
  }

  fillEsControls(es: any) {
    switch (es.Table.TableName != '') {
      case (es.Table.TableCde == CachedLookups.tlkpFilteredFinancialStatementSubType): {
        const list = es.LookupData.find(x => x.Cde == Number(FinancialStatementTypes.Earnings))
        this.typeList.push(new ListControl(list.Desc, list.Cde))
        this.selectedItem = list.Cde
        this.selectedType = list.Cde;
        break;
      }

      case (es.Table.TableCde == Number(CachedLookups.tlkpFinancialStatementTemplate)): {
        es.LookupData.forEach((element, index) => {
          if (element.ExtendedValues.find(x => x.Value == FinancialStatementTypes.EarningsStatement.toString())) {
            this.activeTemplateList.push(new ListControl(element.Desc, element.Cde));
          }
        });
        break;
      }

      case (es.Table.TableCde == Number(CachedLookups.tlkpFinancialQuality)): {
        es.LookupData.forEach((element) => {
          this.finQualityList.push(new ListControl(element.Desc, element.Cde));
        });
        break;
      }

      case (es.Table.TableCde == Number(CachedLookups.tslkpFinancialSourceType)): {
        es.LookupData.forEach((element) => {
          this.sourceDataList.push(new ListControl(element.Desc, element.Cde));
        });
        break;
      }

      default:
        break
    }
  }

  getESLookUps(): void {
    this.lookupTable = [{
      Action: DTOAction.Nothing,
      UserID: 0,
      TableCde: 49,
      TableName: 'tlkpFilteredFinancialStatementSubType',
      EmptyOK: false
    },
    {
      Action: DTOAction.Nothing,
      UserID: 0,
      TableCde: 21,
      TableName: 'tlkpFinancialStatementTemplate',
      EmptyOK: false
    }, {
      Action: DTOAction.Nothing,
      UserID: 0,
      TableCde: 27,
      TableName: 'tslkpFinancialSourceType',
      EmptyOK: false
    }, {
      Action: DTOAction.Nothing,
      UserID: 0,
      TableCde: 26,
      TableName: 'tlkpFinancialQuality',
      EmptyOK: false
    }
    ]

    this.lookupTables = {
      lookupTables: this.lookupTable
    }
    this.restService.post(environment.commonBaseURI + environment.endpoints.commonBaseURLPrefix + environment.endpoints.adminOptionsGetUserClaimsURL, this.lookupTables)
      .subscribe(
        result => {
          const esLookUPDetails: any = result.GetLookupsResult;
          this.fetchEsControlDetails(esLookUPDetails);
        }
      )
  }

  retrieveOpeningClosingBS(): void {
    this.restService.post(environment.baseURI + environment.endpoints.retrieveEarningsStatementHeaderByID, { customerBID: this.selectedCustomerBid, financialStatementBID: null, groupBID: null })
      .subscribe(
        result => {
          this.earingsOpeningBSData = result.RetrieveEarningsStatementHeaderByIDResult.AvailableBalanceSheetHeaders;
          this.earingsClosingOpeningBSData = result.RetrieveEarningsStatementHeaderByIDResult.AvailableBalanceSheetHeaders;
          let bSHeaderPriorBS = new FinancialSheetHeader();
          bSHeaderPriorBS.IsDefault = true
          this.earingsClosingOpeningBSData.unshift(bSHeaderPriorBS);
        }
      )
  }

  validateControl(params: any): void {
    if (params.control == 'startDate' && params.date != '' && params.date != null) {
      const filterPipe = new DateTransformPipe();
      this.endDate = new Date(filterPipe.transform(params.date, AppConstant.dateFormat));
      this.endDate.setFullYear(this.endDate.getFullYear() + 1);
      this.endDate.setDate( this.endDate.getDate() - 1 );
    }
    if (params.response == true) {
      this.fControlName = params.control;
      const fControldesc = this.map.get(params.control);
      this.setErrorDesc(params.control, fControldesc, params.response);
      this.showErrors(this.fControlName);
    } else {
      this.fControlError = '';
      this.tooltip?.hide();
    }
  }

  setErrorDesc(control: any, desc: string, fControlValue?: boolean) {
    let _errorObj
    if (this.newEditEarningsForm.controls[control].hasError('dateValidator')) {
      this.fControlError = `${desc} is not in the correct format. The correct format is: Date (e.g. "02/02/1993")`
    } else if (this.newEditEarningsForm.controls[control].hasError('required') || fControlValue) {
      _errorObj = {
        key: this.map.get(control),
        value: `${desc} is required for: ${this.errorDesc[0].RequiredFieldTypeDesc}.`
      }
      fControlValue ? this.fControlError = _errorObj.value : this.errorObj.push(_errorObj)
    } else if (this.newEditEarningsForm.controls[control].hasError('maxlength')) {
      _errorObj = {
        key: this.map.get(control),
        value: `${desc} must be : 1-${this.newEditEarningsForm.controls[control].errors.maxlength.requiredLength} character(s) long.`
      }
      this.errorObj.push(_errorObj)
    }
  }

  showErrors(error) {
    this.tooltip?.hide()

    switch (error != '') {
      case error == 'startDate':
        this.tooltip.show(this.first);
        break
      case error == 'endDate':
        this.tooltip.show(this.second);
        break
      case error == 'type':
        this.tooltip.show(this.third);
        break
      case error == 'sourceData':
        this.tooltip.show(this.fourth);
        break
      case error == 'activeTemplate':
        this.tooltip.show(this.fifth);
        break

      default:
        break
    }
  }

  validationRequiements(): void {
    const params = {
      applicationCde: 19,
      applicationViewCde: 19,
      customChartOfAccountCde: null
    }
    this.restService.post(environment.commonBaseURI + environment.endpoints.retAppViewRequirements, params)
      .subscribe(
        result => {
          this.errorDesc = result.RetrieveApplicationViewRequirementsResult.ApplicationViewDictionaryObjectRequirements;
          Object.keys(this.newEditEarningsForm.controls).forEach((key, index) => {
            if (this.errorDesc[index]) {
              this.map.set(key, this.errorDesc[index].DictionaryObjectDesc);
            }
          })
        }
      )
  }

  onFinancialStatementHover(id: any): void {
    this.commonService.lastTouchUserInfo(id).subscribe(
      result => {
        this.lastTouchUserInfo = result.RetrieveLastChangedInformationByFinanicalStatementBIDResult;
      });
  }

  mapFormDataToSave() {
    const data: Observable<any> = this.dataservice.getEarningsLinkedStatement();
    const values = Object.values(this.newEditEarningsForm.controls);
    const dateCheck = moment(this.endDate).isAfter(this.startDate);
    this.restService.post(environment.baseURI + environment.endpoints.saveEarningsStatementHeader, { FinancialSheetHeader: this.newEarningStatement, copyEarningsStatement: null })
      .subscribe(response => {
      });

  }

}
