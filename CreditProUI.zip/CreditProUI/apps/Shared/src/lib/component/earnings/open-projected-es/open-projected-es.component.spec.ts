import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OpenProjectedESComponent } from './open-projected-es.component';

describe('OpenProjectedESComponent', () => {
  let component: OpenProjectedESComponent;
  let fixture: ComponentFixture<OpenProjectedESComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OpenProjectedESComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OpenProjectedESComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
