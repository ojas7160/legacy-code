/* eslint-disable no-useless-constructor */
import { Component, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { AppConstant } from '../../constants/app-constants';
import { AppState } from '../../store';
import { gridDataSelector } from '../../store/selectors/grid.selector';
import { cloneDeep } from 'lodash';
import { ShareStatementDataService } from '../../services/earnings/shareStatementDataService'

@Component({
  selector: 'lib-earnings',
  templateUrl: './earnings.component.html',
  styleUrls: ['./earnings.component.scss']
})
export class EarningsComponent implements OnInit {
  earningSubMenu = AppConstant.secondaryMenu.earnings
  columns = [];
  earningData = []
  columnGroupData: any;
  earningstatement: any;
  statementActions = AppConstant.statementActions.earning

  constructor (
    private store: Store<AppState>,
    private dataservice: ShareStatementDataService
  ) { }

  ngOnInit (): void {
    this.dataservice.getNewEarningStatement().subscribe(earningstatement => {
      this.earningstatement = earningstatement
    });

    this.store.pipe(select(gridDataSelector)).subscribe(data => {
      this.columnGroupData = cloneDeep(data.gridData).filter(it => it.type.toLowerCase().includes('earning'))
      if (this.earningstatement !== null) {
        const checkedItem = { name: data.labelValue, id: 232131, startDate: data.FinancialStatementDesc, type: 'Earning Sheet' };
        this.columnGroupData.push(checkedItem);
      }
      this.columns = cloneDeep(data.columnData)
      this.columnGroupData?.length && this.columnGroupData.forEach(it => {
        it.coas = it.coas?.length && it.coas.map(coa => {
          this.columns?.length && this.columns.forEach(column => {
            if (column.id === coa.columnId) {
              coa.columnName = column.dataBindingName
              coa.cellTemplateSelector = column.cellTemplateSelector
            }
          })
          return coa
        })
      })
      this.earningData = this.transform(cloneDeep(data.coa))
      this.columnGroupData = this.columnGroupData?.length && this.columnGroupData.map(it => {
        if (!it.columns || !it.columns.length) {
          it.columns = this.columns.map(it => Object.assign({}, it))
        }
        return it
      })
    });
  }

  transform (coa) {
    return coa?.length && coa.map(chartOfAcc => {
      this.columnGroupData?.length && this.columnGroupData.forEach(statement => {
        chartOfAcc.statementId = statement.id
        chartOfAcc.statementType = statement.type
        statement.coas?.length && statement.coas.forEach(_statement => {
          // chartOfAcc[`${_statement.columnName}${statement.id}`] = ''
          if (chartOfAcc.coaCde === _statement.coaCde) {
            chartOfAcc[`${_statement.columnName}${statement.id}`] = _statement.value
            chartOfAcc.cellTemplateSelector = _statement.cellTemplateSelector
          }
          chartOfAcc[`${_statement.columnName}${statement.id}`] = chartOfAcc[`${_statement.columnName}${statement.id}`] ? chartOfAcc[`${_statement.columnName}${statement.id}`] : ''
          // chartOfAcc.cellTemplateSelector = chartOfAcc.cellTemplateSelector ? chartOfAcc.cellTemplateSelector : 'input'
        })
      })
      if (chartOfAcc.children && chartOfAcc.children.length) {
        chartOfAcc.children = this.transform(chartOfAcc.children)
      }
      return chartOfAcc
    })
  }

  transformCoa (coa) {
    return coa.map(it => {
      this.columns.forEach(column => {
        column.coas && column.coas.length && column.coas.forEach(columnCoa => {
          if (it.coaCde === columnCoa.coaCde) {
            it = Object.assign({}, { ...it, [column.dataBindingName]: columnCoa.value, cellTemplateSelector: columnCoa.cellTemplateSelector })
          }
        })
      })
      if (it.children && it.children.length) {
        it.children = this.transformCoa(it.children)
      }

      return { ...it }
    })
  }

  selectedConsoliadationstmt (data) {
    if (data != null) {
      const checkedItem = { name: data.CustomerTasks.FinancialStatementDesc, id: data.CustomerTasks.CustomerTaskBID, startDate: data.CustomerTasks.FinancialStatementStartDte, type: data.CustomerTasks.TaskDescription };

      if (!data.isChecked) {
        this.columnGroupData.forEach((item, index) => {
          if (item.id === checkedItem.id) {
            this.columnGroupData.splice(index, 1);
          }
        });
      } else {
        this.columnGroupData.push(checkedItem);
      }
    }
  }
}
