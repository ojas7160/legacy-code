/* eslint-disable no-unused-vars */
import { Component, EventEmitter, OnInit, Output, ViewChild, ViewEncapsulation } from '@angular/core';
import { forkJoin, Observable } from 'rxjs';
import { TreeItem } from '@progress/kendo-angular-treeview';
import { DropDownTreeComponent } from '@progress/kendo-angular-dropdowns';
import { environment } from 'apps/CreditPro/src/environments/environment';
import { AppConstant } from '../../../constants/app-constants';
import { FinancialStatementSubTypes } from '../../../enum/financialStatementSubTypes';
import { TreeNode } from '../../../models/balanceSheet/TreeNode';
import { RestService } from '../../../services';
import * as moment from 'moment';
import { EarningStatementHeader } from '../../../models/earningStatementHeader';
import { ShareStatementDataService } from '../../../services/earnings/shareStatementDataService';

@Component({
  selector: 'uc-earnings-link-statement',
  templateUrl: './earnings-link-statement.component.html',
  styleUrls: ['./earnings-link-statement.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EarningsLinkStatementComponent implements OnInit {
  public headerContent = 'This Earnings Sheet is Linked to:';

  conditionVal = 3;
  earningVal = 20;
  @ViewChild('dropdownTree') public dropdownTree: DropDownTreeComponent;
  @Output() selectedItemInLink = new EventEmitter;
  selectedDataforLink: {benchmarkData: {}, earnings2: any, earnings3: any}= {benchmarkData: '', earnings2: '', earnings3: '' };
  // Information available globally
  public currentSelectedCustomerId = 233107;
  public userId = 0;
  public selectedFinancialBID = 73288;
  public defaultEarnings3: { FinancialStatementDesc: string; CustomerTaskBID: string } = {
    FinancialStatementDesc: 'Select Earnings3',
    CustomerTaskBID: '-1'
  };

  public defaultEarnings2: { FinancialStatementDesc: string; CustomerTaskBID: string } = {
    FinancialStatementDesc: 'Select Earnings2',
    CustomerTaskBID: '-1'
  };

  public earnings3: EarningStatementHeader[];
  public selectedEarnings3: any;
  public earnings2: EarningStatementHeader[];
  public selectedEarnings2: any;
  public tlkpBenchmarkIndustryTemplate: any[];
  public benchmarkIndustryTreeNodes: TreeNode[] = [];

  public opened = true;
  lastTouchUserInfo: any;
  // Tree related
  /**
  * The field that holds the keys of the expanded nodes.
  */
  public expandedNodes: number[] = [];
  public expandedKeys: any[] = [];

  public show: boolean = false;

  public selectedKeys: any[] = [];
  public selectedBenchmarkData: TreeNode = {
    id: 0,
    desc: '',
    desc2: '',
    data: undefined,
    icon: false,
    iconPath: '',
    iconType: 0,
    children: [],
    nodeLevel: -1,
    parantid: 0,
    parantDesc: '',
    parantDesc2: ''

  };

  constructor (private _restservice: RestService,
    private dataservice : ShareStatementDataService) {

  }

  ngOnInit (): void {
    this.loadLinkEarningsStatement();
    this.getBenchmarkData();
  }

 loadLinkEarningsStatement () {
    const paramsData = {
      customerBID: this.currentSelectedCustomerId,
      financialStatementBID: this.selectedFinancialBID,
      groupBID: null,
      Errors: []
    };

    this._restservice.post(environment.baseURI + AppConstant.endpoints.retrieveEarningsStatementHeaderByID, paramsData).subscribe((data: any) => {
      if(data)
      {
        const ddData = data.RetrieveEarningsStatementHeaderByIDResult.AvailableEarningsHeaders;
        //this.earnings3 = [];
        this.earnings2 = [];
  
        //this.earnings3 = ddData.map(element => this.mapToESHeader(element));
        this.earnings2 = ddData.map(element => this.mapToESHeader(element));
      }
      this.addItemInEarning();
    });
  }

  addItemInEarning()
  {
    const earningStatementHeader: EarningStatementHeader =
      {
        AvailableBalanceSheetHeaders: [],
        AvailableBenchmarks: [],
        AvailableEarningsHeaders: [],
        FinancialStatementBID: 0,
        CustomerBID: 0,
        FinancialSourceTypeCde: 0,
        FinancialStatementDesc: '',
        FinancialStatementEndDte: '',
        FinancialStatementJoins: [],
        FinancialStatementStartDte: '',
        FinancialStatementSubTypeCde: 0,
        FinancialStatementTemplateCde: 0,
        IncludesMonthlyBudgetInd: true,
        LinkedBalanceSheetHeaders: [],
        LinkedEarningsHeaders: [],
        PrimaryInd: true,
        ProjectionValueHeldCde: 0,
        IsDefault: true
      }

      let param: EarningStatementHeader =
      {
        AvailableBalanceSheetHeaders: [],
        AvailableBenchmarks: [],
        AvailableEarningsHeaders: [],
        FinancialStatementBID: 0,
        CustomerBID: 0,
        FinancialSourceTypeCde: 0,
        FinancialStatementDesc: '',
        FinancialStatementEndDte: '',
        FinancialStatementJoins: [],
        FinancialStatementStartDte: '',
        FinancialStatementSubTypeCde: 0,
        FinancialStatementTemplateCde: 0,
        IncludesMonthlyBudgetInd: true,
        LinkedBalanceSheetHeaders: [],
        LinkedEarningsHeaders: [],
        PrimaryInd: true,
        ProjectionValueHeldCde: 0,
        IsDefault: true
      }
      
      this.selectedEarnings2 = this.selectedEarnings3 = earningStatementHeader;
    param.FinancialStatementDesc = 'Use the statement currently being created';
    param.IsDefault = false;
    param.FinancialStatementSubTypeCde = FinancialStatementSubTypes.NewStatement;
    if(this.earnings2)
    {
      this.earnings2.unshift(param);
      //this.earnings3.unshift(param);
    }
    else
    {
      let temp = [];
      temp.push(param);
      this.earnings2 = temp.map(element => this.mapToESHeader(element));
      //this.earnings3 = temp.map(element => this.mapToESHeader(element));
    }
    this.earnings2.unshift(earningStatementHeader);
    //this.earnings3.unshift(earningStatementHeader);
 
  }

  mapToESHeader (element: any): EarningStatementHeader {
    const startDate = moment.utc(element.FinancialStatementStartDte).format('MM/DD/yyyy');
    const endDate = moment.utc(element.FinancialStatementEndDte).format('MM/DD/yyyy');
    return {
      AvailableBalanceSheetHeaders: element.AvailableBalanceSheetHeaders,
      AvailableBenchmarks: element.AvailableBenchmarks,
      AvailableEarningsHeaders: element.AvailableEarningsHeaders,
      FinancialStatementBID: element.FinancialStatementBID,
      CustomerBID: element.CustomerBID,
      FinancialSourceTypeCde: element.FinancialSourceTypeCde,
      FinancialStatementDesc: element.FinancialStatementDesc,
      FinancialStatementEndDte: endDate,
      FinancialStatementJoins: element.FinancialStatementJoins,
      FinancialStatementStartDte: startDate,
      FinancialStatementSubTypeCde: element.FinancialStatementSubTypeCde,
      FinancialStatementTemplateCde: element.FinancialStatementTemplateCde,
      IncludesMonthlyBudgetInd: element.IncludesMonthlyBudgetInd,
      LinkedBalanceSheetHeaders: element.LinkedBalanceSheetHeaders,
      LinkedEarningsHeaders: element.LinkedEarningsHeaders,
      PrimaryInd: element.PrimaryInd,
      ProjectionValueHeldCde: element.ProjectionValueHeldCde,
      IsDefault: false
    };
  }

  getBenchmarkData () {
    let paramsData: any = {
      lookupTables: [
        {
          TableCde: 103,
          TableName: 'tlkpBenchmarkIndustryTemplate',
          EmptyOK: true
        }]
    };
    const lookupData: Observable<any> = this._restservice.post(environment.commonBaseURI + AppConstant.endpoints.getLookups, paramsData);

    paramsData =
      { selectedFinancialStatementBIDs: [] };
    const benchmarkData: Observable<any> = this._restservice.post(environment.baseURI + AppConstant.endpoints.retrieveBenchmarkNodes, paramsData);

    forkJoin([lookupData, benchmarkData]).subscribe((data: any[]) => {
      this.tlkpBenchmarkIndustryTemplate = data[0].GetLookupsResult;
      const groubedByBenchmarkIndustryTemplateCde = this.groupBy(data[1].RetrieveBenchmarkNodesResult.BenchmarkGroupNodes, 'BenchmarkIndustryTemplateCde');

      paramsData = {
        benchmarkIDs: data[1].RetrieveBenchmarkNodesResult.BenchmarkNodes.map(val => val.BenchmarkID),
        financialStatementType: FinancialStatementSubTypes.EarningsStatement,
        Error: []
      };

      let lastLeafnodes: TreeNode[] = [];
      const benchmarkLastLeafNodeData = this._restservice.post(environment.baseURI + AppConstant.endpoints.retrieveBenchmarkStatementNodesAll, paramsData).subscribe((e: any) => {
        const fhsCollections = e.RetrieveBenchmarkStatementNodesAllResult.flatMap((elem) => elem.FinancialSheetHeaders)

        lastLeafnodes = fhsCollections.map(leafchild => <TreeNode>{
          data: leafchild,
          id: leafchild.FinancialStatementBID,
          nodeLevel: 3,
          children: [],
          desc: leafchild.FinancialStatementEndDte,
          desc2: leafchild.FinancialStatementDesc,
          icon: true,
          iconType: leafchild.FinancialStatementSubTypeCde,
          iconPath: '',
          parantid: leafchild.DefaultBenchmarkID
        });

        this.benchmarkIndustryTreeNodes = [];
        let temp={
          data: null,
          id: -1,
          nodeLevel: 0,
          children: null,
          desc: 'done',
          icon: false,
          iconPath: '',
          parantid: 0
        };
        for (const key in groubedByBenchmarkIndustryTemplateCde) {
          const industryTemplate = this.tlkpBenchmarkIndustryTemplate[0].LookupData.find((x) => parseInt(x.Cde) === parseInt(key));
          const industryTemplatesData = this.LoadBenchmarkNode(this.tlkpBenchmarkIndustryTemplate, data[1], key, lastLeafnodes, ...groubedByBenchmarkIndustryTemplateCde[key]);

          this.benchmarkIndustryTreeNodes.push({
            data: industryTemplate,
            id: parseInt(industryTemplate.Cde),
            nodeLevel: 0,
            children: industryTemplatesData,
            desc: industryTemplate.Desc,
            icon: false,
            iconPath: '',
            parantid: 0
          });
        }

        benchmarkLastLeafNodeData.unsubscribe();
        this.benchmarkIndustryTreeNodes.sort((a, b) => a.desc < b.desc ? -1 : a.desc > b.desc ? 1 : 0);
        this.benchmarkIndustryTreeNodes.unshift(temp);
        //console.log(this.benchmarkIndustryTreeNodes);
      });
    });
  }

  LoadBenchmarkNode (tlkpBenchmarkIndustryTemplate: any, data: any, key: string, lastLeafnodes: TreeNode[], ...element): TreeNode[] {
    const benchmarkIndustryTreeNode: TreeNode[] = [];

    for (const e in element) {
      const nodes: TreeNode[] = [];
      data.RetrieveBenchmarkNodesResult.BenchmarkNodes.filter((bn) =>
        bn.BenchmarkGroupBID === element[e].BenchmarkGroupBID).forEach(ele => {
        nodes.push({
          data: ele,
          id: ele.BenchmarkID,
          nodeLevel: 2,
          children: lastLeafnodes.filter(x => x.parantid === ele.BenchmarkID),
          desc: ele.BenchmarkDesc,
          icon: false,
          iconPath: '',
          parantid: ele.BenchmarkGroupBID
        });
      });

      benchmarkIndustryTreeNode.push({
        data: {
          BenchmarkGroupHeader: e,
          BenchmarkNodes: nodes
        },
        id: parseInt(element[e].BenchmarkGroupBID),
        nodeLevel: 1,
        children: nodes,
        desc: element[e].BenchmarkGroupName,
        icon: false,
        iconPath: ''
      });
    }

    return benchmarkIndustryTreeNode;
  }

  groupBy = function (xs, key) {
    return xs.reduce(function (rv, x) {
      (rv[x[key]] = rv[x[key]] || []).push(x);
      return rv;
    }, {});
  };

  /**
   * A function that checks whether a given node index exists in the expanded keys collection.
   * If the item ID can be found, the node is marked as expanded.
   */
  public isNodeExpanded = (node: any): boolean => {
    return this.expandedNodes.indexOf(node.id) !== -1;
  };

  /**
   * A `nodeCollapse` event handler that will remove the node data item ID
   * from the collection, collapsing its children.
   */
  public handleCollapse (args: TreeItem): void {
    this.expandedNodes = this.expandedNodes.filter(
      (id) => id !== args.dataItem.id
    );
  }

  /**
   * An `nodeExpand` event handler that will add the node data item ID
   * to the collection, expanding the its children.
   */
  public handleExpand (args: any): void {
    this.expandedNodes = this.expandedNodes.concat(args.dataItem.id);
    // this.BindStatementNode(args.index);
  }

  public onToggle (): void {
    this.show = !this.show;
  }

  public handleSelection ({ index }: any): void {
    const selectedIndex = String(index).split('_');
    if (selectedIndex.length === 4) {
      this.selectedBenchmarkData = this.benchmarkIndustryTreeNodes[selectedIndex[0]].children[selectedIndex[1]].children[selectedIndex[2]].children[selectedIndex[3]];
      this.selectedBenchmarkData.parantDesc = this.benchmarkIndustryTreeNodes[selectedIndex[0]].desc;
      this.selectedBenchmarkData.parantDesc2 = this.benchmarkIndustryTreeNodes[selectedIndex[1]].desc;
      this.show = !this.show;
    } else {
      this.selectedBenchmarkData = {
        id: 0,
        desc: '',
        desc2: '',
        data: undefined,
        icon: false,
        iconPath: '',
        iconType: 0,
        children: [],
        nodeLevel: -1,
        parantid: 0,
        parantDesc: '',
        parantDesc2: ''

      };
    }
    this.selectedDataforLink.benchmarkData = this.selectedBenchmarkData;
    this.dataservice.setEarningsLinkedStatment(this.selectedDataforLink);
  }
  
  changeEarnings (event: any, earnings: any): void {
    if (earnings === '2') {
      this.selectedDataforLink.earnings2 = event;
    } else {
      this.selectedDataforLink.earnings3 = event;
    }
    this.dataservice.setEarningsLinkedStatment(this.selectedDataforLink);
  }

  onFinancialStatementHover (id: any): void {
    const paramsData = {
      financialStatementBID: id
    };
    const apiUrl = environment.baseURI + environment.endpoints.retrieveLastInfo;
    this._restservice.post(apiUrl, paramsData).subscribe((data: any) => {
      this.lastTouchUserInfo = data.RetrieveLastChangedInformationByFinanicalStatementBIDResult;
    });
    
  }
}