import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OpenEarningStatementComponent } from './open-earning-statement.component';

describe('OpenEarningStatementComponent', () => {
  let component: OpenEarningStatementComponent;
  let fixture: ComponentFixture<OpenEarningStatementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OpenEarningStatementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OpenEarningStatementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
