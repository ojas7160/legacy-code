import { Component, OnInit,TemplateRef,ViewChild,HostListener,ElementRef } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { AppState } from '../../../store';
import { earningStatements } from '../../../store/selectors/earningStatement.selector';
import * as earningStatementActions from '../../../store/actions';
import {ShareStatementDataService} from '../../../services/earnings/shareStatementDataService';
import { KendoModalService } from '../../../services';
import { NewEditEarningsComponent } from '../new-edit-earnings/new-edit-earnings.component';
import { WindowRef } from '@progress/kendo-angular-dialog';

@Component({
  selector: 'uc-open-projected-es',
  templateUrl: './open-projected-es.component.html',
  styleUrls: ['./open-projected-es.component.scss']
})
export class OpenProjectedESComponent implements OnInit {
  parameterList : any[];
  statementListByCustomer : any[];
  earningStatementsData:any;
  windowopenRef;
  

  constructor(private store:Store<AppState>,
              private shareStatementDataService:ShareStatementDataService,
              private kendoModalService:KendoModalService,
              private eRef:ElementRef,
              private windowRef:WindowRef)
     { }

  ngOnInit(): void {
    this.store.dispatch(earningStatementActions.earningStatement({}));
    this.store.pipe(select(earningStatements))    
		.subscribe(data => {
      this.earningStatementsData = data.earningStatement.earningStatements;
		 })
  }

  // getStatementListByCustomer(dataItem){
  //   this.statementListByCustomer = dataItem.earningStatements;
  // }

  selectProjectedStatement(dataItem){  
    debugger;
    // this.parameterList = dataItem.otherparameters;
    // this.shareStatementDataService.setProfileObs(dataItem);
    console.log('dataItem',dataItem);
    
  }

// @HostListener('document:click', ['$event'])
projectedNew() {
  this.windowRef.close();
 
  this.windowopenRef = this.kendoModalService.open('window', 'newProjectedForm',
    NewEditEarningsComponent,
    {  titleBarContent: "New Projection"  })

}


projectedWindowClose()
{
  //this.kendoModalService.close('window', this.windowRef);
  this.windowRef.close();
}

// ngOnDestroy(){
//   this.kendoModalService.close('window', this.windowRef);
//   this.windowRef = null;
  
// }

}
