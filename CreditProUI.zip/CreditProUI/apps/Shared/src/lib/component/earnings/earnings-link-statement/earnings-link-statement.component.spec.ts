import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EarningsLinkStatementComponent } from './earnings-link-statement.component';

describe('EarningsLinkStatementComponent', () => {
  let component: EarningsLinkStatementComponent;
  let fixture: ComponentFixture<EarningsLinkStatementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EarningsLinkStatementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EarningsLinkStatementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
