import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-earnings-statement-header',
  templateUrl: './earnings-statement-header.component.html',
  styleUrls: ['./earnings-statement-header.component.scss']
})
export class EarningsStatementHeaderComponent implements OnInit {
  public value: Date = new Date();
  public opened = true;
  public dataSaved = false;
  public listItems: Array<string> = [
    "Type 1"]
  constructor() { }

  ngOnInit(): void {
  }

  public close() {
    this.opened = false;
  }

  public open() {
    this.opened = true;
  }

  public submit() {
    this.dataSaved = true;
    this.close();
  }
}
