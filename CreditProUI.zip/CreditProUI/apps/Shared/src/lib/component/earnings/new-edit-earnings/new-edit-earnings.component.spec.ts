import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewEditEarningsComponent } from './new-edit-earnings.component';

describe('NewEditEarningsComponent', () => {
  let component: NewEditEarningsComponent;
  let fixture: ComponentFixture<NewEditEarningsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewEditEarningsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NewEditEarningsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
