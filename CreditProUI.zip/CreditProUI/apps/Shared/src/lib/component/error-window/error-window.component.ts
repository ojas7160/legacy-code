import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'lib-error-window',
  templateUrl: './error-window.component.html',
  styleUrls: ['./error-window.component.scss']
})
export class ErrorWindowComponent implements OnInit {
  @Input() error : string;
  public opened = false;
  constructor() { } 

  public close(status:any) {
      console.log(`Dialog result: ${status}`);
      this.opened = false;
  }

  public open() {
      this.opened = true;
  }

  ngOnInit(): void {
  }

}
