import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consolidation-maintenance',
  templateUrl: './consolidation-maintenance.component.html',
  styleUrls: ['./consolidation-maintenance.component.scss']
})
export class ConsolidationMaintenanceComponent implements OnInit {
  page;
  constructor () { }

  ngOnInit (): void {
  }
}
