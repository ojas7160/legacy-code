import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsoGrpSelectionComponent } from './conso-grp-selection.component';

describe('ConsoGrpSelectionComponent', () => {
  let component: ConsoGrpSelectionComponent;
  let fixture: ComponentFixture<ConsoGrpSelectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsoGrpSelectionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsoGrpSelectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
