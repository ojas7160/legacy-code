import { Component, Input, OnInit, ViewChild, TemplateRef, ViewEncapsulation } from '@angular/core';
import { AppState } from '../../../store';
import { select, Store } from '@ngrx/store';
import * as consolidationGroupActions from '../../../store/actions/consolidations/consolidations.action';
import { consolidationGroups } from '../../../store/selectors/consolidations/consolidations.selector';
import { commonSelector } from '../../../store/selectors/common.selector';
import * as commentsActions from '../../../store/actions/comments.action';
import { commentsSelector } from '../../../store/selectors/comments.selector';
import { WindowCloseResult, WindowRef } from '@progress/kendo-angular-dialog';
import { KendoModalService, RestService, SelectedCustomerService } from '../../../services';
import { CommentEditor } from '../../common/comments-editor/comments-editor.component';
import { NewEditBalanceSheetComponent } from '../../balancesheet/new-edit-balance-sheet/new-edit-balance-sheet.component';
import { NewEditEarningsComponent } from '../../earnings/new-edit-earnings/new-edit-earnings.component';
import { UtilityService } from '../../../services/utility/utility.service';
import { CachedLookups } from '../../../enum/cachedLookups';
import { DcComment } from '../../../models/comment';
import { OpenedCustomer } from '../../../models/customer-search-result.model';
import { DTOAction } from '../../../enum/DTOAction';
import { environment } from 'apps/CreditPro/src/environments/environment';
import { TooltipDirective } from '@progress/kendo-angular-tooltip';

@Component({
  selector: 'app-conso-grp-selection',
  templateUrl: './conso-grp-selection.component.html',
  styleUrls: ['./conso-grp-selection.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ConsoGrpSelectionComponent implements OnInit {
  @Input() page: string;
  isIncludeActiveGroupsOnly = true;
  pageName = 'Consolidation';
  comment: DcComment;
  consolidationGroup: any;
  @ViewChild('bSWindowTitleBar', { static: false, read: TemplateRef }) public bSWindowTitleBar
  @ViewChild('earningWindowTitleBar', { static: false, read: TemplateRef }) public earningWindowTitleBar
  opened: boolean;
  windowRef;
  groupTypeCde = 6;
  isLoading = false;
  selectedCustomer: OpenedCustomer;
  groupData: any;
  lookUps;
  selectedGroup: any;
  @ViewChild(TooltipDirective) tooltipDir: TooltipDirective;

  constructor(
    private store: Store<AppState>,
    private kendoModalService: KendoModalService,
    private utiltyService: UtilityService,
    private windowsRef: WindowRef,
    private selectedCustomerService: SelectedCustomerService,
    private restService: RestService
  ) { }

  ngOnInit(): void {
    // load the lookups data
    this.loadLookUps();

    // get selected current customer
    this.selectedCustomer = this.selectedCustomerService.getCurrentSelectedCustomer2();
    this.initializeFormLoad();
  }

  /**
   *  call on page load and load the consolidation data
   */
  initializeFormLoad(): void {
    this.store.pipe(select(consolidationGroups))
      .subscribe(data => {
        this.consolidationGroup = [];
        const consolidationData = data?.consolidationGroups?.RetrieveGroupDefinitionByCustomerBIDResult;
        if (consolidationData?.length){
          if(this.isLoading) {
            this.isLoading = false;
          }
          this.consolidationGroup = consolidationData?.filter(grp => grp.GroupTypeCde === this.groupTypeCde);
        }
        this.filterGroupType(this.groupData);
      });
  }

  /**
   * toggle includeActiveGroups value b/w true and false and load data accordingly
   */
  includeActiveGroupsOnly(): void {
    this.isIncludeActiveGroupsOnly = !this.isIncludeActiveGroupsOnly;
    this.isLoading = true;
    this.store.dispatch(consolidationGroupActions.consolidationGroup({
      CustomerBID: this.selectedCustomer.customerId,
      EmPOWER: true, includeActiveGroupsOnly: this.isIncludeActiveGroupsOnly
    }));
  }

  // Close the window modal on clcik of close button
  public closeThis() {
    this.windowsRef.close()
  }

  /**
   * This is to open comment additor on clrick of Add comments in Comments column
   * @param {string} category
   * @memberof ConsoGrpSelectionComponent
   */
  openComentEditor(dataItem: any): void {
    if (dataItem?.CommentBID != null || dataItem.CommentBID === undefined) {
      this.store.dispatch(commentsActions.initialCommentsDataLoad({
        commentBID: dataItem.CommentBID
      }));
    }
    const actionCde = (dataItem.CommentBID === undefined || dataItem?.CommentBID === null) ? DTOAction.Insert : DTOAction.Update;
    const dialog: any = this.kendoModalService.open('window', 'commentEditor', CommentEditor);
    const overlay = this.kendoModalService.addOverlay();
    dialog.result.subscribe((response) => {
      this.kendoModalService.removeOverlay(overlay);
      if (response.action === 'OK') {
        const str = response.comment;
        const strippedText = str.replace(/(<([^>]+)>)/ig,"");
        this.comment = {
          Action: actionCde,
          Comment: response.comment,
          CommentBID: null,
          CommentPlainTxt: strippedText,
          TableName: null,
          UserID: this.selectedCustomer.customerId
        }
        this.store.dispatch(commentsActions.commentsDataSave({
          comment: {Action: this.comment.Action, UserID: 1997, Comment: this.comment.Comment,
          CommentBID: dataItem.CommentBID, CommentPlainTxt: this.comment.CommentPlainTxt}
        }));
        this.saveComment(dataItem, response);
      }
    })
  }

  /**
   * To save the comment in the comment Editor
   * @param response
   */
  saveComment(index: any, response: any) {
    this.pageName = 'BSCon';
    this.store.pipe(select(commentsSelector))
    .subscribe(data => {
      if (this.pageName === 'BSCon' && (data?.type === commentsActions.COMMENTS_SAVE_DATA || data?.type === commentsActions.COMMENTS_UPDATE_DATA)) {
        index.CommentBID = data?.SaveCommentResult;
        if(this.comment.Action === DTOAction.Insert && data?.SaveCommentResult){
          this.saveGroup(index);
        }
      }
    });
  }

  /**
   * Delete the comments from selected group consolidation
   * @param dataItem
   */
  deleteComment(dataItem: any): void {
    dataItem.DeleteIsChecked = false;
    const params = [{Action: DTOAction.Delete,UserID: 1997, CommentBID: dataItem.CommentBID}];
    this.store.dispatch(commentsActions.commentsDataDelete({
      comments: params
    }));
    dataItem.CommentBID = null;
    this.comment = null;
    this.saveGroup(dataItem);
  }

  /**
   * Open the create new Consolidation on the basis of page name on click of new
   * @memberof ConsoGrpSelectionComponent
   */
  newConsolidation(d) {
    this.windowsRef.close();
    this.selectedGroup = d
    switch (this.page) {
      case 'balansheet':
        this.newBalanceSheetForm(this.bSWindowTitleBar)
        break;
      case 'earning':
        this.newEarnings(this.earningWindowTitleBar)
    }
  }


  /**
   * Open new Bs consolidation on click of Group name while user is on BS Module Consolidation
   * @param {TemplateRef<any>} titleContent
   * @memberof ConsoGrpSelectionComponent
   */
  newBalanceSheetForm(titleContent: TemplateRef<any>) {
    this.opened = true;
    const overlay = this.kendoModalService.addOverlay();

    this.windowRef = this.kendoModalService.open('window', 'balanceSheetForm',
      NewEditBalanceSheetComponent,
      { titleBarContent: titleContent })

    const windowInstance = this.windowRef.content.instance;
    windowInstance.hideElement = { hidetemplate: true };
    windowInstance.whichComponent = 'Consolidation BS';
    windowInstance.lookUps = this.lookUps;
    windowInstance.selectedGroup = this.selectedGroup
    windowInstance.bsConsolidationRequiredFields = [383, 382] // this contains static ids as it's checking statically the same way in silverlight with ids

    this.windowRef.result.subscribe((result) => {
      if (result instanceof WindowCloseResult) {
        this.opened = false;
        this.kendoModalService.removeOverlay(overlay);
        this.utiltyService.dialogClose(true);
      }
    });
  }


  /**
   * Method to open the Earnings Consolidation on click of group name
   * While user is on Earnings module
   * @param {TemplateRef<any>} titleContent
   * @memberof ConsoGrpSelectionComponent
   */
  newEarnings(titleContent: TemplateRef<any>) {
    this.opened = true;
    this.windowRef = this.kendoModalService.open('window', 'newEarningsForm',
      NewEditEarningsComponent,
      { titleBarContent: titleContent })

    this.windowRef.result.subscribe((result) => {
      if (result instanceof WindowCloseResult) {
        this.opened = false;
        this.utiltyService.dialogClose(true);
      }
    });
  }

  /**
   * This method can fiter and append grouptype to the consolidation
   * data on the basis of groupTypeCde
   * @param {*} groupData
   * @memberof ConsoGrpSelectionComponent
   */
  filterGroupType(groupData): void {
    this.consolidationGroup?.forEach((group, index) => {
      //Find groupType on the basis of groupTypeCde
      const groupType = groupData.LookupData.find(g => g.Cde === group.GroupTypeCde);
      this.consolidationGroup[index].GroupTypeDesc = groupType.Desc;
    })
  }

  /**
   * This method load all the required lookups saved in the store
   * @memberof ConsoGrpSelectionComponent
   */
  loadLookUps(): void {
    this.store.pipe(select(commonSelector))
      .subscribe(res => {
        this.lookUps = res.GetLookupsResult?.length && res.GetLookupsResult;
        this.groupData = this.lookUps.find((element) => element.Table.TableCde === CachedLookups.tlkpGroupType )
      })
  }

  /**
   * To save and update commentBID on insert and delete of comments
   * @param dataItem
   */
  saveGroup(dataItem: any): void {
    dataItem.Action = DTOAction.Update;
    this.restService.post(environment.baseURI + environment.endpoints.baseURLPrefix + environment.endpoints.saveGroup, {group: dataItem})
    .subscribe(result => {
    });
  }
}
