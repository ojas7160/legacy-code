import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolidationsNoComponentAlertComponent } from './consolidations-no-component-alert.component';

describe('ConsolidationsNoComponentAlertComponent', () => {
  let component: ConsolidationsNoComponentAlertComponent;
  let fixture: ComponentFixture<ConsolidationsNoComponentAlertComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsolidationsNoComponentAlertComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsolidationsNoComponentAlertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
