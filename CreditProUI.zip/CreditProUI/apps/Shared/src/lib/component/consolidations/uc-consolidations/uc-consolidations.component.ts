import { Component, OnInit } from '@angular/core';
import { RestService } from '../../../services';

@Component({
  selector: 'lib-uc-consolidations',
  templateUrl: './uc-consolidations.component.html',
  styleUrls: ['./uc-consolidations.component.scss']
})
export class UcConsolidationsComponent implements OnInit {

  constructor(private restService: RestService) {

    this.restService.get("https://gorest.co.in/public-api/users").subscribe(data=>console.log(data));
 
   }

  ngOnInit(): void {
  }

}
