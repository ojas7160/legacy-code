import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolidationsNewPopupComponent } from './consolidations-new-popup.component';

describe('ConsolidationsNewPopupComponent', () => {
  let component: ConsolidationsNewPopupComponent;
  let fixture: ComponentFixture<ConsolidationsNewPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsolidationsNewPopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsolidationsNewPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
