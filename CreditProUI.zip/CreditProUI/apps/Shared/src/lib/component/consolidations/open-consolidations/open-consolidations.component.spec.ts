import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OpenConsolidationsComponent } from './open-consolidations.component';

describe('OpenConsolidationsComponent', () => {
  let component: OpenConsolidationsComponent;
  let fixture: ComponentFixture<OpenConsolidationsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OpenConsolidationsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OpenConsolidationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
