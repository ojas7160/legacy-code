import { Component, OnInit } from '@angular/core';
import { WindowRef } from '@progress/kendo-angular-dialog';

@Component({
  selector: 'lib-consolidations-new-popup',
  templateUrl: './consolidations-new-popup.component.html',
  styleUrls: ['./consolidations-new-popup.component.scss']
})
export class ConsolidationsNewPopupComponent implements OnInit {
  isShown: boolean = false ; // hidden by default
  public dialogOpened = false;
  public windowOpened = false;
  public opened = true;
  public dataSaved = false;
  public closed = true;
   errormsg:any='There are errors on this page.';
  public data = []
  constructor(public windowRef: WindowRef) { }

  ngOnInit(): void {
  }
  public close() {
    this.windowRef.close()
  }
  public openClose(isOpened: boolean) {
    this.opened = isOpened;
  }
  divclose(){
    this.closed = false;
  }
  divangleup(){
    this.isShown = ! this.isShown;
  }
  public open() {
    this.opened = true;
  }

  public submit() {
    this.dataSaved = true;
    this.close();
  }

}
