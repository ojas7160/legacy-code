import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-consolidations-no-component-alert',
  templateUrl: './consolidations-no-component-alert.component.html',
  styleUrls: ['./consolidations-no-component-alert.component.scss']
})
export class ConsolidationsNoComponentAlertComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  public opened = false;

  public close(status:any) {
      console.log(`Dialog result: ${status}`);
      this.opened = false;
  }

  public open() {
      this.opened = true;
  }
}
