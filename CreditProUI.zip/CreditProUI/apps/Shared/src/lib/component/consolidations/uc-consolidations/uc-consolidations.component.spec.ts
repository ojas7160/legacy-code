import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UcConsolidationsComponent } from './uc-consolidations.component';

describe('UcConsolidationsComponent', () => {
  let component: UcConsolidationsComponent;
  let fixture: ComponentFixture<UcConsolidationsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UcConsolidationsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UcConsolidationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
