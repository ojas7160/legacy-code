import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { WindowCloseResult, WindowRef } from '@progress/kendo-angular-dialog';
import { KendoModalService, SelectedCustomerService } from '../../../services';
import { UtilityService } from '../../../services/utility/utility.service';
import { AppState } from '../../../store';
import { openConsolidations } from '../../../store/selectors/consolidations/openConsolidation.selector';
import * as openConsolidationsActions from '../../../store/actions/consolidations/openConsolidations.action';
import * as consolidationGroupActions from '../../../store/actions/consolidations/consolidations.action';
import { ConsoGrpSelectionComponent } from '../conso-grp-selection/conso-grp-selection.component';
import { TreeNode } from '../../../models/balanceSheet/TreeNode';

@Component({
  selector: 'uc-open-consolidations',
  templateUrl: './open-consolidations.component.html',
  styleUrls: ['./open-consolidations.component.scss']
})
export class OpenConsolidationsComponent implements OnInit {
  @ViewChild('consoGrpSelectionWindowTitleBar', { static: false, read: TemplateRef }) public consoGrpSelectionWindowTitleBar;
  @ViewChild('earningWindowTitleBar', { static: false, read: TemplateRef }) public earningWindowTitleBar
  opened: boolean;
  windowRef;
  groupTypeCde = 6;
  page: string;
  isIncludeActiveGroupsOnly = true;
  selectedCustomer;
  openConsolidationTreeData: TreeNode[] = [];
  isLoading = false;
  selectedConsolidation: TreeNode = {
    id: 0,
    desc: '',
    desc2: '',
    data: undefined,
    icon: false,
    iconPath: "",
    iconType: 0,
    children: [],
    nodeLevel: -1,
    parantid: 0,
    parantDesc: '',
    parantDesc2: ''
  };

  constructor(private store: Store<AppState>,
    private kendoModalService: KendoModalService,
    private utiltyService: UtilityService,
    private windowsRef: WindowRef,
    private selectedCustomerService: SelectedCustomerService) { }

  ngOnInit(): void {
    // get selected current customer
    this.selectedCustomer = this.selectedCustomerService.getCurrentSelectedCustomer2();
    // Intialize page content
    this.initializeFormLoad();
  }

  /**
  *  call on page load and load the consolidation data
  */
  initializeFormLoad(): void {
    this.store.pipe(select(openConsolidations))
      .subscribe(data => {
        this.openConsolidationTreeData = [];
        let result = data?.openConsolidations?.RetrieveCustomerConsolidationFinancialStatementHeadersResult;
        if (result?.length) {
          result = result?.filter(grp => grp.Group.GroupTypeCde === this.groupTypeCde);
          this.mapConsolidationData(result);
          if (this.isLoading) {
            this.isLoading = false;
          }
        }
      });
  }

  /**
   * This to map data of API into tree format
   * @param {*} data
   * @return {*}  {*}
   * @memberof OpenConsolidationsComponent
   */
  mapConsolidationData(data: any): any {
    data.forEach(rb => {
      if (rb?.FinancialStatements) {
        this.openConsolidationTreeData.push({
          id: rb.Group.GroupBID,
          desc: rb.Group.GroupNameTxt,
          data: rb.Group,
          nodeLevel: 0,
          children: rb.FinancialStatements.map(x => <TreeNode>{
            data: x,
            id: x.FinancialStatementBID,
            nodeLevel: 1,
            children: [],
            isChecked: false,
            taskDescription: 'BS Consolidation',
            desc: x.FinancialStatementEndDte,
            desc2: x.FinancialStatementDesc,
            icon: true,
            iconType: x.FinancialStatementSubTypeCde,
            iconPath: '',
            parantid: rb.Group.GroupBID,
            linkText: 'Setup'
          })
        })
      }
    });
  }

  /**
   * Open Consolidation Grp Selection window on click of New button
   */
  openNewConsolidation(): void {
    this.windowsRef.close();
    this.store.dispatch(consolidationGroupActions.consolidationGroup({
      CustomerBID: this.selectedCustomer.customerId,
      EmPOWER: true, includeActiveGroupsOnly: true
    }));
    const params: any = {
      width: 1000,
      height: 400,
      titleBarContent: this.consoGrpSelectionWindowTitleBar
    };
    this.opened = true;
    this.windowRef = this.kendoModalService.open('window', 'consoGrpSelection', ConsoGrpSelectionComponent, params);
    const overlay = this.kendoModalService.addOverlay();
    let consolidationGroupSelection = this.windowRef.content.instance;
    consolidationGroupSelection.page = this.page

    // Subscribed to perform actions on closing of dialog window
    this.windowRef.result.subscribe((result) => {
      if (result instanceof WindowCloseResult) {
        this.opened = false;
        this.kendoModalService.removeOverlay(overlay);
        this.utiltyService.dialogClose(true);
      }
    });
  }

  /**
   * toggle includeActiveGroups value b/w true and false and load data accordingly
   */
  includeActiveGroupsOnly(): void {
    this.isIncludeActiveGroupsOnly = !this.isIncludeActiveGroupsOnly;
    this.isLoading = true;
    this.store.dispatch(openConsolidationsActions.openConsolidation({
      customerBID: this.selectedCustomer.customerId,
      includeBS: true, includeES: false, includeActiveGroupsOnly: this.isIncludeActiveGroupsOnly
    }));
  }

  /**
   * Redirect to next screen on click of OK button
   * @param {*} event
   * @memberof OpenConsolidationsComponent
   */
  onClickOK(event: any): void {
    this.closePopUp();
  }

  // Close the window modal on clcik of close button
  public closePopUp(): void {
    this.windowsRef.close()
  }

  /**
   * handle selection on selecting any data from tree
   * @param e
   */
  public handleConsoSelection(e: any): void {
    if (!e.dataItem.children || !e.dataItem.children.length) {
      this.selectedConsolidation = e.dataItem
      this.selectedConsolidation.parantDesc = e.dataItem.parent?.FinancialStatementDesc;
      this.selectedConsolidation.parantDesc2 = e.dataItem.desc2;
    }
    else {
      this.selectedConsolidation = {
        id: 0,
        desc: '',
        desc2: '',
        data: undefined,
        icon: false,
        iconPath: "",
        iconType: 0,
        children: [],
        nodeLevel: -1,
        parantid: 0,
        parantDesc: '',
        parantDesc2: ''
      };
    }
  }

}