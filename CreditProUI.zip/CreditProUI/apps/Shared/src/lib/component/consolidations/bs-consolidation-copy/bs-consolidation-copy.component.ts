/* eslint-disable no-undef */
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { RestService } from '../../../services';
import { environment } from 'apps/CreditPro/src/environments/environment';
import { FinancialStatementSubTypes } from '../../../enum/financialStatementSubTypes';
import { AppConstant } from '../../../constants/app-constants';

@Component({
  selector: 'uc-bs-consolidation-copy',
  templateUrl: './bs-consolidation-copy.component.html',
  styleUrls: ['./bs-consolidation-copy.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class BsConsolidationCopyComponent implements OnInit {

  selectedGroup;
  public headerContent = "Create New by Copying From:";
  groupStatements: any[]
  statementGroup;
  dateFormat = AppConstant.dateFormat
  
  constructor(private restService: RestService) { }

  ngOnInit(): void {
    setTimeout(() => this.retrieveConsolidationGroup(), 0)
    
  }

  retrieveConsolidationGroup() {
    let params = {
      "GroupBID" : this.selectedGroup.GroupBID,
      "financialStatementSubTypeCde" : FinancialStatementSubTypes.BalanceSheetConsolidation
    }
    this.restService.post(environment.baseURI + environment.endpoints.baseURLPrefix + environment.endpoints.retrieveConsolidationGroup, params)
    .subscribe(res => {
      this.groupStatements = res?.RetrieveConsolidationGroupResult?.ConsolidationFinancialSheetHeaders.reverse()
      this.statementGroup = res?.RetrieveConsolidationGroupResult?.Group
    })
  }

  selectStatement(statement) {
    this.groupStatements.forEach(it => { 
      if(it.FinancialStatementBID === statement.FinancialStatementBID)
        it.active = true
      else it.active = false
    })
    // statement.active = true;
  }

  clearAll() {
    this.groupStatements = this.groupStatements.map(it => { return { ...it, active: false } } )
  }
 
}
