import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolidationMaintenanceComponent } from './consolidation-maintenance.component';

describe('ConsolidationMaintenanceComponent', () => {
  let component: ConsolidationMaintenanceComponent;
  let fixture: ComponentFixture<ConsolidationMaintenanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsolidationMaintenanceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsolidationMaintenanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
