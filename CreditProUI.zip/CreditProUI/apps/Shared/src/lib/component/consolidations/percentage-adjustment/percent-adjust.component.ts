/* eslint-disable no-useless-constructor */
import { Component, Input, OnInit } from '@angular/core';
import { DialogRef } from '@progress/kendo-angular-dialog';
import { ListControl } from '../../../models/listControl';

@Component({
  selector: 'uc-percent-adjust',
  templateUrl: './percent-adjust.component.html',
  styleUrls: ['./percent-adjust.component.scss']
})
export class PercentAdjustComponent implements OnInit {
  perAdjust: ListControl[];
  @Input() showCancelbtn;
  constructor (private dialog: DialogRef) { }

  ngOnInit (): void {
    this.initPerAdjust();
  }

  initPerAdjust () {
    this.perAdjust = [{ text: 'FCS Value', value: 0 }, { text: 'Value', value: 1 }]
  }

  close (param?: string) {
    this.dialog.close(param);
  }
}
