import { Component, OnInit } from '@angular/core'
import { Store } from '@ngrx/store'
import { AppState } from '../../store'
import { ReportTemplateList, selectedReport, selectedReportsBundle } from '../../models/BottomGridReport'
import { ReportService } from '../../services/report/report.service'
import { environment } from '../../../../../CreditPro/src/environments/environment'
import { ACAReportTemplateDataItem, CustomerReportTemplateDataItem, DcReportBundle, DcReportTemplate } from '../../models/exclude-spec-details'
import { RestService } from '../../services'
import { AppConstant } from '../../constants/app-constants'
import { CustomerDetails } from '../../models/customerDetails.model'
import { ReportExportService } from '../../services/report/report-export.service'
import { SelectedCustomerService } from '../../services/utility/selectedCustomer.service'
import { DcCustomer } from '../../models/customer'
import { DTOAction } from '../../enum/DTOAction'

@Component({
  selector: 'lib-uc-reports',
  templateUrl: './uc-reports.component.html',
  styleUrls: ['./uc-reports.component.scss']
})
export class UcReportsComponent implements OnInit {
  public SelectedReportsBundles: selectedReportsBundle[];
  public SelectedReports: selectedReport[] = [];
  public SelectedReport: selectedReport;
  ReportTemplateTreeSource: any[]
  TemplateList_ACATemplates: number = 0
  TemplateList_CustomerBundles: number = 1
  DeleteIsChecked: boolean;
  windowOpened: boolean
  customerTemplates: any
  reportBundle: any
  OnSelectedReportsBundles (sRsBs: selectedReportsBundle[]) {
    this.SelectedReportsBundles = sRsBs
  }

  OnSelectedReports (sRs: selectedReport[]) {
    this.SelectedReports = sRs
  }

  OnSelectedReport (sR: selectedReport) {
    this.SelectedReport = sR
  }

  public showReports: boolean = false;
  selectedReportType: any;
  selectedReport: any;
  // public lookupData = [{"TableCde": 39,
  //                       "TableName": "tlkpFilteredReportOptionsMap",
  //                       "EmptyOK": false}];

  // public lookupTables ={lookupTables : this.lookupData};
  // eslint-disable-next-line no-useless-constructor
  constructor (private store: Store<AppState>, public reportService: ReportService,
    private restService: RestService,
    public reportServicePrintPdf: ReportExportService,
    private _selectedCustomerService: SelectedCustomerService) {
    this.ReportTemplateTreeSource = []
    const templateList: ReportTemplateList = new ReportTemplateList('ACA Templates', false)
    this.ReportTemplateTreeSource.push(templateList)
    const bundleList: ReportTemplateList = new ReportTemplateList('Customer Report Bundles', true)
    this.ReportTemplateTreeSource.push(bundleList)
  }

  public subMenu: any[]
  // public customerBID = 226363;
  public customerBID = this._selectedCustomerService.getCurrentSelectedCustomer2();
  dcReportBundle: DcReportBundle[]
  dcReportTemplate: DcReportTemplate[]
  public arrayItem: any = [];
  public selectedCustomerDetails: CustomerDetails = {};
  public showCustomer: boolean = false;
  reportMenu = AppConstant.secondaryMenu.report
  ngOnInit (): void {
    if (history.state) { this.getSelectedCustomerInfo(); }
    console.log('Customer Id', this.customerBID.customerId)
    this.RetrieveReportBundleByCustomerBID(this.customerBID.customerId)
    this.RetrieveReportTemplates(this.customerBID.customerId)    
    this.customerTemplates = this.ReportTemplateTreeSource
    this.reportService.openedCustomer = this._selectedCustomerService.getRelatedCustomers()
    if(this.reportService.SelectedCustomer){
      if(this.reportService.openedCustomer.customerId != this.reportService.SelectedCustomer.CustomerBID){
        this.reportService.SelectedFilteredReport = null
      }
    }
    if (this.reportService.openedCustomer) {
      this.reportService.RelatedCustomers = this.reportService.openedCustomer.relatedCustomers.RelatedCustomers.map(rc => rc.RelatedCustomerData)
      this.reportService.SelectedCustomer = this.reportService.RelatedCustomers.find(rc => rc.CustomerBID === this.reportService.openedCustomer.customerId)
      if(!this.reportService.RelatedCustomers.length){
        let selectedCustomer : DcCustomer
        selectedCustomer = {
          CustomerBID: this.reportService.openedCustomer.customerId,
          CustomerName: this.reportService.openedCustomer.customerName,
          Address: null,
          BranchID:  null,
          CustomerCrossReference:  null,
          CustomerCustomSICs: null,
          CustomerEID: null,
          CustomerTypeCde: null,
          SpouseRelation: null,
          DisplayName: null,
          Phone: null,
          PrimaryLoanOfficer: null,
          Settings: null,
          Action: DTOAction.Nothing,
          UserID: null

        }
        this.reportService.RelatedCustomers.push(selectedCustomer)
        this.reportService.SelectedCustomer = selectedCustomer
      }
      this.reportService.CurrentCustomerBID = this.reportService.openedCustomer.customerId
    }
  }

  reportListEvent (event: any) {
    this.showReports = true
    this.selectedReportType = event
    console.log('Getting Value', this.selectedReportType)
  }

  RetrieveReportBundleByCustomerBID (event: any) {
    
    const isReplaceOnly = this.ReportTemplateTreeSource[this.TemplateList_CustomerBundles].IsReplaceOnly
    // var openCommand = new DelegateCommand(OpenReportBundle);
    // var deleteCommand = new DelegateCommand(DeleteReportBundle);
    this.restService.post(environment.baseURI + environment.endpoints.retrieveReportBundleByCustomerBID, { customerBID: event })
      .subscribe(
        result => {
          this.dcReportBundle = result.RetrieveReportBundleByCustomerBIDResult
          this.dcReportBundle.forEach(rb => {
            const item = new CustomerReportTemplateDataItem()
            item.ReportBundleName = rb.ReportBundleDesc
            item.ReportBundleBID = rb.ReportBundleBID
            item.IsReplaceOnly = isReplaceOnly
            this.ReportTemplateTreeSource[this.TemplateList_CustomerBundles].ReportTemplates.push(item)
          })
        }
      )
  }

  RetrieveReportTemplates (event: any) {
    const isReplaceOnly = this.ReportTemplateTreeSource[this.TemplateList_ACATemplates].IsReplaceOnly
    this.restService.post(environment.baseURI + environment.endpoints.retrieveReportTemplates, { customerBID: event })
      .subscribe(
        result => {
          this.dcReportTemplate = result.RetrieveReportTemplatesResult
          this.dcReportTemplate.filter(d => d.DoNotDisplayInd != true).sort(s => s.DisplayOrderNum).forEach(rbs => {
            const items = new ACAReportTemplateDataItem()
            items.ReportBundleName = rbs.ReportTemplateDesc
            items.ReportTemplateBID = rbs.ReportTemplateBID
            items.IsReplaceOnly = isReplaceOnly
            this.ReportTemplateTreeSource[this.TemplateList_ACATemplates].ReportTemplates.push(items)
          })
          this.reportService.reportTemplateTree(this.ReportTemplateTreeSource)
        }
      )
  }

  selectedReportEvent (event: any) {
    this.selectedReport = event
  }

  openedWindow (event: any) {
    this.reportService.deletewindowOpened = true
    this.reportService.WindowPopupOpened = true
    this.reportService.ReportBundleBID = event
  }

  onCustomerBundle (event: any) {
    this.restService.post(environment.baseURI + environment.endpoints.retrieveReportBundleByReportBundleBID, { reportBundleBID: event })
      .subscribe(
        result => {
          // this.dcReportBundle = result.RetrieveReportBundleByReportBundleBIDResult
          // this.reportService.customerBundleSearch(this.dcReportBundle)
          this.reportBundle = result.RetrieveReportBundleByReportBundleBIDResult
          this.reportService.ReportBundleRetrieved(this.reportBundle)
          console.log('Search', this.dcReportBundle)
        }
      )
  }

  getSelectedCustomerInfo () {
    this._selectedCustomerService.getCurrentSelectedCustomer().subscribe(data => {
      if (data !== undefined) {
        this.selectedCustomerDetails = { customerBID: data.customerId, customerName: data.customerName };
        this.showCustomer = this.selectedCustomerDetails.customerBID > 0;
      }
    });
  }
}
