import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core'
import { State, process, SortDescriptor, orderBy, distinct } from '@progress/kendo-data-query'
import { select, Store } from '@ngrx/store'
import { AppState } from '../../../store'
import * as moment from 'moment'
import { DatePipe } from '@angular/common'
import {
  GridComponent,
  GridDataResult,
  DataStateChangeEvent
} from '@progress/kendo-angular-grid'
import { SelectedReportType } from '../../../enum/reportSelection'
import { reportsData } from '../../../store/selectors/report.selector'
import { RestService } from '../../../services'
import { environment } from '../../../../../../CreditPro/src/environments/environment'
import { ExternalBranch } from '../../../models/branches'
import { FinancialStatementSubType } from '../../../enum/financialStatementSubType'
import { ReportStatementSelection } from '../../../models/reportStatementSelection'
import { Reports } from '../../../enum/reports'
import { FinancialSourceTypes } from '../../../enum/financialsourcetypes'
import { ReportService } from '../../../services/report/report.service'

@Component({
  selector: 'uc-statement-selection-report',
  templateUrl: './statement-selection-report.component.html',
  styleUrls: ['./statement-selection-report.component.scss']
})
export class StatementSelectionReportComponent implements OnInit {
  public value = new Date();
  public batchMode = false;
  public reportName: string = 'Report Name';
  public reportCde: number;
  public reportOptionsMap: any;
  public retrievedReports: any;
  public selectedReportTypeCdeCopy: number;
  public filteredFinancialStatementSubType: any;
  public financialSoureType: any;
  fromDate: Date = new Date();
  public toDate: Date = new Date();
  public selectedBranches: ExternalBranch[] = [];
  public placeHolder: ExternalBranch = {
    BranchName: 'Select Branch(es)',
    BranchOID: null
  }
  selectedReportTypeCde: number;
  showSourceColumn: boolean;
  showCollateralColumn: boolean;
  showLinkedBalancesheet: boolean;
  showGroupNameColumn: boolean;
  branchName: any = [];
  branchlookup: ExternalBranch[] = [];
  public financialStatementDescforDropdown: any = [];
  public balanceSheetHeader: any = [];
  public balanceSheetColumnName: string = 'Balance Sheet'
  public clickedRowItem: any;
  public clickedRowColumn: any;
  public multiple = false;
  public allowUnsort = true;
  public sort: SortDescriptor[] = [];
  public gridView: GridDataResult;
  public selectedItem: any;
  public relatedCustomers: any;
  public selectedCustomer: any;
  public changedCustomer: any;
  public state: State = {
  };

  public sortedArray: any;
  financialStatements: ReportStatementSelection[] = [];
  @Input() set selectedReportType (value: any) { }
  @Output() selectedReportEvent = new EventEmitter<ReportStatementSelection[]>()
  public report: ReportStatementSelection
  constructor (
    private store: Store<AppState>,
    private restService: RestService,
    public reportService:ReportService
  ) { }

  ngOnInit (): void {
  }

  ngOnChanges (changes: SimpleChanges) {
    this.fromDate = new Date();
    this.toDate = new Date();
    if (changes.selectedReportType) {
      this.store.pipe(select(reportsData)).subscribe(data => {
        this.reportOptionsMap = data.lookupData.filter(lookupData => {
          return lookupData.Table.TableName == 'tlkpFilteredReportOptionsMap'
        })
        this.filteredFinancialStatementSubType = data.lookupData.filter(lookupData => {
          return lookupData.Table.TableName == 'tlkpFilteredFinancialStatementSubType'
        })
        this.financialSoureType = data.lookupData.filter(lookupData => {
          return lookupData.Table.TableName == 'tslkpFinancialSourceType'
        })
        this.reportService.tslkpFinancialSourceType = this.financialSoureType
        this.reportService.tlkpFilteredReportOptionsMap = this.reportOptionsMap
      })
      this.reportName = this.reportService.SelectedFilteredReport.OverrideReportDesc
      this.reportCde = changes.selectedReportType.currentValue.ReportCde
      if (changes.selectedReportType.currentValue != null && changes.selectedReportType.previousValue?.ReportCde != changes.selectedReportType.currentValue.ReportCde) {
        this.filterReportOptionMap(changes.selectedReportType.currentValue)
        this.selectedReportTypeCde = null
      }
      this.financialStatements = []
      this.batchMode = false
    }
  }
  
  filterReportOptionMap (selectedReport) {
    const reportOptionMap = this.reportOptionsMap[0].LookupData
    for (let i = 0; i < reportOptionMap.length; i++) {
      if (this.selectedReportTypeCde == null) {
        if (reportOptionMap[i].Cde == selectedReport.ReportCde) {
          const reportOption = reportOptionMap[i].ExtendedValues.filter(element => element.Key == 'ReportOptionCde')[0]
          const reportTypeCde = parseInt(reportOption.Value)
          switch (reportTypeCde) {
            case SelectedReportType.BalanceSheetStatementSelection:
            case SelectedReportType.BalanceSheetStatementSelectionNoProjections:
            case SelectedReportType.ProjectionsStatementSelection:
            case SelectedReportType.EarningsStatementSelection:
            case SelectedReportType.EarningsStatementWithLink:
            case SelectedReportType.BalanceSheetConsolidationSelection:
            case SelectedReportType.EarningsStatementConsolidationSelection:
            case SelectedReportType.AdvancedPostCloseFromConsolidationStatementSelection:
            case SelectedReportType.ProjectedConsolidationConsolidatedProjectionStatementSelection:
            case SelectedReportType.BSWorksheetBatchModeSelection:
              this.selectedReportTypeCde = reportTypeCde
              break
          }
          if (this.selectedReportTypeCde) {
            this.selectedReportTypeCdeCopy = this.selectedReportTypeCde;
            this.onReportSelection(this.selectedReportTypeCde);
          }
        }
      }
    }
  }

  public onRelatedCustomersChange (value: any): void {
    this.changedCustomer = value.CustomerBID
    this.reportService.SelectedCustomer = value
    this.financialStatements = [];
    this.onReportSelection(this.selectedReportTypeCdeCopy)
    console.log('selectionChange', value)
  }

  onReportSelection (reportOptionCde) {
    let branches: ExternalBranch[]
    switch (reportOptionCde) {
      case SelectedReportType.BalanceSheetStatementSelection:
        this.restService.post(environment.baseURI + environment.endpoints.retrieveBalanceSheet, { customerBID: this.reportService.SelectedCustomer ? this.reportService.SelectedCustomer.CustomerBID : this.selectedCustomer.CustomerBID, howMany: 999, includeConsolidations: true, includeProjections: true })
          .subscribe(
            result => {
              this.retrievedReports = result
              this.onBalanceSheetsRetrieved(this.retrievedReports)
            }
          )
        break
      case SelectedReportType.BalanceSheetStatementSelectionNoProjections:
        this.restService.post(environment.baseURI + environment.endpoints.retrieveBalanceSheet, { customerBID: this.reportService.SelectedCustomer.CustomerBID ? this.reportService.SelectedCustomer.CustomerBID : this.selectedCustomer.CustomerBID, howMany: 999, includeConsolidations: true, includeProjections: false })
          .subscribe(
            data => {
              this.retrievedReports = data
              this.onBalanceSheetsRetrieved(this.retrievedReports)
            }
          )
        break
      case SelectedReportType.ProjectionsStatementSelection:
        this.restService.post(environment.baseURI + environment.endpoints.retrieveEarnigsStatement, { customerBID: this.reportService.SelectedCustomer.CustomerBID ? this.reportService.SelectedCustomer.CustomerBID : this.selectedCustomer.CustomerBID, howMany: 999, includeConsolidations: true, includeProjections: true })
          .subscribe(
            data => {
              this.retrievedReports = data
              this.onProjectionStatementHeadersRetrieved(this.retrievedReports)
            }
          )
        break
      case SelectedReportType.EarningsStatementSelection:
        this.restService.post(environment.baseURI + environment.endpoints.retrieveEarnigsStatement, { customerBID: this.reportService.SelectedCustomer.CustomerBID ? this.reportService.SelectedCustomer.CustomerBID : this.selectedCustomer.CustomerBID, howMany: 999, includeConsolidations: true, includeProjections: true })
          .subscribe(
            data => {
              this.retrievedReports = data
              this.onEarningsStatementHeadersRetrieved(this.retrievedReports)
            })
        break
      case SelectedReportType.EarningsStatementWithLink:
        this.restService.post(environment.baseURI + environment.endpoints.retrieveBalanceSheet, { customerBID: this.reportService.SelectedCustomer.CustomerBID ? this.reportService.SelectedCustomer.CustomerBID : this.selectedCustomer.CustomerBID, howMany: 999, includeConsolidations: true, includeProjections: true })
          .subscribe(
            data => {
              this.balanceSheetHeader = data
              this.onBalanceSheetHeadersForDropdownRetrieved(this.balanceSheetHeader)
            })
        break
      case SelectedReportType.BalanceSheetConsolidationSelection:
        this.restService.post(environment.baseURI + environment.endpoints.retrieveCustomerConsolidationFinancialStatement, { customerBID: this.reportService.SelectedCustomer.CustomerBID ? this.reportService.SelectedCustomer.CustomerBID : this.selectedCustomer.CustomerBID, includeBS: true, includeES: false, includeActiveGroupsOnly: false })
          .subscribe(
            data => {
              this.retrievedReports = data
              this.onBalanceSheetConsolidationsRetrieved(this.retrievedReports)
            })
        break
      case SelectedReportType.EarningsStatementConsolidationSelection:
        this.restService.post(environment.baseURI + environment.endpoints.retrieveCustomerConsolidationFinancialStatement, { customerBID: this.reportService.SelectedCustomer.CustomerBID ? this.reportService.SelectedCustomer.CustomerBID : this.selectedCustomer.CustomerBID, includeBS: false, includeES: true, includeActiveGroupsOnly: false })
          .subscribe(
            data => {
              this.retrievedReports = data
              this.onEarningsStatementConsolidationsRetrieved(this.retrievedReports)
            })
        break
      case SelectedReportType.AdvancedPostCloseFromConsolidationStatementSelection:
        this.restService.post(environment.baseURI + environment.endpoints.retriveAdvanceBalanceSheetProjection, { customerBID: this.reportService.SelectedCustomer.CustomerBID ? this.reportService.SelectedCustomer.CustomerBID : this.selectedCustomer.CustomerBID })
          .subscribe(
            data => {
              this.retrievedReports = data
              this.onAdvancedPostCloseFromConsolidationRetrieved(this.retrievedReports)
            })
        break
      case SelectedReportType.ProjectedConsolidationConsolidatedProjectionStatementSelection:
        this.restService.post(environment.baseURI + environment.endpoints.retrieveProjectedConsolidationAndConsolidatedProjection, { customerBID: this.reportService.SelectedCustomer.CustomerBID ? this.reportService.SelectedCustomer.CustomerBID : this.selectedCustomer.CustomerBID })
          .subscribe(
            data => {
              this.retrievedReports = data
              this.onProjectedConsolidationConsolidatedProjectionRetrieved(this.retrievedReports)
            })
        break
      case SelectedReportType.BSWorksheetBatchModeSelection:
        this.restService.get(environment.baseURI + environment.endpoints.retrieveBranchLookups)
          .subscribe(
            data => {
              branches = data.RetrieveBranchLookupsResult;
              this.branchesRetrieved(branches)
            });
        break;
    }
  }

  onBalanceSheetsRetrieved (reports) {
    this.createStatementSelection(reports.RetrieveBalanceSheetHeadersByCustomerBIDResult)
    this.showGroupNameColumn = true
    this.showCollateralColumn = true
    this.showSourceColumn = false
    this.showLinkedBalancesheet = false
    console.log('onBalanceSheet', reports)
  }

  onProjectionStatementHeadersRetrieved (reports) {
    let gridItems = reports.RetrieveEarningsStatementHeadersByCustomerBIDResult.filter(rp => rp.FinancialStatementSubTypeCde === FinancialStatementSubType.EarningsStatementProjection)
    this.createStatementSelection(gridItems)
    this.showSourceColumn = true
    this.showGroupNameColumn = this.showCollateralColumn = this.showLinkedBalancesheet = false
    console.log('onProjectionStatementHeaders', reports)
  }

  onEarningsStatementHeadersRetrieved (reports) {
    this.createStatementSelection(reports.RetrieveEarningsStatementHeadersByCustomerBIDResult)
    this.showGroupNameColumn = true
    this.showLinkedBalancesheet = this.showCollateralColumn = false
    this.showSourceColumn = true // need to get this like ShowSourceSelection = ReportsOption.CashAndAccrualMix;
    console.log('EarningsStatementHeadersRetrieved', reports)
  }

  onBalanceSheetHeadersForDropdownRetrieved (reports) {
    reports.RetrieveBalanceSheetHeadersByCustomerBIDResult.forEach(rpt => {
      const jsonDate = rpt.FinancialStatementStartDte
      const parsedDate = new Date(parseInt(jsonDate.substr(6)))
      const financialStatementEndDte = moment(parsedDate).format('MM/DD/YYYY')
      rpt.FinancialStatementDescforDropdown = '[' + financialStatementEndDte + '] ' + rpt.FinancialStatementDesc
      this.financialStatementDescforDropdown.push('[' + financialStatementEndDte + '] ' + rpt.FinancialStatementDesc)
    })
    this.balanceSheetHeader = reports.RetrieveBalanceSheetHeadersByCustomerBIDResult
    this.restService.post(environment.baseURI + environment.endpoints.retrieveEarnigsStatement, { customerBID: this.reportService.SelectedCustomer.CustomerBID ? this.reportService.SelectedCustomer.CustomerBID : this.selectedCustomer.CustomerBID, howMany: 999, includeConsolidations: true, includeProjections: true })
      .subscribe(
        data => {
          this.retrievedReports = data
          this.onEarningsStatementHeadersWithLinksRetrieved(this.retrievedReports)
        })
    console.log('BalanceSheetHeadersForDropdownRetrieved', reports)
    console.log('BalanceSheet header for dropdown', reports)
  }

  onEarningsStatementHeadersWithLinksRetrieved (reports) {
    this.createStatementSelection(reports.RetrieveEarningsStatementHeadersByCustomerBIDResult)
    this.showLinkedBalancesheet = this.showGroupNameColumn = true
    this.showCollateralColumn = false
    this.showSourceColumn = true // need to get this like ShowSourceSelection = ReportsOption.CashAndAccrualMix;
    console.log('EarningsStatementConsolidationsRetrieved', reports)
  }

  onEarningsStatementConsolidationsRetrieved (reports) {
    // ToDo //set financial groups
    const statementHeaders: any = []
    const groups = []
    reports.RetrieveCustomerConsolidationFinancialStatementHeadersResult.forEach(fs => {
      fs.FinancialStatements.forEach(element => {
        statementHeaders.push(element)
      })
      groups.push(fs.Group)
    })
    for (let i = 0; i < statementHeaders.length; i++) {
      statementHeaders[i].Group = groups[i]
    }
    this.createStatementSelection(statementHeaders)
    this.showSourceColumn = this.showGroupNameColumn = true
    this.showLinkedBalancesheet = this.showLinkedBalancesheet = this.showCollateralColumn = false
    console.log('EarningsStatementConsolidationsRetrieved', reports)
  }

  onAdvancedPostCloseFromConsolidationRetrieved (reports) {
    this.createStatementSelection(reports.RetrieveAdvancedBalanceSheetProjectionHeadersFromConsolidationsByCustomerBIDResult)
    this.showGroupNameColumn = true
    this.showSourceColumn = this.showLinkedBalancesheet = this.showCollateralColumn = false
    console.log('AdvancedPostCloseFromConsolidationRetrieved', reports)
  }

  onBalanceSheetConsolidationsRetrieved (reports) {
    // ToDo Set financial groups
    const statementHeaders: any = []
    const groups = []
    reports.RetrieveCustomerConsolidationFinancialStatementHeadersResult.forEach(fs => {
      fs.FinancialStatements.forEach(element => {
        statementHeaders.push(element)
      })
      groups.push(fs.Group)
    })
    for (let i = 0; i < statementHeaders.length; i++) {
      statementHeaders[i].Group = groups[i]
    }
    this.createStatementSelection(statementHeaders)
    this.showGroupNameColumn = true
    this.showSourceColumn = this.showLinkedBalancesheet = this.showCollateralColumn = false
    console.log('BalanceSheetConsolidationsRetrieved', reports)
  }

  onProjectedConsolidationConsolidatedProjectionRetrieved (reports) {
    this.createStatementSelection(reports.RetrieveProjectedConsolidationAndConsolidatedProjectionHeadersByCustomerBIDResult)
    this.showGroupNameColumn = true
    this.showSourceColumn = this.showLinkedBalancesheet = this.showCollateralColumn = false
    console.log('ProjectedConsolidationConsolidatedProjectionRetrieved', reports)
  }

  branchesRetrieved (branches) {
    this.batchMode = true
    branches.forEach(branch => {
      this.branchlookup.push(branch);
    });
    if (this.reportService.IsBSBatchmodeSelected) {
      for (let i = 0; i < this.reportService.SelectedParentReportGrid.Branches.length; i++) {
        this.selectedBranches = branches.filter(br => {
          if (br.BranchID == this.reportService.SelectedParentReportGrid.Branches[i]) { return br }
        })
      }
      this.reportService.IsBSBatchmodeSelected = false;
      this.fromDate = this.reportService.SelectedParentReportGrid.OrderFinancials[0].fromDate
      this.toDate = this.reportService.SelectedParentReportGrid.OrderFinancials[0].toDate
      this.onBSBatchmodeReportSelected()
    } else {
      this.fromDate.setFullYear(this.fromDate.getFullYear() - 1);
      this.toDate = new Date();
      this.selectedBranches = null;
    }
  }

  onBSBatchmodeReportSelected () {
    const fdate = '/Date(' + this.fromDate.getTime() + ')/';
    const tdate = '/Date(' + this.toDate.getTime() + ')/';
    this.restService.post(environment.baseURI + environment.endpoints.retrieveBalanceSheetHeadersByDateandBranches, { StartDate: fdate, EndDate: tdate, SelectedBranches: this.selectedBranches })
      .subscribe(
        data => {
          const balanceSheetHeaders = data
          this.createStatementSelection(balanceSheetHeaders.RetrieveBalanceSheetHeadersByDateandBranchesResult)
        });
  }

  createStatementSelection (reportheaders) {
    if(reportheaders){
    for (let i = 0; i < reportheaders.length; i++) {
      if (reportheaders[i].FinancialStatementSubTypeCde == FinancialStatementSubType.BalanceSheet ||
        reportheaders[i].FinancialStatementSubTypeCde == FinancialStatementSubType.BalanceSheetAdvancedPostClose ||
        reportheaders[i].FinancialStatementSubTypeCde == FinancialStatementSubType.BalanceSheetAdvancedProforma ||
        reportheaders[i].FinancialStatementSubTypeCde == FinancialStatementSubType.BalanceSheetSimplePostClose ||
        reportheaders[i].FinancialStatementSubTypeCde == FinancialStatementSubType.BalanceSheetSimpleProforma ||
        reportheaders[i].FinancialStatementSubTypeCde == FinancialStatementSubType.BalanceSheetConsolidation) {
        var isBS = true
      }
      this.report = {
        FinancialStatementBID: reportheaders[i].FinancialStatementBID,
        FinancialStatementDesc: reportheaders[i].FinancialStatementDesc,
        CustomerBID: reportheaders[i].CustomerBID,
        CustomerEID: reportheaders[i].Customer?.CustomerEID,
        CustomerName: reportheaders[i].Customer?.CustomerName,
        CustomerDisplayName: reportheaders[i].Customer?.DisplayName,
        SpouseName: reportheaders[i].Customer?.SpouseRelation?.SpouseName,
        BranchID: reportheaders[i].Customer?.BranchID,
        PrimaryLoanOfficer: reportheaders[i].Customer?.PrimaryLoanOfficer,
        FinancialStatementSubTypeCde: reportheaders[i].FinancialStatementSubTypeCde,
        FinancialStatementEndDte: reportheaders[i].FinancialStatementEndDte,
        FinancialStatementStartDte: reportheaders[i].FinancialStatementStartDte,
        FinancialSourceTypeCde: reportheaders[i].FinancialSourceTypeCde,
        CollateralStatementInd: reportheaders[i].FinancialStatementSubTypeCde == FinancialStatementSubType.BalanceSheet && reportheaders[i].CollateralStatementInd == true,
        GroupBID: reportheaders[i].GroupBID,
        OpeningBSFinancialStatementBID: reportheaders[i].OpeningBSFinancialStatementBID,
        ClosingBSFinancialStatementBID: reportheaders[i].ClosingBSFinancialStatementBID,
        GroupName: reportheaders[i].Group?.GroupNameTxt,
        IsProjection: reportheaders[i].FinancialStatementSubTypeCde == (FinancialStatementSubType.EarningsStatementProjection ||
          FinancialStatementSubType.BalanceSheetAdvancedPostClose ||
          FinancialStatementSubType.BalanceSheetAdvancedProforma),
        IsConsolidation: reportheaders[i].FinancialStatementSubTypeCde == (FinancialStatementSubType.BalanceSheetConsolidation ||
          FinancialStatementSubType.EarningsStatementConsolidation),
        BranchName: this.selectedBranches?.filter(sb => {
          return sb.BranchID == reportheaders[i].Customer?.BranchID
        }).shift()?.BranchName,
        AllowMixedSource: false,
        IsCashToAccrualEnabled: this.reportService.IsCashToAccrualEnabled,
        DisplayDate: null,
        FinancialStatementSubTypeDesc: this.filteredFinancialStatementSubType[0].LookupData.filter(subType => subType.Cde == reportheaders[i].FinancialStatementSubTypeCde).shift().Desc,
        HasClosingBS: reportheaders[i].ClosingBSFinancialStatementBID != (null || undefined),
        HasOpeningBS: reportheaders[i].OpeningBSFinancialStatementBID != (null || undefined),
        LinkedFinancialStatementDesc: null,
        IsSelected: false,
        EnableDropdown: false,
        ReportCollateralCheckboxVisibility: !!((reportheaders[i].FinancialStatementSubTypeCde == FinancialStatementSubType.BalanceSheet ||
                                            reportheaders[i].FinancialStatementSubTypeCde == FinancialStatementSubType.BalanceSheetSimplePostClose))
      }
      if (isBS) {
        this.report.LinkedFinancialStatementBID = reportheaders[i].OpeningBSFinancialStatementBID
        this.report.LinkedFinancialStatementDesc = this.getBalanceSheetDesc(reportheaders[i].OpeningBSFinancialStatementBID)
      } else if (!isBS) {
        this.report.LinkedFinancialStatementBID = reportheaders[i].ClosingBSFinancialStatementBID
        this.report.LinkedFinancialStatementDesc = this.getBalanceSheetDesc(reportheaders[i].ClosingBSFinancialStatementBID)
      }
      this.report.FinancialSourceTypeDesc = this.financialSoureType[0].LookupData.filter(sctype => sctype.Cde == reportheaders[i].FinancialSourceTypeCde).shift()?.Desc
      this.report.AllowMixedSource = this.reportService.IsCashToAccrualEnabled && this.report.HasClosingBS && this.report.HasOpeningBS
      if (this.report.FinancialStatementStartDte == this.report.FinancialStatementEndDte) {
        const displaydate = new Date(parseInt(this.report.FinancialStatementStartDte.substr(6)))
        this.report.DisplayDate = moment(displaydate).format('MM/DD/YYYY')
      } else if (this.report.FinancialStatementStartDte != this.report.FinancialStatementEndDte) {
        const startDate = new Date(parseInt(this.report.FinancialStatementStartDte.substr(6)))
        const endDate = new Date(parseInt(this.report.FinancialStatementEndDte.substr(6)))
        this.report.DisplayDate = moment(startDate).format('MM/DD/YYYY') + '-' + moment(endDate).format('MM/DD/YYYY')
      }
      if (this.batchMode) {
        this.report.fromDate = this.fromDate
        this.report.toDate = this.toDate
      }
      this.financialStatements.push(this.report)
    }
  }
    this.removeInvalidStatementsForReports(this.financialStatements, this.reportCde)
  }

  removeInvalidStatementsForReports (financialStatementHeaders, selectedReportTypeCde) {
    if (selectedReportTypeCde == (Reports.NetWorthReconciliation ||
      Reports.NetWorthReconciliationTrend ||
      Reports.NetWorthReconciliationWorkingCapital)) {
      this.financialStatements = financialStatementHeaders.filter(fst => {
        return fst.FinancialSourceTypeCde == FinancialSourceTypes.Accrual && (fst.IsCashToAccrualEnabled || fst.AllowMixedSource)
      })
    } else if (selectedReportTypeCde == Reports.CollateralAppraisalWorksheetReport) {
      this.financialStatements = financialStatementHeaders.filter(fst => {
        return fst.CollateralStatementInd == true
      })
    } else if (selectedReportTypeCde == Reports.BalanceSheetWorksheet) {
      this.financialStatements = financialStatementHeaders.filter(fst => {
        return fst.FinancialStatementSubTypeCde == FinancialStatementSubType.BalanceSheet
      })
    }
    this.removeInvalidStatementTypes(this.financialStatements)
  }

  removeInvalidStatementTypes (financialStatements) {
    switch (this.selectedReportTypeCde) {
      case SelectedReportType.AdvancedPostCloseFromConsolidationStatementSelection:
        this.financialStatements = financialStatements.filter(fs => {
          return (fs.FinancialStatementSubTypeCde == FinancialStatementSubType.BalanceSheetAdvancedPostClose ||
            fs.FinancialStatementSubTypeCde == FinancialStatementSubType.BalanceSheetAdvancedProforma)
        })
        break
      case SelectedReportType.ProjectedConsolidationConsolidatedProjectionStatementSelection:
        this.financialStatements = financialStatements.filter(fs => {
          return (fs.FinancialStatementSubTypeCde == FinancialStatementSubType.EarningsStatementProjection ||
            fs.FinancialStatementSubTypeCde == FinancialStatementSubType.EarningsStatementConsolidation)
        })
        break
      case SelectedReportType.ProjectionsStatementSelection:
        this.financialStatements = financialStatements.filter(fs => {
          return (fs.FinancialStatementSubTypeCde == FinancialStatementSubType.EarningsStatementProjection)
        })
        break
      case SelectedReportType.BalanceSheetConsolidationSelection:
        this.financialStatements = financialStatements.filter(fs => {
          return (fs.FinancialStatementSubTypeCde == FinancialStatementSubType.BalanceSheetConsolidation)
        })
        break
      case SelectedReportType.EarningsStatementConsolidationSelection:
        this.financialStatements = financialStatements.filter(fs => {
          return (fs.FinancialStatementSubTypeCde == FinancialStatementSubType.EarningsStatementConsolidation)
        })
        break
      case SelectedReportType.BalanceSheetStatementSelection:
        this.financialStatements = financialStatements.filter(fs => {
          return (fs.FinancialStatementSubTypeCde == FinancialStatementSubType.BalanceSheet ||
            fs.FinancialStatementSubTypeCde == FinancialStatementSubType.BalanceSheetConsolidation ||
            fs.FinancialStatementSubTypeCde == FinancialStatementSubType.BalanceSheetAdvancedPostClose ||
            fs.FinancialStatementSubTypeCde == FinancialStatementSubType.BalanceSheetAdvancedProforma ||
            fs.FinancialStatementSubTypeCde == FinancialStatementSubType.BalanceSheetSimplePostClose ||
            fs.FinancialStatementSubTypeCde == FinancialStatementSubType.BalanceSheetSimpleProforma)
        })
        break
      case SelectedReportType.BalanceSheetStatementSelectionNoProjections:
        this.financialStatements = financialStatements.filter(fs => {
          return (fs.FinancialStatementSubTypeCde == FinancialStatementSubType.BalanceSheet ||
            fs.FinancialStatementSubTypeCde == FinancialStatementSubType.BalanceSheetConsolidation)
        })
        break
      case SelectedReportType.EarningsStatementSelection:
        this.financialStatements = financialStatements.filter(fs => {
          return (fs.FinancialStatementSubTypeCde == FinancialStatementSubType.EarningsStatement ||
            fs.FinancialStatementSubTypeCde == FinancialStatementSubType.EarningsStatementConsolidation ||
            fs.FinancialStatementSubTypeCde == FinancialStatementSubType.EarningsStatementProjection ||
            fs.FinancialStatementSubTypeCde == FinancialStatementSubType.EarningsStatementSimpleProjection)
        })
        break
      case SelectedReportType.EarningsStatementWithLink:
        this.financialStatements = financialStatements.filter(fs => {
          return (fs.FinancialStatementSubTypeCde == FinancialStatementSubType.EarningsStatement ||
            fs.FinancialStatementSubTypeCde == FinancialStatementSubType.EarningsStatementConsolidation ||
            fs.FinancialStatementSubTypeCde == FinancialStatementSubType.EarningsStatementProjection ||
            fs.FinancialStatementSubTypeCde == FinancialStatementSubType.EarningsStatementSimpleProjection)
        })
        break
    }
    this.reportService.GridItems = this.financialStatements
    this.reportService.showSelectedReportGridAfterLoad = true
    if (this.reportService.GridItems) {
      if (this.reportService.showSelectedReportGridAfterLoad) {
        this.reportService.UpdateIsSelectable(this.reportService.ReportsOption)
        this.reportService.ShowReportGridReport()
        this.reportService.showSelectedReportGridAfterLoad = false
      }
    }
  }

  onSubmit () {
    const fdate = '/Date(' + this.fromDate.getTime() + ')/'
    const tdate = '/Date(' + this.toDate.getTime() + ')/'
    this.restService.post(environment.baseURI + environment.endpoints.retrieveBalanceSheetHeadersByDateandBranches, { StartDate: fdate, EndDate: tdate, SelectedBranches: this.selectedBranches })
      .subscribe(
        data => {
          const balanceSheetHeaders = data
          this.createStatementSelection(balanceSheetHeaders.RetrieveBalanceSheetHeadersByDateandBranchesResult)
          console.log('branches reports', balanceSheetHeaders)
        })
    this.reportService.SelectedBranches = this.selectedBranches.map(sb => sb.BranchID)
  }

  getBalanceSheetDesc (linkedFinancialStatementBID) {
    if (linkedFinancialStatementBID) {
      const financialstatementDesc = this.balanceSheetHeader.RetrieveBalanceSheetHeadersByCustomerBIDResult?.filter(bsh => {
        return bsh.FinancialStatementBID == linkedFinancialStatementBID
      }).shift()?.FinancialStatementDesc
      return financialstatementDesc
    }
  }

  onCellClick (e) {
    this.clickedRowItem = e.dataItem
    this.clickedRowColumn = e.column.title
    if (this.selectedItem) {
      this.financialStatements.forEach(fs => {
        if (fs.EnableDropdown == true) {
          fs.LinkedFinancialStatementBID = this.selectedItem.FinancialStatementBID
        }
      })
    }
    if (this.clickedRowItem.LinkedFinancialStatementBID) {
      const selectedLinkedBalanceSheet = this.balanceSheetHeader.find(bsh => bsh.FinancialStatementBID == this.clickedRowItem.LinkedFinancialStatementBID)
      this.selectedItem = selectedLinkedBalanceSheet
    }
    this.financialStatements.forEach(fs => {
      if (fs.FinancialStatementBID != e.dataItem.FinancialStatementBID || this.clickedRowColumn != this.balanceSheetColumnName) { fs.EnableDropdown = false }
    })
    if (this.clickedRowItem.LinkedFinancialStatementBID == null) {
      this.selectedItem = null
    }
  }

  onDblClick () {
    if (this.balanceSheetHeader[0].FinancialStatementBID != -1) {
      this.balanceSheetHeader.unshift({ FinancialStatementDescforDropdown: 'None', FinancialStatementBID: -1 })
    }
    for (let i = 0; i < this.financialStatements.length; i++) {
      if (this.financialStatements[i].FinancialStatementBID == this.clickedRowItem.FinancialStatementBID &&
        this.balanceSheetColumnName == this.clickedRowColumn) {
        this.financialStatements[i].EnableDropdown = true
      }
    }
    console.log('double click')
  }

  public sortChange (sort: SortDescriptor[]): void {
    this.sort = sort
    this.loadFinancialStatements()
  }

  public dataStateChange (state: DataStateChangeEvent): void {
    this.state = state
    if (this.gridView) {
      this.gridView = process(this.sortedArray, this.state)
    } else {
      this.gridView = process(this.financialStatements, this.state)
    }
  }

  private loadFinancialStatements (): void {
    this.gridView = {
      data: orderBy(this.financialStatements, this.sort),
      total: this.financialStatements.length
    }
    this.sortedArray = this.gridView.data
    console.log(this.gridView)
  }

  getLinkedBalanceSheet (linkedBalanceSheetId) {
    if (linkedBalanceSheetId) {
      return this.balanceSheetHeader.find(bsh => bsh.FinancialStatementBID == linkedBalanceSheetId)
    }
  }

  onChange (FinancialStatementBID: number) {
    if (this.reportService.SelectedParentReportGrid != null && this.reportService.GridItems != null) {
      this.reportService.UpdateStatementsInReport(FinancialStatementBID, this.reportService.SelectedParentReportGrid);
      this.reportService.UpdateStatementsOrder(this.reportService.SelectedParentReportGrid);
      this.reportService.BuildConcatenatedReportLabel(this.reportService.SelectedParentReportGrid);
    }
  }

  public itemDisabled (itemArgs: { dataItem: any; index: number }) {
    return itemArgs.dataItem.FinancialStatementBID == -1
  }
}