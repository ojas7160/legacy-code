import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'uc-report-content',
  templateUrl: './report-content.component.html',
  styleUrls: ['./report-content.component.scss']
})
export class ReportContentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
