import { Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core'
import { DTOAction } from '../../../enum'
import {
  Report, ReportOptions, ReportFinancialStatement, MyFarmReportValidator,
  DcWebBalanceSheetRequest
} from '../../../models/BottomGridReport'
import { ReportOption, Reports } from '../../../enum/reportSelection'
import { ListReport } from '../../../models/ListReport'

import { KendoModalService, RestService } from '../../../services'
import { environment } from '../../../../../../CreditPro/src/environments/environment'
import { Parameters } from '../../../enum/parameters'
import { ReportService } from '../../../services/report/report.service'
import { ReportExportService } from '../../../services/report/report-export.service'
import { DcCustomer } from '../../../models/customer'
import { AlertDialogComponent } from '../..'
import { AppConstant } from '../../../constants/app-constants'

@Component({
  selector: 'uc-report-bottom-grid',
  templateUrl: './report-bottom-grid.component.html',
  styleUrls: ['./report-bottom-grid.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ReportBottomGridComponent implements OnInit {
  bundlewindowOpened: boolean = false;
  popoverIsVisible: boolean = false;
  isPopoverButtonClicked: boolean = false;
  IsVisibleColumnOrderdialog: boolean = false;
  Headers: ReportFinancialStatement[];

  DeleteIsChecked: boolean;
  BundleName:string = '';

  get IsArchivable (): boolean {
    return this.reportService.ReportBundle != null &&
    !this.reportService.ReportBundle.filter(r => r.FilteredReport.ReportCde == Reports.BalanceSheetWorksheetBatch)
  }

  get CanExcludeChartOfAccounts (): boolean {
    const canExclude: boolean =
      this.reportService.ReportsOption.VisibleOptions.indexOf(ReportOption.IncludeDetailSchedules) > 0 &&
      this.reportService.ReportsOption.IncludeDetailSchedules &&
      this.reportService.GridItems != null && this.reportService.GridItems.some(a => a.IsSelected)

    if (!canExclude) { this.reportService.ReportsOption.ExcludedChartOfAccountCdes = [] }

    return canExclude
  }

  get CanSubmittoWeb (): boolean {
    return this.reportService.ReportBundle != null &&
      this.reportService.ReportBundle.some(r =>
        r.Action != DTOAction.Delete &&
        (r.StatementType == ReportOption.BSWorksheetBatchModeSelection || r.FilteredReport.ReportCde == Reports.BalanceSheetWorksheet || r.FilteredReport.ReportCde == Reports.BalanceSheetWorksheetBatch))
  }

  dateFormat: string = AppConstant.dateFormat

  constructor (private restService: RestService, public reportService: ReportService,
    public reportServicePrintPdf: ReportExportService, private kendoModalService: KendoModalService) { }

  ngOnInit (): void {
    this.restService.post(environment.baseURI + environment.endpoints.retrieveParms, { parms: [Parameters.EnableEmPOWERReportBundleArchive] })
      .subscribe(
        result => {
          this.reportService.EnableEmPOWERArchive = result.RetrieveParmsResult.shift().ParmValInd
        }
      )
    this.reportService.SelectedBenchmarkStatements = []
  }

  AddReportToList () {
    const errors: string[] = []
    const report = this.CreateReport(this.reportService.SelectedCustomer, this.reportService.SelectedFilteredReport, false, errors)
    if (report != null && errors.length == 0) {
      this.BuildStatementsAndAddToBundle(report)
    } else {
      let errorObj
      errors.forEach(e => {
        errorObj = {
          key: 'Add Report',
          value: e
        }
        this.reportService.commonService.errorObjs.push(errorObj)
      })
      this.reportService.commonService.ErrorData(this.reportService.commonService.errorObjs, 'Errors')
    }
  }

  CreateReport (customer: DcCustomer, report: ListReport, addToBundle: boolean, errors: string[]): Report {
    if (this.reportService.ReportBundle != null && this.reportService.GridItems != null) {
      const r: Report = new Report()
      r.Action = DTOAction.Insert
      r.Customer = customer
      r.FilteredReport = report
      r.Options = new ReportOptions(this.reportService.ReportsOption)
      r.SequenceNum = this.reportServicePrintPdf.GetNextSequenceNum()
      r.DisplayOrder = this.reportService.ReportBundle.length > 0 ? Math.max(...this.reportService.ReportBundle.map(rb => rb.DisplayOrder)) + 1 : 1
      r.IsColumnOrderEnabled = this.reportService.TrendStyleReports(r.FilteredReport.ReportCde)

      // let editColumnOrderOnAdd: boolean = false

      if (report.ReportCde == Reports.BalanceSheetWorksheetBatch) {
        const res = this.reportService.GridItems.filter(g => g.IsSelected).sort((a, b) => a.CustomerName.localeCompare(b.CustomerName))
        if (res.length == 0) {
          errors.push('Balance Sheet Worksheet (Batch) requires at least one statement')
          return null
        } else {
          res.forEach(g => this.reportService.PopulateReportFromStatementSelection(g, r))
          r.Branches.push(...this.reportService.SelectedBranches)
        }
      } else {
        const selected = this.reportService.GridItems.filter(g => g.IsSelected)

        if (report.ReportCde == Reports.MyFarmAnalysis) {
          const hasClosingBS = selected.length > 0 && selected[0].HasClosingBS
          const industryTemplates = this.reportService.SelectedBenchmarkStatements
            .map(s => this.reportService.GetBenchmarkIndustryTemplate(s.FinancialStatementBID))

          const validator = new MyFarmReportValidator(selected.length, this.reportService.SelectedBenchmarkStatements.length,
            hasClosingBS, industryTemplates, this.reportService.tlkpBenchmarkIndustryTemplate)

          const validationErrors: string[] = []
          if (!validator.Validate(validationErrors)) {
            validationErrors.forEach(v => {
              errors.push(v)
            })
            return null
          } else {
            // editColumnOrderOnAdd = validator.IsDairy
            r.ShowCheckboxColumnInColumnOrderModal = validator.IsDairy
            if (r.ShowCheckboxColumnInColumnOrderModal) {
              r.ColumnOrderModalCheckboxColumnHeader = 'Benchmark Comparison'
              r.ColumnOrderModalCheckboxColumnCellTemplate = 'cbBenchmarkComparison'
            }
            // this.BuildCompositeReport(r, selected);
          }
        } else if (report.ReportCde == Reports.ProfilerReport) {
          if (selected.length < 2 || selected.length > 6) {
            errors.push('Profiler Report requires at least two and up to six Statements selected')
            return null
          }

          r.ShowCheckboxColumnInColumnOrderModal = true
          r.ColumnOrderModalCheckboxColumnHeader = 'Primary Statement'
          r.ColumnOrderModalCheckboxColumnCellTemplate = 'cbPrimaryTemplate'

          // BuildCompositeReport(r, selected);
        } else {
          if (report.ReportCde == Reports.BalanceSheetVariance || report.ReportCde == Reports.EarningsVariance) {
            if (selected.length + this.reportService.SelectedBenchmarkStatements.length != 2) {
              errors.push('Variance Report requires two statements')
              return null
            }
          }

          selected.forEach(g => this.reportService.PopulateReportFromStatementSelection(g, r))
        }
      }

      if (r.Options.IsBenchmarkEnabled) {
        this.reportService.SelectedBenchmarkStatements.forEach(fs => {
          this.reportService.ReportBundleSelectedBenchmarks(r, fs)
        })
      }

      if (addToBundle) {
        this.BuildStatements(r)
        this.reportService.ReportBundle.push(r)
      }

      return r
    }

    return null
  }


  BuildStatementsAndAddToBundle (r: Report) {
    this.BuildStatements(r)
    this.AddReportBundle(r)
    this.reportService.SetSavedReportBundleChanged()
  }

  BuildStatements (r: Report) {
    this.reportService.SelectedBenchmarkStatements.forEach(fs => {
      this.reportService.ReportBundleSelectedBenchmarks(r, fs)
    })

    r.ComponentReports.forEach(comp => {
      this.reportService.UpdateComponentReport(comp)
    })

    this.reportService.UpdateStatementsOrder(r)
    this.reportService.BuildConcatenatedReportLabel(r)
  }

  AddReportBundle (r: Report) {
    this.reportService.ReportBundle.push(r)
    this.reportService.SelectedReportGrid = null
    this.reportService.SelectedParentReportGrid = null
    if (!this.IsArchivable) { this.reportService.IsArchiveBundleToEmPOWERBinder = false }
  }

  GetBalanceSheetDesc (bid?: number): string {
    if (bid && this.reportService.BalanceSheetHeaders != null) { return this.reportService.BalanceSheetHeaders.find(b => b.FinancialStatementBID == bid)?.FinancialStatementDesc } else { return null }
  }

  rowCallback (dataItem) {
    if (dataItem.dataItem.IsSelected) { return { selecteddRow: dataItem.dataItem.IsSelected } } else { return { deselecteddRow: !dataItem.dataItem.IsSelected } }
  }

  cellClickHandler ({
    sender,
    rowIndex,
    columnIndex,
    dataItem,
    isEdited
  }) {
    if (dataItem && rowIndex >= 0) {
      this.trClick(dataItem);
    }
    if (!isEdited && ((columnIndex == 9 && this.reportService.Convert(dataItem.Options, 9)) ||
                      (columnIndex == 10 && this.reportService.Convert(dataItem.Options, 10)) ||
                      (columnIndex == 11 && this.reportService.Convert(dataItem.Options, 15)))) {
      sender.editCell(rowIndex, columnIndex, this.reportService)
    }
  }

  trClick(dataItem) {
    this.reportService.SelectedReportGrid = dataItem
    if (dataItem.FilteredReport.OverrideReportDesc == 'Balance Sheet Update Worksheet (Batch Mode)') {
      this.reportService.IsBSBatchmodeSelected = true
    }
  }

  SaveAsReportBundle = function () {
    this.bundlewindowOpened = true
    this.reportService.WindowPopupOpened = true
    this.BundleName = ''
  }

  RetrieveBundleName (BundleName: string) {
    // let error: string
    this.reportService.ReportBundleName = BundleName
    this.reportService.ReportBundleBID = null
    let alertwindowOpened: boolean
    // duplicate report bundle name validation
    this.reportService.ReportTemplateTreeSource[this.reportService.TemplateList_CustomerBundles].ReportTemplates.forEach(item => {
      if (item.ReportBundleName == this.reportService.ReportBundleName) {
        alertwindowOpened = true
        const params = {
          title: AppConstant.alertTitle,
          width: AppConstant.alertWidth,
          height: AppConstant.alertHeight
        }
        const dialog: any = this.kendoModalService.open('dialog', 'alertDialog', AlertDialogComponent, params)
        const dialogBodyContent = dialog.content.instance;
        dialogBodyContent.body = 'This report bundle label is already used. Please make a new label.';
        dialogBodyContent.showCancelbtn = false;
        dialogBodyContent.alertImgshow = true;
      }
    })
    if (!alertwindowOpened) {
      this.reportService.templateLoaded = false
      this.reportService.savedBundleHasChanges = false
      this.reportServicePrintPdf.SaveReportBundle()
      this.DeleteIsChecked = false
    }
    alertwindowOpened = false;
  }

  onKeyDownEventtxtBundleLable (event: any) {
    if (!this.reportService.IsReportLabelReadOnly) { this.reportService.SetSavedReportBundleChanged() }
  }

  CancelModalCommand () {
    this.bundlewindowOpened = false
    this.reportService.WindowPopupOpened = false
  }

  SaveModalCommand (BundleName: string) {
    // this.BundleLable = true
    this.bundlewindowOpened = false
    this.reportService.WindowPopupOpened = false
    this.RetrieveBundleName(BundleName)
  }

  onDeleteButtonview () {
    // this.IsDeleteButtonview = !this.IsDeleteButtonview
    this.DeleteIsChecked = !this.DeleteIsChecked
  }

  onDeletewindowopen () {
    this.reportService.deletewindowOpened = true
    this.reportService.WindowPopupOpened = true
    this.DeleteIsChecked = !this.DeleteIsChecked
  }

  onDeletewindowclose () {
    this.reportService.deletewindowOpened = false
    this.reportService.WindowPopupOpened = false
  }

  SubmittoWeb () {
    if (this.reportService.ReportBundle != null && this.reportService.ReportBundle.filter(r => r.Action != DTOAction.Delete && (r.StatementType == ReportOption.BSWorksheetBatchModeSelection || r.FilteredReport.ReportCde == Reports.BalanceSheetWorksheet || r.FilteredReport.ReportCde == Reports.BalanceSheetWorksheetBatch)).length > 0) {
      const webBalanceSheetRequests: DcWebBalanceSheetRequest[] = []
      this.reportService.ReportBundle.filter(rb => rb.StatementType == ReportOption.BSWorksheetBatchModeSelection || rb.FilteredReport.ReportCde == Reports.BalanceSheetWorksheet || rb.FilteredReport.ReportCde == Reports.BalanceSheetWorksheetBatch).forEach(rb => {
        rb.FinancialStatements.forEach(fs => {
          const bsr: DcWebBalanceSheetRequest = new DcWebBalanceSheetRequest()
          bsr.FinancialStatementBID = fs.FinancialStatementBID
          bsr.FinancialStatementDesc = fs.FinancialStatementDesc
          bsr.FinancialStatementEndDate = fs.FinancialStatementEndDte
          bsr.PrimaryNamedPartyOID = fs.CustomerEID ?? ''
          if (!bsr.PrimaryNamedPartyOID) { bsr.CustomerBID = rb.Customer.CustomerBID }
          webBalanceSheetRequests.push(bsr)
        })
      })

      if (webBalanceSheetRequests.length > 0) {
        this.restService.post(environment.baseURI + environment.endpoints.submittoWeb, { webBalanceSheetRequests: webBalanceSheetRequests })
          .subscribe(
            result => {
              this.OnSubmittoWeb(result)
            }
          )
        // iReportRepository.SubmittoWeb(webBalanceSheetRequests, new ReturnResult<DcGenericFault>(OnSubmittoWeb));
      }
    }
  }

  OnSubmittoWeb (callback) {
    if (!callback.Errors) {
        const params = {
          title: AppConstant.submittoWebTitle,
          width: AppConstant.submittoWebWidth,
          height: AppConstant.alertHeight
        }
        const dialog: any = this.kendoModalService.open('dialog', 'alertDialog', AlertDialogComponent, params)
        const dialogBodyContent = dialog.content.instance;
        dialogBodyContent.body = 'Request submitted successfully';
        dialogBodyContent.showCancelbtn = false;
        dialogBodyContent.alertImgshow = false;
    } else {
      let errorObj
      errorObj = {
        key: callback.Errors.DisplayName,
        value: callback.Errors.ErrorMessage
      }
      this.reportService.commonService.errorObjs.push(errorObj)
      this.reportService.commonService.ErrorData(this.reportService.commonService.errorObjs, 'Errors')
    }
  }

  showPopover () {
    if (!this.isPopoverButtonClicked) {
      this.popoverIsVisible = true
    }
  }

  hidePopover () {
    if (!this.isPopoverButtonClicked) {
      this.popoverIsVisible = false
    }
  }

  onPopoverButtonClick () {
    this.isPopoverButtonClicked = true
    this.popoverIsVisible = true
  }

  ondialogclose () {
    this.isPopoverButtonClicked = false
    this.popoverIsVisible = false
    this.pos1 = 495
    this.pos2 = 225
  }

  MoveReportUp (r: Report, reports?: Report[]) {
    if (!reports) {
      if (r.ParentSequenceNum) {
        const parent = this.reportService.ReportBundle.filter(f => f.SequenceNum == r.ParentSequenceNum)[0]
        this.MoveReportUp(r, parent.ComponentReports)
      } else {
        this.MoveReportUp(r, this.reportService.ReportBundle)
      }
    } else { var upReports = reports.filter(rb => rb.DisplayOrder < r.DisplayOrder) }
    if (upReports != null && upReports.length > 0) {
      const diplayOrder: number = r.DisplayOrder
      const swapReport = reports.filter(rb => rb.DisplayOrder == Math.max(...upReports.map(u => u.DisplayOrder)))[0]

      r.DisplayOrder = swapReport.DisplayOrder
      swapReport.DisplayOrder = diplayOrder
      this.Swap(reports, r, swapReport)
      this.reportService.SetSavedReportBundleChanged()
    }
  }

  Swap (collection: any[], obj1: any, obj2: any) {
    if (!((collection.indexOf(obj1) > -1) && (collection.indexOf(obj2) > -1))) return
    if (collection.indexOf(obj1) === collection.indexOf(obj2)) return
    collection.splice(collection.indexOf(obj1), 0, collection.splice(collection.indexOf(obj2), 1)[0])
  }

  MoveReportDown (r: Report, reports?: Report[]) {
    if (!reports) {
      if (r.ParentSequenceNum) {
        const parent = this.reportService.ReportBundle.filter(f => f.SequenceNum == r.ParentSequenceNum)[0]
        this.MoveReportDown(r, parent.ComponentReports)
      } else {
        this.MoveReportDown(r, this.reportService.ReportBundle)
      }
    } else {
      const downReports = reports.filter(rb => rb.DisplayOrder > r.DisplayOrder)
      if (downReports != null && downReports.length > 0) {
        const displayOrder: number = r.DisplayOrder
        const swapReport = reports.filter(rb => rb.DisplayOrder === Math.min(...downReports.map(u => u.DisplayOrder)))[0]
        r.DisplayOrder = swapReport.DisplayOrder
        swapReport.DisplayOrder = displayOrder
        this.Swap(reports, r, swapReport)
        this.reportService.SetSavedReportBundleChanged()
      }
    }
  }

  RemoveReport (report: Report, reports?: Report[]) {
    if (!reports) {
      if (report != null) {
        if (report.ParentSequenceNum) {
          const parent = this.reportService.ReportBundle.filter(f => f.SequenceNum == report.ParentSequenceNum)[0]
          this.RemoveReport(report, parent.ComponentReports)

          if (parent.ComponentReports.length == 0) { this.RemoveReport(parent, this.reportService.ReportBundle) }
        } else {
          this.RemoveReport(report, this.reportService.ReportBundle)
        }
      }
    } else {
      if (report.Action != DTOAction.Insert) {
        report.Action = DTOAction.Delete
        this.reportService.DeletedReports.push(report)

        report.ComponentReports.forEach(comp => {
          this.reportService.DeletedReports.push(comp)
        })
      }

      // if (this.BenchmarkViewModel != null && report.ParentSequenceNum == null)
      // this.ClearBenchmarkSelector();

      this.reportService.SelectedReportGrid = null

      const index = reports.indexOf(report)
      if (index !== -1) {
        reports.splice(index, 1)
      }
      this.reportService.SetSavedReportBundleChanged()

      // Update Display order in ReportBundle Grid
      let i: number = 1
      reports.sort(a => a.DisplayOrder).forEach(r => {
        r.DisplayOrder = i
        i++
      })
    }
  }

  OnEditColumnOrder (report: Report) {
    if (report.IsColumnOrderEnabled) {
      this.reportService.SelectedReportGrid = this.reportService.ReportBundle.filter(r => r.SequenceNum == report.SequenceNum)[0]
      this.EditColumnOrder(report)
    }
  }

  EditColumnOrder (report: Report) {
    this.Headers = [...new Set(report.OrderFinancials.sort(h => h.SequenceNum))]
    this.IsVisibleColumnOrderdialog = true
    if (report.ShowCheckboxColumnInColumnOrderModal) {
      // this.btnCancel.Visibility = Visibility.Collapsed;
      // GridViewDataColumn column = new GridViewDataColumn();
      // column.Header = report.ColumnOrderModalCheckboxColumnHeader;
      // column.IsReadOnly = true;
      // column.CellTemplate = this.Resources[report.ColumnOrderModalCheckboxColumnCellTemplate] as DataTemplate;
      // this.StmtGridView.Columns.Add(column);
    }
  }

  SetMyFarmVarianceBenchmark (report: Report) {
    report.ComponentReports.forEach(comp => {
      this.reportService.RemoveAllStatementsFromReport(comp, true)
      this.reportService.UpdateComponentReport(comp)
    })
    this.reportService.BuildConcatenatedReportLabel(report)
  }

  onOrderRecordup (r: ReportFinancialStatement) {
    const stmts = this.Headers.filter(m => m.SequenceNum < r.SequenceNum)
    if (stmts != null && stmts.length > 0) {
      const diplayOrder: number = r.SequenceNum
      const swapitem = this.Headers.filter(rb => rb.SequenceNum == Math.max(...stmts.map(u => u.SequenceNum)))[0]
      r.SequenceNum = swapitem.SequenceNum
      swapitem.SequenceNum = diplayOrder
      this.Swap(this.Headers, r, swapitem)
    }
  }

  onOrderRecorddown (r: ReportFinancialStatement) {
    const stmts = this.Headers.filter(m => m.SequenceNum < r.SequenceNum)
    if (stmts != null && stmts.length > 0) {
      const displayOrder: number = r.SequenceNum
      const swapitem = this.Headers.filter(rb => rb.SequenceNum == Math.min(...stmts.map(u => u.SequenceNum)))[0]
      r.SequenceNum = swapitem.SequenceNum
      swapitem.SequenceNum = displayOrder
      this.Swap(this.Headers, r, swapitem)
    }
  }

  onColumnOrderdialogclose () {
    this.IsVisibleColumnOrderdialog = false
    this.Headers = null
  }

  onColumnOrderOk () {
    this.IsVisibleColumnOrderdialog = false
    this.reportService.SelectedReportGrid.OrderFinancials = this.Headers
    this.reportService.BuildConcatenatedReportLabel(this.reportService.SelectedReportGrid)
    this.reportService.SetSavedReportBundleChanged()
    if (this.reportService.SelectedReportGrid.ShowCheckboxColumnInColumnOrderModal) { this.SetMyFarmVarianceBenchmark(this.reportService.SelectedReportGrid) }
  }

  @ViewChild('mvpopup') mvpopup: ElementRef;
  pos1 = 495
  pos2 = 225
  pos3 = 0
  pos4 = 0
  condition = false;
  dragMouseDown (e) {
    e = e || window.event;
    e.preventDefault();
    this.pos3 = e.clientX;
    this.pos4 = e.clientY;
    this.condition = true;
  }

  elementDrag (e) {
    if (this.condition) {
      e = e || window.event;
      e.preventDefault();
      this.pos1 = this.pos3 - e.clientX;
      this.pos2 = this.pos4 - e.clientY;
      this.pos3 = e.clientX;
      this.pos4 = e.clientY;
      this.pos2 = this.mvpopup.nativeElement.offsetTop - this.pos2
      this.pos1 = this.mvpopup.nativeElement.offsetLeft - this.pos1
    }
  }

  closeDragElement () {
    this.condition = false
  }
}
