/* eslint-disable no-useless-constructor */
import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core'
import { Store, select } from '@ngrx/store'
import { ListReport } from '../../../models/ListReport'
import * as fromStore from '../../../store/reducers/reports/reports.reducer'
import * as reportsActions from '../../../store/actions'
import { ListViewComponent } from '@progress/kendo-angular-listview'
import { reportsData } from '../../../store/selectors/report.selector'
import { TooltipDirective } from '@progress/kendo-angular-tooltip'
import { ReportService } from '../../../services/report/report.service'

@Component({
  selector: 'uc-report-list',
  templateUrl: './report-list.component.html',
  styleUrls: ['./report-list.component.scss']
})
export class ReportListComponent implements OnInit {
  public listReport: 'List of Reports';
  public headerText: '';
  @ViewChild('listView', { static: false })
  public listView: ListViewComponent;
  @ViewChild(TooltipDirective) tooltipDir: TooltipDirective;
  disableListList = false
  disableReportList = false
  OverrideReportDesc: string = '';
  displayOrderNum: number=0;
  @Output() selectedItemEvent = new EventEmitter<ListReport>()
  selectedReport:string
  constructor (private store: Store<fromStore.RetrieveFilteredReport>, public reportService:ReportService) {
  }

  ngOnInit (): void {
    this.store.dispatch(reportsActions.reports())
    this.store.pipe(select(reportsData)).subscribe(data => {
      this.reportService.FullReportList = data.Data
      this.reportService.ReportsList = data.Data
      this.reportService.ReportsList = data.Data.slice().sort((i, j) => (j.OverrideReportDesc > i.OverrideReportDesc ? -1 : 1))
    })
    this.reportService.onReportListSearch(this.search.bind(this))
  }

  currentRecord () {
    this.search(this.listView.activeIndex)
  }

  search (activeIndex?: number) {
    const currentIndex = activeIndex ?? this.reportService.ReportsList.findIndex(x => x.DisplayOrderNum === this.reportService.SelectedFilteredReport.DisplayOrderNum)
    this.listView.focus(currentIndex)
    this.reportService.SelectedFilteredReport = this.reportService.ReportsList[currentIndex]
    this.selectedItemEvent.emit(this.reportService.SelectedFilteredReport)
  }

  public showTooltip (e: MouseEvent): void {
    const className = (<any>e.target).className
    if (className.indexOf('k-listview-item') >= 0) {
      const element = e.target as HTMLElement
      this.tooltipDir.toggle(element)
    }
  }
}
