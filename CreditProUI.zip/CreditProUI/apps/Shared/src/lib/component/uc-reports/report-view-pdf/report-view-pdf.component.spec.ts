import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportViewPdfComponent } from './report-view-pdf.component';

describe('ReportViewPdfComponent', () => {
  let component: ReportViewPdfComponent;
  let fixture: ComponentFixture<ReportViewPdfComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReportViewPdfComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportViewPdfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
