import { Component, OnInit } from '@angular/core';
import { ReportExportService } from '../../../services/report/report-export.service';
import { ReportService } from '../../../services/report/report.service';

@Component({
  selector: 'uc-report-view-pdf',
  templateUrl: './report-view-pdf.component.html',
  styleUrls: ['./report-view-pdf.component.scss']
})
export class ReportViewPdfComponent implements OnInit {
  constructor (public reportExportService: ReportExportService, public reportService: ReportService) { }
  public src!: Blob
  ngOnInit (): void {
  }
}
