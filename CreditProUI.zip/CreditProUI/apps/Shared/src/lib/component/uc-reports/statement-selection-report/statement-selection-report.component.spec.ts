import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StatementSelectionReportComponent } from './statement-selection-report.component';

describe('StatementSelectionReportComponent', () => {
  let component: StatementSelectionReportComponent;
  let fixture: ComponentFixture<StatementSelectionReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StatementSelectionReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StatementSelectionReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
