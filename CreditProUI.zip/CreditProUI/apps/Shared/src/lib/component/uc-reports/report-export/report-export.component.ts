import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'uc-report-export',
  templateUrl: './report-export.component.html',
  styleUrls: ['./report-export.component.scss']
})
export class ReportExportComponent implements OnInit {
  constructor () { }

  ngOnInit (): void {
  }
}
