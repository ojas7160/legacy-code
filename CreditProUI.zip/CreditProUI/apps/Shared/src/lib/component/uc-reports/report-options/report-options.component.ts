import { Component, Input, OnInit } from '@angular/core'
import { WindowService } from '@progress/kendo-angular-dialog'
import { TreeItem } from '@progress/kendo-angular-treeview'
import { environment } from 'apps/CreditPro/src/environments/environment'
import { forkJoin, Observable } from 'rxjs'
import { AppConstant } from '../../../constants/app-constants'
import { FinancialStatementSubTypes } from '../../../enum/financialStatementSubTypes'
import { TreeNode } from '../../../models/balanceSheet/TreeNode'
import { RestService } from '../../../services'
import { ExcludeSpecDetailsComponent } from '../exclude-spec-details/exclude-spec-details.component'
import { ExcludeDetails } from '../../../models/exclude-spec-details'
import { ReportService } from '../../../services/report/report.service'
import { Store } from '@ngrx/store'
import { AppState } from '../../../store'
@Component({
  selector: 'uc-report-options',
  templateUrl: './report-options.component.html',
  styleUrls: ['./report-options.component.scss']
})
export class ReportOptionsComponent implements OnInit {
  public accountExcluded = 0;
  // @Input() options: ReportOptions;
  public countValue: number;
  public selectedBenchmarkCount: number = 0;
  recordList: ExcludeDetails[]
  public headerTitle ='Exclude Specfield Details'
  public selectedKeys: any[] = [];
  public tlkpBenchmarkIndustryTemplate: any[];
  public show: boolean = false;
  public expandedNodes: number[] = [];
  public expandedKeys: any[] = [];
  public benchmarkTreeNodes: TreeNode[] = [];
  @Input() selectedbenchmarkTreeNodes: TreeNode[] = [];
  public selectedBenchmarkData: TreeNode = {
    id: 0,
    desc: '',
    desc2: '',
    data: null,
    icon: false,
    iconPath: '',
    iconType: 0,
    children: [],
    nodeLevel: -1,
    parantid: 0,
    parantDesc: '',
    parantDesc2: ''
  };

  public value :any[];
  constructor (private store: Store<AppState>, private windowService: WindowService, private _restService: RestService, public reportService:ReportService) {
  }

  ngOnInit (): void {
    this.reportService.selectListEvent.subscribe((result) => {
      this.countValue = 0
      for (let i = 0; i < result.length; i++) {
        if (result[i].CheckboxChecked === true) {
          this.countValue++
          this.accountExcluded = this.countValue
        }
      }
      this.recordList = result
    })
    this.getBenchmarkData()
  }

  post (url, paramData): Observable<any> {
    return this._restService.post(url, paramData)
  }

  getBenchmarkData () {
    let paramsData: any = {
      lookupTables: [
        {
          TableCde: 103,
          TableName: 'tlkpBenchmarkIndustryTemplate',
          EmptyOK: true
        }]
    }
    const lookupData: Observable<any> = this.post(environment.commonBaseURI + AppConstant.endpoints.getLookups, paramsData)

    paramsData =
      { selectedFinancialStatementBIDs: [] }
    const benchmarkData: Observable<any> = this.post(environment.baseURI + AppConstant.endpoints.retrieveBenchmarkNodes, paramsData)

    forkJoin([lookupData, benchmarkData]).subscribe((data: any[]) => {
      this.tlkpBenchmarkIndustryTemplate = data[0].GetLookupsResult
      const groubedByBenchmarkIndustryTemplateCde = this.groupBy(data[1].RetrieveBenchmarkNodesResult.BenchmarkGroupNodes, 'BenchmarkIndustryTemplateCde')

      paramsData = {
        benchmarkIDs: data[1].RetrieveBenchmarkNodesResult.BenchmarkNodes.map(val => val.BenchmarkID),
        financialStatementType: FinancialStatementSubTypes.BalanceSheet,
        Error: []
      }
      let lastLeafnodes: TreeNode[] = []
      const benchmarkLastLeafNodeData = this.post(environment.baseURI + AppConstant.endpoints.retrieveBenchmarkStatementNodesAll, paramsData).subscribe((e: any) => {
        const fhsCollections = e.RetrieveBenchmarkStatementNodesAllResult.flatMap((elem) => elem.FinancialSheetHeaders)

        lastLeafnodes = fhsCollections.map(leafchild => <TreeNode>{
          data: leafchild,
          id: leafchild.FinancialStatementBID,
          nodeLevel: 3,
          children: [],
          desc: leafchild.FinancialStatementEndDte,
          desc2: leafchild.FinancialStatementDesc,
          icon: true,
          iconType: leafchild.FinancialStatementSubTypeCde,
          iconPath: '',
          parantid: leafchild.DefaultBenchmarkID
        })

        this.benchmarkTreeNodes = []

        for (const key in groubedByBenchmarkIndustryTemplateCde) {
          const industryTemplate = this.tlkpBenchmarkIndustryTemplate[0].LookupData.find((x) => parseInt(x.Cde) === parseInt(key))
          const industryTemplatesData = this.LoadBenchmarkNode(data[1], lastLeafnodes, ...groubedByBenchmarkIndustryTemplateCde[key])
          this.benchmarkTreeNodes.push({
            data: industryTemplate,
            id: parseInt(industryTemplate.Cde),
            nodeLevel: 0,
            children: industryTemplatesData,
            desc: industryTemplate.Desc,
            icon: false,
            iconPath: '',
            parantid: 0
          })
        }
        benchmarkLastLeafNodeData.unsubscribe()
        this.benchmarkTreeNodes.sort((a, b) => a.desc < b.desc ? -1 : a.desc > b.desc ? 1 : 0)
      })
    })
  }

  LoadBenchmarkNode (data: any, lastLeafnodes: TreeNode[], ...element): TreeNode[] {
    const benchmarkIndustryTreeNode: TreeNode[] = []
    for (const e in element) {
      const nodes: TreeNode[] = []
      data.RetrieveBenchmarkNodesResult.BenchmarkNodes.filter((bn) =>
        bn.BenchmarkGroupBID === element[e].BenchmarkGroupBID).forEach(ele => {
        nodes.push({
          data: ele,
          id: ele.BenchmarkID,
          nodeLevel: 2,
          children: lastLeafnodes.filter(x => x.parantid === ele.BenchmarkID),
          desc: ele.BenchmarkDesc,
          icon: false,
          iconPath: '',
          parantid: ele.BenchmarkGroupBID
        })
      })

      benchmarkIndustryTreeNode.push({
        data: {
          BenchmarkGroupHeader: e,
          BenchmarkNodes: nodes
        },
        id: parseInt(element[e].BenchmarkGroupBID),
        nodeLevel: 1,
        children: nodes,
        desc: element[e].BenchmarkGroupName,
        icon: false,
        iconPath: ''
      })
    }

    return benchmarkIndustryTreeNode
  }

  excludedetails () {
    this.windowService.open({
      title: this.headerTitle,
      content: ExcludeSpecDetailsComponent,
      minWidth: 370,
      width: 370,
      minHeight: 270,
      height: 270
    })
  }

  groupBy = function (xs, key) {
    return xs.reduce(function (rv, x) {
      (rv[x[key]] = rv[x[key]] || []).push(x)
      return rv
    }, {})
  };

  public onToggle (): void {
    this.show = !this.show
  }

  public handleExpand (args: any): void {
    this.expandedNodes = this.expandedNodes.concat(args.dataItem.id)
  }

  public handleCollapse (args: TreeItem): void {
    this.expandedNodes = this.expandedNodes.filter(
      (id) => id !== args.dataItem.id
    )
  }

  public isNodeExpanded = (node: any): boolean => {
    return this.expandedNodes.indexOf(node.id) !== -1
  };

  public handleSelection ({ index }: any, dataitem: any): void {
    const selectedIndex = String(index).split('_')
    if (selectedIndex.length === 4) {
      this.selectedBenchmarkData = this.benchmarkTreeNodes[selectedIndex[0]].children[selectedIndex[1]].children[selectedIndex[2]].children[selectedIndex[3]]
      this.selectedBenchmarkData.parantDesc = this.benchmarkTreeNodes[selectedIndex[0]].desc
      this.selectedBenchmarkData.parantDesc2 = this.benchmarkTreeNodes[selectedIndex[1]].desc
      this.show = !this.show
      const duplicate = this.selectedbenchmarkTreeNodes.filter(benchMark => {
        if (benchMark.id === this.selectedBenchmarkData.id) { return benchMark }
      })
      if (duplicate.length <= 0) {
        this.selectedbenchmarkTreeNodes.push(this.selectedBenchmarkData)
        this.selectedBenchmarkCount = this.selectedbenchmarkTreeNodes.length
      }
    } else {
      this.selectedBenchmarkData = {
        id: 0,
        desc: '',
        desc2: '',
        data: undefined,
        icon: false,
        iconPath: '',
        iconType: 0,
        children: [],
        nodeLevel: -1,
        parantid: 0,
        parantDesc: '',
        parantDesc2: ''
      }
    }
    this.reportService.setBenchMarkList(this.selectedbenchmarkTreeNodes)
  }

  clickExcludedetails () {
    if (this.accountExcluded === 0) {
      this.reportService.excludeReportList()
    } else {
      setTimeout(() => {
        this.reportService.excludeCheckedData(this.recordList)
      }, 5)
    }
    this.windowService.open({
      title: this.headerTitle,
      content: ExcludeSpecDetailsComponent,
      minWidth: 370,
      width: 370,
      minHeight: 270,
      height: 270
    })
  }
}
