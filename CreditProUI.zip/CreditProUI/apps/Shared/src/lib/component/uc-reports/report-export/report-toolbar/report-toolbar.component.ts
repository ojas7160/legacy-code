import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'uc-report-toolbar',
  templateUrl: './report-toolbar.component.html',
  styleUrls: ['./report-toolbar.component.scss']
})
export class ReportToolbarComponent implements OnInit {

  constructor() { }

  ngOnInit (): void {
  }

  public onPaste (): void {
    console.log('Paste')
  }

  public data: Array<any> = [
    {
      text: 'Acrobat (PDF) file',
      click: () => {
        console.log('Acrobat (PDF) file')
      }
    },
    {
      text: 'Excel 97-2003',
      click: () => {
        console.log('Excel 97-2003')
      }
    }
  ]
}
