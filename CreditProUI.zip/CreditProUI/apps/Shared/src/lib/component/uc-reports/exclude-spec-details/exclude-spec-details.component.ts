import { Component, OnInit } from '@angular/core'
import { ExcludeDetails } from '../../../models/exclude-spec-details'
import { KendoModalService } from '../../../services'
import { WindowRef } from '@progress/kendo-angular-dialog'
import { ReportService } from '../../../services/report/report.service'
@Component({
  selector: 'uc-exclude-spec-details',
  templateUrl: './exclude-spec-details.component.html',
  styleUrls: ['./exclude-spec-details.component.scss']
})
export class ExcludeSpecDetailsComponent implements OnInit {
  public reportRecord : ExcludeDetails[]
  public selectedText:string ='Check All'
  public btnOk:string ='OK'
  public btnCancel:string ='Cancel'
  public selected:boolean=true
  selectedItems:ExcludeDetails[];
  count: number

  constructor (private kendoModalService: KendoModalService,
    public windowRef: WindowRef, private reportService:ReportService) { }

  ngOnInit (): void {
    this.loadData()
  }

  onChange (e:any, accountDesc: any, reports:any) {
    if (e.target.checked) {
      for (let i = 0; i < reports.length; i++) {
        if (reports[i].ChartOfAccountDesc === accountDesc) {
          reports[i].CheckboxChecked = true
          this.selectedItems = reports
        }
      }
    } else {
      this.selectedItems = []
      this.selectedItems = reports.filter(m => m.ChartOfAccountDesc !== accountDesc)
    }
  }

  loadData () {
    this.count = 0
    this.reportService.selectListEvent.subscribe((res) => {
      this.reportRecord = res
      for (let i = 0; i < res.length; i++) {
        if (res[i].CheckboxChecked === true) {
          this.count++
          if (res.length === this.count) {
            this.selectedText = 'Uncheck All'
          }
        }
      }
    })
  }

  public checkUncheckAll (reportRecord: any) {
    if (this.selected) {
      this.selectedText = 'Uncheck All'
      this.selected = false
      this.count = 0
      for (let i = 0; i < reportRecord.length; i++) {
        reportRecord[i].CheckboxChecked = true
        this.selectedItems = reportRecord
      }
    } else {
      this.selectedText = 'Check All'
      this.selected = true
      this.selectedItems = []
    }
  }

  SaveDetails (reportRecord) {
    for (let i = 0; i < reportRecord.length; i++) {
      if (reportRecord[i].CheckboxChecked === true) {
        reportRecord[i].CheckboxChecked = true
        this.selectedItems = reportRecord
      }
    }
    this.reportService.excludeCheckedData(this.selectedItems)
    this.kendoModalService.close('window', this.windowRef.close())
  }

  windowclose () {
    this.kendoModalService.close('window', this.windowRef.close())
  }
}
