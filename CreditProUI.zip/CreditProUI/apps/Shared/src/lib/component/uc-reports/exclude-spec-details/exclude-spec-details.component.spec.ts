import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExcludeSpecDetailsComponent } from './exclude-spec-details.component';

describe('ExcludeSpecDetailsComponent', () => {
  let component: ExcludeSpecDetailsComponent;
  let fixture: ComponentFixture<ExcludeSpecDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExcludeSpecDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExcludeSpecDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
