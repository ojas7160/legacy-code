import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UcReportsComponent } from './uc-reports.component';

describe('UcReportsComponent', () => {
  let component: UcReportsComponent;
  let fixture: ComponentFixture<UcReportsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UcReportsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UcReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
