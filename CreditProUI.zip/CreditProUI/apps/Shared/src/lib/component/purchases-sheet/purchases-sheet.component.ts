import { Component, Input, OnInit } from '@angular/core';
import { GridDataResult, PageChangeEvent } from "@progress/kendo-angular-grid";
import { SortDescriptor } from "@progress/kendo-data-query";
import { Observable } from "rxjs";


import { WcfDataService } from "../../services/wcf/wcf-data.service";
//Interface
import { ClosingBalanceSheet } from "../../interface/closing-balance-sheet";
import { OpeningBalanceSheet } from "../../interface/opening-balance-sheet";
import { Purchases } from "../../interface/purchases";

@Component({
  selector: 'lib-purchases-sheet',
  templateUrl: './purchases-sheet.component.html',
  styleUrls: ['./purchases-sheet.component.css']
})
export class PurchasesSheetComponent implements OnInit {
  public gridPurchases: Observable<Purchases>;
  public pageSize: number = 10;
  public skip: number = 0;
  public sortDescriptor: SortDescriptor[] = [];
  public filterTerm: number = null;
  public lcaData: any = [];
  //Input Parameter - Template
  @Input() temlatePurchaseJSONUri: string;

  constructor(
     private wcfstubserv: WcfDataService
  ) { }

  ngOnInit(): void {
    this.initializePageLoad();
  }
  initializePageLoad() {
    this.loadData();
  }
  loadData() {
    this.loadPurchaseSheet();
  }
  loadPurchaseSheet() {
    const jsonUrl = this.temlatePurchaseJSONUri;
    this.wcfstubserv.getPurchases(jsonUrl).subscribe((data: any) => {
      this.lcaData = data;
      //this.gridClosingBalanceSheet = this.lcaData.closingBalanceSheet;
      this.gridPurchases = this.lcaData.purchases;
      console.log("gridPurchases", this.gridPurchases);
    });
  }
  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadData();
  }

  public handleSortChange(descriptor: SortDescriptor[]): void {
    this.sortDescriptor = descriptor;
    this.loadData();
  }

}
