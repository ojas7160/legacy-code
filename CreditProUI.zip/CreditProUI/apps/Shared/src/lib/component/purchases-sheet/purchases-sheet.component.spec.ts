import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PurchasesSheetComponent } from './purchases-sheet.component';

describe('PurchasesSheetComponent', () => {
  let component: PurchasesSheetComponent;
  let fixture: ComponentFixture<PurchasesSheetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PurchasesSheetComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PurchasesSheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
