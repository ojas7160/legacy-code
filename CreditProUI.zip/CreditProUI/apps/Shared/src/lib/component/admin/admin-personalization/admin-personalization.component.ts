import { Component, Input, OnInit } from '@angular/core';
import { BASE_URL, COMMON_ENDPOINT } from '../../../configuration';
import { ApplicationView, ApplicationViewPersonalizationAttribute, DTOAction } from '../../../enum/enum';
import { DcUserApplicationViewPersonalization } from '../../../models/DcUserApplicationViewPersonalization';
import { RestService } from '../../../services';
import { defaultPersonalization } from '../../../constants/default-personalization';
import { WindowRef } from '@progress/kendo-angular-dialog';
import { AppConstant } from '../../../constants/app-constants';
import { environment } from '../../../../../../CreditPro/src/environments/environment';


@Component({
  selector: 'lib-admin-personalization',
  templateUrl: './admin-personalization.component.html',
  styleUrls: ['./admin-personalization.component.scss']
})
export class AdminPersonalizationComponent implements OnInit {
  @Input() opened = false;

  public appViewPersonalizations: DcUserApplicationViewPersonalization[] = [];
  public personalization: any = defaultPersonalization;
  //this userId will change when it will be avaliable on store
  public userID: number = 1942;
  public checkResponse: any;


  constructor(private restService: RestService, private window: WindowRef) { }

  ngOnInit(): void {
  }
  public close() {
    this.opened = false;
  }

  public open() {
    this.opened = true;
  }

  DialogClosedEvent() {
    this.GetAllPersonalizationsForUser(true);
    this.opened = false;

  }

  GetAllPersonalizationsForUser(isNewUser: boolean) {

    const paramsData = {
      "userID": this.userID
    }

    this.checkResponse = this.restService.post(environment.commonBaseURI + AppConstant.endpoints.adminPersonalizationScreen, paramsData).subscribe(data => {
      this.appViewPersonalizations = data;
      this.appViewPersonalizations = []
      for (let i in this.personalization) {
        this.AddNewPersonalization(isNewUser, ...this.personalization[i])
      }

      this.restService.post(environment.commonBaseURI + AppConstant.endpoints.adminResetPersonalizationScreen, { "records": this.appViewPersonalizations }).subscribe(result => {
      });
    });
  }

  HasPersonalization(applicationViewCde: Number, personalizationAttributeCde: Number): boolean {
    {
      return this.appViewPersonalizations.length != 0 &&
        this.appViewPersonalizations.some(p => p.applicationViewCde == applicationViewCde &&
          p.personalizationAttributeCde == personalizationAttributeCde);
    }
  }
  AddNewPersonalization(isNewUser: boolean, ...args) {

    if (isNewUser || !this.HasPersonalization(args[0], args[1])) {
      let dc: DcUserApplicationViewPersonalization =
      {
        action: DTOAction.Insert,
        userID: this.userID,
        applicationViewCde: args[0],
        personalizationAttributeCde: args[1],
        personalizationValue: args[2]
      };

      this.appViewPersonalizations.push(dc);
    }
  }
}
