import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminCoaRowPropertiesComponent } from './admin-coa-row-properties.component';

describe('AdminCoaRowPropertiesComponent', () => {
  let component: AdminCoaRowPropertiesComponent;
  let fixture: ComponentFixture<AdminCoaRowPropertiesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminCoaRowPropertiesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminCoaRowPropertiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
