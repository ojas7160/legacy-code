import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-admin-coa-row-properties',
  templateUrl: './admin-coa-row-properties.component.html',
  styleUrls: ['./admin-coa-row-properties.component.scss']
})
export class AdminCoaRowPropertiesComponent implements OnInit {
  public windowTop = 450;
  public windowLeft = 50;
  isShown: boolean = false ; // hidden by default
  public dialogOpened = false;
  public windowOpened = false;
  public opened = true;
  public closed = true;
 
  
  constructor() { }

  ngOnInit(): void {
  }

  public openClose(isOpened: boolean) {
    this.opened = isOpened;
  }
  
  public open() {
    this.opened = true;
  }

  public close() {
    this.opened = false;
  }

}
