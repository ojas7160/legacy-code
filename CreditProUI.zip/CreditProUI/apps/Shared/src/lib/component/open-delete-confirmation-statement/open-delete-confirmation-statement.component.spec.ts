import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OpenDeleteConfirmationStatementComponent } from './open-delete-confirmation-statement.component';

describe('OpenDeleteConfirmationStatementComponent', () => {
  let component: OpenDeleteConfirmationStatementComponent;
  let fixture: ComponentFixture<OpenDeleteConfirmationStatementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OpenDeleteConfirmationStatementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OpenDeleteConfirmationStatementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
