import { Component, OnInit } from '@angular/core';
import {ShareStatementDataService} from '../../services/earnings/shareStatementDataService'
import { Subject } from 'rxjs';
import { WindowRef } from '@progress/kendo-angular-dialog';

@Component({
  selector: 'uc-open-delete-confirmation-statement',
  templateUrl: './open-delete-confirmation-statement.component.html',
  styleUrls: ['./open-delete-confirmation-statement.component.scss']
})
export class OpenDeleteConfirmationStatementComponent implements OnInit {
  unsubscribe$: Subject<boolean> = new Subject();
  balancesheetStatement : any;

  constructor(private dataservice : ShareStatementDataService,private windowRef:WindowRef) { 
    this.dataservice.getProfileObs().subscribe(balancesheetStatement => {
      this.balancesheetStatement = balancesheetStatement
    });
  }

  ngOnInit(): void {
  }

  deletePopupClose(){
    this.windowRef.close();
  }


  ngOnDestroy(){
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }

}
