import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { LoaderService } from '../../../services';
import { WcfDataService } from '../../../services/wcf/wcf-data.service';
import * as UserContextdActions from '../../../store/actions/user-context.actions';
import { AppState } from '../../../store';
@Component({
  selector: 'lib-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.scss']
})

export class LoaderComponent implements OnInit {
  isLoading: any;
  message: string;

  constructor (private loaderService: LoaderService, private CommonService: WcfDataService, private store: Store<AppState>) {
    this.loaderService.isLoading
      .subscribe(res => {
        console.log(res)
        this.isLoading = res;
        this.message = this.loaderService.message;
        if (!this.isLoading){
          this.message = null;
        }
      })
  }

  ngOnInit (): void {
    console.log('isLoading', this.isLoading)
    this.CommonService.getUserInfo().subscribe((e: any) => {
      console.log('User info - ', e.GetUserRestResult);
      if (e != null && e.GetUserRestResult != null) {
      // copy the userid propertry to the required field for the header.
        e.GetUserRestResult.UserEID = e.GetUserRestResult.UserLoginEID;
        this.store.dispatch(UserContextdActions.userContextLoad(e.GetUserRestResult));
      } else {
        console.log('Warning UserContext not found in results, state will not be updated...');
      }
    });
  }
}
