/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */
import { Component, OnInit, OnDestroy, ViewChild, Output,EventEmitter, Input, ViewEncapsulation, AfterViewInit, OnChanges } from '@angular/core';
import { Align, Offset } from '@progress/kendo-angular-popup';
import { select, Store } from '@ngrx/store';
import { AppState } from '../../store';
import { customerWithEarningStatements } from '../../store/selectors/customerWithEarningStatement.selector';
import { ShareStatementDataService } from '../../services/earnings/shareStatementDataService';
import { Subject } from 'rxjs';
import { CustomerSearchResult } from '../../models/customer-search-result.model';
import { environment } from 'apps/CreditPro/src/environments/environment';
import { RestService, SelectedCustomerService } from '../../services';
import { Observable } from 'rxjs';
import { AppConstant } from '../../constants/app-constants';
import * as customersWithEarningStatementActions from '../../store/actions';
import { FinancialStatementSubTypes } from '../../enum/financialStatementSubTypes';
import { TooltipDirective } from '@progress/kendo-angular-tooltip'
import { ListViewComponent } from '@progress/kendo-angular-listview';
import { TreeNode, TreeNodeFinancialConsolidation } from '../../models/balanceSheet/TreeNode'
import { openStatementSelector } from '../../store/selectors/balanceSheet/openStatement-selector'
import * as openStatementAction from '../../store/actions'

@Component({
  selector: 'uc-earning-copy-statement-popup',
  templateUrl: './earning-copy-statement-popup.component.html',
  styleUrls: ['./earning-copy-statement-popup.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class EarningCopyStatementPopupComponent implements OnInit, OnDestroy {
  public toggleText = "UC-EarningCopyStatementPopup";
  public headerContent = "Create New by Copying From:";
   page: string;
  public dialogOpened = false;
  public offset: Offset = { left: 100, top: 250 };
  public popupAlign: Align = { horizontal: "center", vertical: "center" };
  parameterList: any[];
  statementListByCustomer: any[];
  earningStatementsData: any;
  customerEarningStatementsData: any;
  unsubscribe$: Subject<boolean> = new Subject();
  customerHeadersearchList: CustomerSearchResult = {};
  public consolidationTreeNode: TreeNode[] = [];
  data$ = this.store.pipe(select(openStatementSelector));
  public currentSelectedCustomerId

  currentCustomer = true;
  customerHeading = 'Customer:';
  financialHeading = 'Financial Statements:';
  customerHeadingCSS = 'font-weight-bold mt-2';
  financialHeadingCSS = 'font-weight-bold mt-2';
  statementName = 'earning Sheet';
  apiUrl = environment.endpoints.retrieveEarnigsStatement;
  apiUrlJsonKey = 'RetrieveEarningsStatementHeadersByCustomerBIDResult';
  imgSrc = 'assets/app-icons-imgs/Earnings_icon.jpg';
  selectedCustomer: any;
  selectedFinancialStatement: any;
  @ViewChild('listView', { static: false })
  public listView: ListViewComponent;
  isActiveStartDate = true;
  isActiveEndDate = true;

  @ViewChild(TooltipDirective) tooltipDir: TooltipDirective;
  disableparameterList = false
  radiochecked:any;
  radioOptions=[
    {"option": "With All Values"},
    {"option": "Without Any Values"},
    {"option": "Without Values For:"}
  ]
  @Output() radioValueEmitter = new EventEmitter();
  @Output() onFinancialSelected = new EventEmitter();

  rmDisabled: boolean = false;
  lastTouchUserInfo:any;
  groupElements: any;  
  
  constructor(private _restservice: RestService, private store: Store<AppState>, private dataservice: ShareStatementDataService, private restService: RestService, private _selectedCustomerService: SelectedCustomerService,) {
    
  }



  getSelectedCustomerData(event) {
    this.selectedCustomer = event;
  }

  getSelectedFinancialData(event) {
    this.onFinancialSelected.emit(event);
  }
  

  ngOnInit(): void {

    this.currentSelectedCustomerId = this._selectedCustomerService.getCurrentSelectedCustomer2().customerId;
    this.store.dispatch(openStatementAction.openStatementData());
    
    setTimeout(()=>{   
      this.getConsolidation();    
      this.loadCopyEarningsStatement();
    },0);
    this.store.dispatch(customersWithEarningStatementActions.CustomersListWithEarningStatement({}));
    this.store.pipe(select(customerWithEarningStatements))
      .subscribe(data => {
        this.customerEarningStatementsData = data.customersEarningStatement.customerListWithEarningsStatmentList;
      })

    const jsonUrl = environment.endpoints.earningConsoldationstmt;
    this.restService.get(jsonUrl).subscribe(data => {
      this.customerHeadersearchList = this.filterSaerchData(data.RecentCustomers);
    });
  }


  
  public showTooltip (e: MouseEvent): void {
    const className = (<any>e.target).className
    if (className.indexOf('k-listview-item') >= 0) {
      const element = e.target as HTMLElement
      this.tooltipDir.toggle(element)
    }
  }

  getConsolidation() {
    let paramsData ;
    switch(this.page)
    {
     case 'Projection':
      paramsData = {
        "customerBID": this.currentSelectedCustomerId,
        "includeBS": true,
        "includeES": false,
        "includeActiveGroupsOnly": true
      };
       break;
      case 'Earning':
        paramsData = {
          "customerBID": this.currentSelectedCustomerId,
          "includeBS": false,
          "includeES": true,
          "includeActiveGroupsOnly": true
        };  
       break;
    }

    this.restMethodCall(environment.baseURI + environment.endpoints.openStatementComponent, paramsData).subscribe((val: any) => {
      val.RetrieveCustomerConsolidationFinancialStatementHeadersResult.forEach(rb => {
        if (rb.FinancialStatements && rb.FinancialStatements.length > 0) {
          this.consolidationTreeNode.push({
            id: rb.Group.GroupBID,
            desc: rb.Group.GroupNameTxt.split(", ")[1],
            data: rb.Group,
            nodeLevel: 0,
            children: rb.FinancialStatements.map(x => <TreeNodeFinancialConsolidation>{
              data: x,
              id: x.FinancialStatementBID,
              nodeLevel: 1,
              children: [],
              isChecked: false,
              desc: x.FinancialStatementEndDte,
              desc2: x.FinancialStatementDesc,
              desc3: x.FinancialStatementStartDte,
              icon: true,
              iconType: x.FinancialStatementSubTypeCde,
              iconPath: '',
              parantid: rb.Group.GroupBID
            })
          })
        }
      })
    });
  }

  onFinancialStatementHover (id: any): void {
    const paramsData = {
      financialStatementBID: id
    };
    const apiUrl = environment.baseURI + environment.endpoints.retrieveLastInfo;
    this.restService.post(apiUrl, paramsData).subscribe((data: any) => {
      this.lastTouchUserInfo = data.RetrieveLastChangedInformationByFinanicalStatementBIDResult;
    });
    
  }

  onGroupNameHover(id, item){
    this.groupElements= item.data.GroupMembers.filter(x=>x.GroupBID === id)  
  }

  loadCopyEarningsStatement() {    
    const paramsData = {
      "customerBID": this.currentSelectedCustomerId,
      "financialStatementBID": null,
      "groupBID": null,
      "Errors": []
    };
     switch(this.page)
     {
      case 'Projection':
          this.restMethodCall(environment.baseURI + AppConstant.endpoints.retrieveEarningsStatementHeaderByID, paramsData).subscribe((data: any) => {
          this.earningStatementsData = data?.RetrieveEarningsStatementHeaderByIDResult?.AvailableEarningsHeaders?.filter(a => a.FinancialStatementSubTypeCde == FinancialStatementSubTypes.EarningsStatement ||
            a.FinancialStatementSubTypeCde == FinancialStatementSubTypes.BalanceSheetSimpleProforma)
        });
        break;
       case 'Earning':
        this.restMethodCall(environment.baseURI + AppConstant.endpoints.retrieveEarningsStatementHeaderByID, paramsData).subscribe((data: any) => {
          this.earningStatementsData = data?.RetrieveEarningsStatementHeaderByIDResult?.AvailableEarningsHeaders?.filter(a => a.FinancialStatementSubTypeCde == FinancialStatementSubTypes.EarningsStatement ||
            a.FinancialStatementSubTypeCde == FinancialStatementSubTypes.EarningsStatementSimpleProjection)
        });  
        break;
     }
   
  }

  getStatementListByCustomer(dataItem) {
    this.statementListByCustomer = dataItem.earningStatements;
  }

  copyStatement(dataItem,op?) {

    const paramsData = {
      "financialStatementBIDs": op ? dataItem.id : dataItem.FinancialStatementBID
    };
    this.restMethodCall(environment.baseURI + AppConstant.endpoints.retrieveCustomCOAbyStatementBID, paramsData).subscribe((data: any) => {
      this.parameterList = data.RetrieveCustomChartOfAccountsByFinancialStatementBIDResult
    });
    this.dataservice.setProfileObs(op ?dataItem.data : dataItem);
  }




  public onTabSelect(e) {
  }


  clickOnTest() {
  }

  private filterSaerchData(dataToFilter: any) {

    dataToFilter.Customers.forEach((customer) => {
      customer.CustomerTasks = [];
      dataToFilter.CustomerTasks.forEach(customerTask => {
        if (customer.CustomerBID === customerTask.CustomerBID) {
          customer.CustomerTasks.push(customerTask);
        }
      });
    });

    return dataToFilter;
  }

  public onToggle(): void {
    this.dialogOpened = !this.dialogOpened;
  }

  clearAll() {
    this.radiochecked = false;
    this.rmDisabled = false;
    this.dataservice.setProfileObs(null);
    this.dataservice.setProfileObs(null);
    this.radioValueEmitter.emit(null);
    let element = document.getElementsByClassName('k-state-selected');
    if(element.length > 0 )
    {
      element[0].classList.remove('k-state-selected');
    }
  }

  onItemChange(event){
    this.radioValueEmitter.emit(this.radiochecked);
    if(this.radiochecked === 'Without Values For:')
    {
      this.rmDisabled = true;
    }
    else
    {
      this.rmDisabled = false;
    }
  }

  restMethodCall(url, paramData): Observable<any> {
    return this._restservice.post(url, paramData);
  }

  ngOnDestroy() {
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }
}
