import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EarningCopyStatementPopupComponent } from './earning-copy-statement-popup.component';

describe('EarningCopyStatementPopupComponent', () => {
  let component: EarningCopyStatementPopupComponent;
  let fixture: ComponentFixture<EarningCopyStatementPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EarningCopyStatementPopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EarningCopyStatementPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
