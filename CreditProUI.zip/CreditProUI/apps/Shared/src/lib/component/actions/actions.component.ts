import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-actions',
  templateUrl: './actions.component.html',
  styleUrls: ['./actions.component.scss']
})
export class ActionsComponent implements OnInit {
  public windowTop = 450;
  public windowLeft = 50;
  isShown: boolean = false ; // hidden by default 
  public dialogOpened = false;
  public windowOpened = false;
  public opened = true;
  public closed = true;
    
  constructor() { }

  ngOnInit(): void {
  }
  public close() {
    this.opened = false;
  }
 
  public open() {
    this.opened = true;
  }

  public openClose(isOpened: boolean) {
    this.opened = isOpened;
  }

}
