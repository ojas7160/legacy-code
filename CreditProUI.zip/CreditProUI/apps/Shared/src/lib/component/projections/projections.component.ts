import { Component, OnInit } from '@angular/core';
import { AppConstant } from '../../constants/app-constants';
import { CustomerDetails } from '../../models/customerDetails.model';
import { select, Store } from '@ngrx/store';
import { AppState } from '../../store';
import * as gridActions from '../../store/actions/grid.action';
import { gridDataSelector } from '../../store/selectors/grid.selector';
import { cloneDeep } from 'lodash';
import { updateGridDataSuccess } from '../../store/actions/balancesheet-grid.action'


@Component({
  selector: 'app-projections',
  templateUrl: './projections.component.html',
  styleUrls: ['./projections.component.scss']
})
export class ProjectionsComponent implements OnInit {
  projectionsSubMenu = AppConstant.secondaryMenu.projections

  public showCustomer: boolean = false;
  public selectedCustomerDetails: CustomerDetails = {};
  balanceSheetData: any[];
  columns: any = AppConstant.gridColumns;
  columnGroupData: any;

  constructor(private store: Store<AppState>,) { }

  ngOnInit(): void {
    this.store.dispatch(gridActions.initialGridDataLoad({ customerId: 123, gridType: 'balancesheet' }))

		this.store.pipe(select(gridDataSelector))
			.subscribe(data => {
				this.columnGroupData = cloneDeep(data.gridData).filter(it => it.type.toLowerCase().includes('balance'))
				this.columns = cloneDeep(data.columnData)
				this.balanceSheetData = this.transformCoa(cloneDeep(data.coa))
				this.columnGroupData = this.columnGroupData.map(it => { 
					if(!it.columns || !it.columns.length) {
						it['columns'] = this.columns.map(it => Object.assign({}, it))
					}
					return it 
				})
			})

			console.log('this.balanceSheetData :',this.balanceSheetData);
  }

  transformCoa(coa) {
		return coa.map(it => {
			this.columns.forEach(column => {
				column.coas && column.coas.length && column.coas.forEach(columnCoa => {
					if (it.coaCde === columnCoa.coaCde) {
						it = Object.assign({}, { ...it, [column.dataBindingName]: columnCoa.value
							, cellTemplateSelector: columnCoa.cellTemplateSelector })
					}
				})
			})
			if (it.children && it.children.length) {
				it.children = this.transformCoa(it.children)
			}

			return { ...it }
		})
	}

	performCalculation(percentage: number){
		this.store.dispatch(gridActions.initialGridDataLoad({ customerId: 123, gridType: 'balancesheet' }))
		this.store.pipe(select(gridDataSelector))
			.subscribe(data => {
				this.balanceSheetData = this.performePerAdj(cloneDeep(data.coa),percentage)
			})

			// this.store.dispatch(gridActions.gridDataUpdate({ : this.balanceSheetData }))
	}


	performePerAdj(coa,percentage) {
		return coa.map(it => {
			this.columns.forEach(column => {
				column.coas && column.coas.length && column.coas.forEach(columnCoa => {
					if (it.coaCde === columnCoa.coaCde) {
						it = Object.assign({}, { ...it, [column.dataBindingName]: columnCoa.value + (columnCoa.value / 100) * percentage
							, cellTemplateSelector: columnCoa.cellTemplateSelector })
					}
				})
			})
			if (it.children && it.children.length) {
				it.children = this.performePerAdj(it.children,percentage)
			}
			return { ...it }
		})
	}

}
