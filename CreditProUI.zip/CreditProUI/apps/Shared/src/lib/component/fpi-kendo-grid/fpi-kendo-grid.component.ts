import { Component, Input, OnInit } from '@angular/core';
import { GridDataResult, PageChangeEvent } from "@progress/kendo-angular-grid";
import { SortDescriptor } from "@progress/kendo-data-query";
import { Observable } from "rxjs";


import { WcfDataService } from "../../services/wcf/wcf-data.service";
//Interface
import { ClosingBalanceSheet } from "../../interface/closing-balance-sheet";
import { OpeningBalanceSheet } from "../../interface/opening-balance-sheet";
import { Purchases } from "../../interface/purchases";

@Component({
  selector: 'lib-fpi-kendo-grid',
  templateUrl: './fpi-kendo-grid.component.html',
  styleUrls: ['./fpi-kendo-grid.component.css']
})
export class FpiKendoGridComponent implements OnInit {

  public gridClosingBalanceSheet: Observable<ClosingBalanceSheet>;
  public gridOpeningBalanceSheet: Observable<OpeningBalanceSheet>;
  public gridResult: Observable<any>;
  public gridPurchases: Observable<Purchases>;
  public pageSize: number = 10;
  public skip: number = 0;
  public sortDescriptor: SortDescriptor[] = [];
  public filterTerm: number = null;
  public lcaData: any = [];
  //Input Parameter - Template
  @Input() temlateOpeningJSONUri: string;
  @Input() temlateClosingJSONUri: string;

  constructor(
        private wcfstubserv: WcfDataService
  ) { }

  ngOnInit(): void {
    this.initializePageLoad();
  }
  initializePageLoad() {
    this.loadData();
  }
  loadData() {
    this.loadCloseBalanceSheet();
  }
  loadCloseBalanceSheet() {
    const jsonUrl = this.temlateClosingJSONUri;
    this.wcfstubserv.getClosingBalance(jsonUrl).subscribe((data: any) => {
      this.lcaData = data;
      //this.gridClosingBalanceSheet = this.lcaData.closingBalanceSheet;
      this.gridResult = this.lcaData.closingBalanceSheet
      console.log("gridClosingBalanceSheet", this.gridClosingBalanceSheet);
    });
  }
  loadOpenBalanceSheet() {
    const jsonUrl = this.temlateOpeningJSONUri;
    this.wcfstubserv.getOpeningBalance(jsonUrl).subscribe((data: any) => {
      this.lcaData = data;
      //this.gridClosingBalanceSheet = this.lcaData.closingBalanceSheet;
      this.gridResult = this.lcaData.closingBalanceSheet;
      console.log("gridClosingBalanceSheet", this.gridClosingBalanceSheet);
    });
  }
  loadPurchases() {

  }
  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadData();
  }

  public handleSortChange(descriptor: SortDescriptor[]): void {
    this.sortDescriptor = descriptor;
    this.loadData();
  }
}
