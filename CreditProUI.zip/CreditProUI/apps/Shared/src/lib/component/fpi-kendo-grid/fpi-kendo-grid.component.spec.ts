import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FpiKendoGridComponent } from './fpi-kendo-grid.component';

describe('FpiKendoGridComponent', () => {
  let component: FpiKendoGridComponent;
  let fixture: ComponentFixture<FpiKendoGridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FpiKendoGridComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FpiKendoGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
