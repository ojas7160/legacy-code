/* eslint-disable no-useless-constructor */
import { Component, HostListener, OnInit } from '@angular/core';
import { Formula } from '../../models/formula';

@Component({
  selector: 'lib-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.scss']
})
export class CalculatorComponent implements OnInit {
  constructor () { }

  ngOnInit (): void {
  }

  formula = new Formula('0');
  result: any = '';
  history = { clear: false, result: '' };

  title = 'Scientific Calculator';

  @HostListener('window:keyup', ['$event'])
  keyEvent (event: KeyboardEvent) {
    const key = event.key.toString();
    const digits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.'];
    if (digits.indexOf(key) !== -1) {
      this.addSymbol(key, false);
    }
    if (event.keyCode === 8) {
      this.removeSymbol();
    }
    if (event.keyCode === 13) {
      this.calculate();
    }
    if (event.keyCode === 27) {
      this.clear();
    }
    const operations = ['+', '-', '*', '/'];
    if (operations.indexOf(key) !== -1) {
      this.setOperation(key);
    }
    if (key === '%') {
      this.singleton('percent', -1);
    }
  }

  getFormula () {
    return this.formula.get();
  }

  clear (): any {
    this.history.result = ''
    this.history.clear = false;
    this.result = ''
    return this.formula.clear();
  }

  deleteLastChar () {
    console.log(this.formula.stack, this.formula.tempStack)
    if (this.history.clear) return;
    const lastValue = this.result.split('')
    lastValue && lastValue.length && lastValue.pop()
    this.result = (lastValue && lastValue.length > 0) ? lastValue.join('') : ''
  }

  setRadians (): boolean {
    const switcher = !this.getRadians();
    return this.formula.setRadians(switcher);
  }

  secondScreen (): boolean {
    const screen = !this.formula.secondScreen;
    this.formula.secondScreen = screen;
    return screen;
  }

  getScreen (): boolean {
    return this.formula.secondScreen;
  }

  getRadians (): boolean {
    return this.formula.radians;
  }

  sumToMemory () {
    this.formula.sumToMemory();
  }

  deductToMemory () {
    this.formula.deductToMemory();
  }

  clearMemory () {
    this.formula.clearMemory();
  }

  readMemory (): string {
    return this.formula.readMemory();
  }

  statusMemory (): boolean {
    return this.formula.in_memory;
  }

  valueMemory (): number {
    return this.formula.memory;
  }

  getOperand (): string {
    const o = this.formula.operation;
    if (o === '*') return '&#215;';
    return o;
  }

  resetOperand () {
    this.formula.operation = '';
    this.formula.stack = []
    this.formula.tempStack = []
  }

  singleton (operand: string, data: any) {
    if (this.history.clear) {
      this.history.clear = false;
      this.history.result = ''
      this.result = ''
    }
    // this.history.result += operand
    if (operand === 'percent') {
      if (this.formula.stack.length > 1) {
        const tempStack = [...this.formula.stack]
        this.formula.stack.push(this.formula.singleton(operand, data))
        this.result = this.formula.calcStack(this.formula.stack).join('');
        this.formula.stack = [...tempStack]
      }
    } else {
      if (parseFloat(this.result)) { this.result = this.formula.singleton(operand, data) }
    }
  }

  setOperation (operand: string): void {
    if (this.history.clear) {
      this.history.clear = false;
      this.history.result = ''
      this.result = ''
    }

    this.result = ''
    this.formula.setOperation(operand);
    this.history.result = this.formula.stack.join('')
  }

  addSymbol (value: string, start: boolean = false): void {
    if (this.history.clear) {
      this.history.clear = false;
      this.history.result = ''
      this.result = ''
    }
    // this.history.result += value
    this.result += value
    this.formula.addValue(value, start);
  }

  removeSymbol (): void {
    this.formula.removeSymbol();
  }

  calculate (): string {
    if (!this.formula.stack.length) {
      this.history.result = this.formula.tempStack && this.formula.tempStack.length ? '(' + this.formula.tempStack.join('') + ')' : ''
      return;
    }
    let lastValue;
    if (this.formula.is_operand) lastValue = 0
    lastValue = this.result.toString().length ? parseFloat(this.result) : 0
    this.formula.stack.push(lastValue);
    const value = this.formula.calculate().toString();
    this.result = this.formula.calcStack(this.formula.stack).join('')
    this.history.result = this.formula.tempStack.join('')
    this.history.clear = true;
    this.resetOperand();
    return value;
  }
}
