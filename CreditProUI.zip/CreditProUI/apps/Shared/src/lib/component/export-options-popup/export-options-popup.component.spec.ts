import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExportOptionsPopupComponent } from './export-options-popup.component';

describe('ExportOptionsPopupComponent', () => {
  let component: ExportOptionsPopupComponent;
  let fixture: ComponentFixture<ExportOptionsPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExportOptionsPopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExportOptionsPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
