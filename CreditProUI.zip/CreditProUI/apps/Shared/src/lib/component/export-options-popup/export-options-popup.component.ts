import { Component, OnInit } from '@angular/core';
import { Align, Offset } from '@progress/kendo-angular-popup';

@Component({
  selector: 'lib-export-options-popup',
  templateUrl: './export-options-popup.component.html',
  styleUrls: ['./export-options-popup.component.scss']
})
export class ExportOptionsPopupComponent implements OnInit {
  
  public toggleText = "UC-ExportOptionsPopup";
  public headerContent = "Export Trend Options:";
  public hyperLink1 = "- Export All Statements";
  public hyperLink2 = "- Export Selected:";
  public hyperLink3 = "All";
  public hyperLink4 = "None";
  public dialogOpened = false;
  public offset: Offset = { left: 100, top: 250 };
  public popupAlign: Align = { horizontal: "center", vertical: "center" };
  public textAreaValue = "";
  constructor() { }

  ngOnInit(): void {
  }
  public clearValue(): void {
    this.textAreaValue = "";
  }
  public onToggle(): void {
    this.dialogOpened = !this.dialogOpened;
  }
}
