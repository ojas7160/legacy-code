import { FooterComponent } from './footer/footer.component'
import { FpiGrdClosingSheetComponent } from './fpi-grd-closing-sheet/fpi-grd-closing-sheet.component'
import { FpiKendoGridComponent } from './fpi-kendo-grid/fpi-kendo-grid.component'
import { FpiOpeningSheetComponent } from './fpi-opening-sheet/fpi-opening-sheet.component'
import { HeaderComponent } from './header/header.component'
import { MenuComponent } from './menu/menu.component'
import { PurchasesSheetComponent } from './purchases-sheet/purchases-sheet.component'
import { UcBottomTabComponent } from './common/bottom-tab-customer/bottom-tab-customer.component'

import { UcBalanceSheetHeaderComponent } from './balancesheet/uc-balance-sheet-header/uc-balance-sheet-header.component';
import { UcConsolidationsComponent } from './consolidations/uc-consolidations/uc-consolidations.component';
import { UcReportsComponent } from './uc-reports/uc-reports.component';
import { ProjectionsComponent } from './projections/projections.component';
import { LoaderComponent } from './loader/loader/loader.component';
import { CropDetailsComponent } from './crop-details/crop-details.component';
import { OpenConsolidationComponent } from './open-consolidation/open-consolidation.component';
import { AdminOptionComponent } from './admin-option/admin-option.component';
import { AdjustmentDetailsComponent } from './adjustment-details/adjustment-details.component';
import { MessageDebugComponent } from './message-debug/message-debug.component';
import { CropDetailsBudgetComponent } from './crop-details-budget/crop-details-budget.component';
import { CustomerSearchComponent } from './customer-search/customer-search-dialog/customer-search.component';
import { CustomerStatementSearchComponent } from './customer-search/customer-statement-search/customer-statement-search.component';
import { CustomerLockInactivityComponent } from './customer-lock-inactivity/customer-lock-inactivity.component';
import { CustomerLockFailedComponent } from './customer-lock-failed/customer-lock-failed.component';
import { CustomerLockAvailableComponent } from './customer-lock-available/customer-lock-available.component';
import { CustomerLockAcquiredComponent } from './customer-lock-acquired/customer-lock-acquired.component';
import { ConsolidationsNewPopupComponent } from './consolidations/consolidations-new-popup/consolidations-new-popup.component';
import { SecondaryMenuComponent } from './menu/secondary-menu/secondary-menu.component';
import { GlobalPercentageComponent } from './global-percentage/global-percentage.component';
import { ExportOptionsPopupComponent } from './export-options-popup/export-options-popup.component';
import { ChangeViewPopupComponent } from './change-view-popup/change-view-popup.component';
import { CopyLogicPopupComponent } from './copy-logic-popup/copy-logic-popup.component';
import { DeleteConfirmationComponent } from './delete-confirmation/delete-confirmation.component';
import { ConsolidationsNoComponentAlertComponent } from './consolidations/consolidations-no-component-alert/consolidations-no-component-alert.component';
import { ActionsComponent } from './actions/actions.component';
import { ActiveDealsComponent } from './active-deals/active-deals.component';

import { OpenStatementComponent } from './open-statements/open-statements.component';
import { StatementSelectionReportComponent } from './uc-reports/statement-selection-report/statement-selection-report.component';
import { OpenDeleteConfirmationStatementComponent } from './open-delete-confirmation-statement/open-delete-confirmation-statement.component';
import { ReportOptionsComponent } from './uc-reports/report-options/report-options.component';
import { ReportListComponent } from './uc-reports/report-list/report-list.component';
import { ReportBottomGridComponent } from './uc-reports/report-bottom-grid/report-bottom-grid.component';
import { ExcludeSpecDetailsComponent } from './uc-reports/exclude-spec-details/exclude-spec-details.component';
import { AdminPersonalizationComponent } from './admin/admin-personalization/admin-personalization.component';
// import { MulticheckFilterComponent } from '../../lib/component/common/multicheck-filter/multicheck-filter.component';
import { LinkedFinancialComponent } from './financial-corporation/linked-financial/linked-financial.component'
import { ModalSelectFinancialComponent } from './modal-select-financial/modal-select-financial.component'
import { PercentAdjustComponent } from './consolidations/percentage-adjustment/percent-adjust.component';
import { EquityInCorporationComponent } from './coa/equity-in-corporation/equity-in-corporation.component';
import { ModalContentComponent } from './coa/equity-in-corporation/modal-content/modal-content.component';
import { GridCustomerStatementSearchComponent } from './coa/grid-copy-statement/grid-customer-statement-search/grid-customer-statement-search.component';
import { CashSavingsComponent } from './coa/cash-savings/cash-savings.component'
import { GridCommonModalComponent } from './coa/grid-common-modal/grid-common-modal.component'
import { MulticheckFilterComponent } from './common/multicheck-filter/multicheck-filter.component'
import { BalancesheetCopyStatementPopupComponent } from './balancesheet/balancesheet-copy-statement-popup/balancesheet-copy-statement-popup.component'
import { OpenConsolidationsComponent } from './consolidations/open-consolidations/open-consolidations.component';
import { OpenEarningStatementComponent } from './earnings/open-earning-statement/open-earning-statement.component'

export * from './footer/footer.component'
export * from './fpi-grd-closing-sheet/fpi-grd-closing-sheet.component'
export * from './fpi-kendo-grid/fpi-kendo-grid.component'
export * from './fpi-opening-sheet/fpi-opening-sheet.component'
export * from './header/header.component'
export * from './menu/menu.component'
export * from './purchases-sheet/purchases-sheet.component'

export * from './balancesheet/uc-balance-sheet-header/uc-balance-sheet-header.component';
export * from './consolidations/percentage-adjustment/percent-adjust.component';
export * from './consolidations/uc-consolidations/uc-consolidations.component';
export * from './uc-reports/uc-reports.component';
export * from './projections/projections.component';
export * from './loader/loader/loader.component';
export * from './balancesheet/balance-sheet2/balance-sheet2.component';
export * from './submenu/submenu.component';
export * from './common/advance-grid/advance-grid.component';
export * from './earnings/earnings.component';
export * from './admin/admin.component';
export * from './admin/admin-personalization/admin-personalization.component';
export * from './error-window/error-window.component';
export * from './alert-dialog/alert-dialog.component';
export * from './admin-menu/admin-menu.component';
export * from './balancesheet/new-edit-balance-sheet/new-edit-balance-sheet.component';
export * from './crop-details/crop-details.component';
export * from './open-consolidation/open-consolidation.component';
export * from './admin-option/admin-option.component';
export * from './adjustment-details/adjustment-details.component';
export * from './message-debug/message-debug.component';
export * from './crop-details-budget/crop-details-budget.component';
export * from './customer-lock-inactivity/customer-lock-inactivity.component';
export * from './customer-lock-failed/customer-lock-failed.component';
export * from './customer-lock-available/customer-lock-available.component';
export * from './customer-lock-acquired/customer-lock-acquired.component';
export * from './balancesheet/master-detail/master-detail.component';
export * from './earnings/earnings-statement-header/earnings-statement-header.component';
export * from './menu/secondary-menu/secondary-menu.component';
export * from './global-percentage/global-percentage.component';
export * from './admin/admin-coa-row-properties/admin-coa-row-properties.component';
export * from './delete-confirmation/delete-confirmation.component';
export * from './home/home.component';
export * from './home/home-help-topic/home-help-topic.component';
export * from './home/home-information-topic/home-information-topic.component';
export * from './customer-header/customer-header.component';
export * from './home/home-help-topic/home-help-topic.component';
export * from './home/home-information-topic/home-information-topic.component';
export * from './earnings/new-edit-earnings/new-edit-earnings.component';
export * from './calculator/calculator.component';
export * from './earning-copy-statement-popup-list/earning-copy-statement-popup-list.component';
export * from './earning-statements-list/earning-statements-list.component'
export * from './coa/equity-in-corporation/equity-in-corporation.component'
// common user controls
export * from './common/date-input/date-input.component'
export * from './common/drop-down/drop-down.component'
export * from './common/button-and-link/button-and-link.component'
export * from './common/comments-editor/comments-editor.component'
export * from './common/grid-buttons-actions/grid-button-actions.component'
export * from './common/error-component/error-component.component'
export * from './common/simple-grid/simple-grid.component'

export * from './customer-search/customer-search-dialog/customer-search.component';
export * from './customer-search/customer-statement-search/customer-statement-search.component';
export * from './customer-header/customer-header-popup/customer-header-popup.component';
export * from './earnings/open-projected-es/open-projected-es.component';
export * from './common/multicheck-filter/multicheck-filter.component';
export * from './common/help-info-icon/help-info-icon.component';
export * from './consolidations/bs-consolidation-copy/bs-consolidation-copy.component';
export * from './consolidations/open-consolidations/open-consolidations.component';

export const SHARED_COMPONENTS = [
  FooterComponent,
  FpiGrdClosingSheetComponent,
  FpiKendoGridComponent,
  FpiOpeningSheetComponent,
  HeaderComponent,
  MenuComponent,
  PurchasesSheetComponent,
  UcBalanceSheetHeaderComponent,
  UcConsolidationsComponent,
  UcReportsComponent,
  ProjectionsComponent,
  LoaderComponent,
  CropDetailsComponent,
  OpenConsolidationComponent,
  OpenStatementComponent,
  OpenDeleteConfirmationStatementComponent,
  AdminOptionComponent,
  AdminPersonalizationComponent,
  AdjustmentDetailsComponent,
  MessageDebugComponent,
  CropDetailsBudgetComponent,
  CustomerLockInactivityComponent,
  CustomerLockFailedComponent,
  CustomerLockAvailableComponent,
  CustomerLockAcquiredComponent,
  ConsolidationsNewPopupComponent,
  PercentAdjustComponent,
  SecondaryMenuComponent,
  GlobalPercentageComponent,
  ExportOptionsPopupComponent,
  ChangeViewPopupComponent,
  CopyLogicPopupComponent,
  DeleteConfirmationComponent,
  ConsolidationsNoComponentAlertComponent,
  ActionsComponent,
  ActiveDealsComponent,
  CustomerSearchComponent,
  CustomerStatementSearchComponent,
  StatementSelectionReportComponent,
  ReportOptionsComponent,
  ReportListComponent,
  ReportBottomGridComponent,
  ExcludeSpecDetailsComponent,
  UcBottomTabComponent,
  //MulticheckFilterComponent,
  EquityInCorporationComponent,
  ModalContentComponent,
  LinkedFinancialComponent,
  ModalSelectFinancialComponent,
  OpenConsolidationsComponent,
  GridCustomerStatementSearchComponent,
  CashSavingsComponent,
  GridCommonModalComponent,
  BalancesheetCopyStatementPopupComponent,
  OpenEarningStatementComponent
]
