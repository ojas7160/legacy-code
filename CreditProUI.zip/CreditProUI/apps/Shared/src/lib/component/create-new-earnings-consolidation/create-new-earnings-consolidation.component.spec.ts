import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateNewEarningsConsolidationComponent } from './create-new-earnings-consolidation.component';

describe('CreateNewEarningsConsolidationComponent', () => {
  let component: CreateNewEarningsConsolidationComponent;
  let fixture: ComponentFixture<CreateNewEarningsConsolidationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateNewEarningsConsolidationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateNewEarningsConsolidationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
