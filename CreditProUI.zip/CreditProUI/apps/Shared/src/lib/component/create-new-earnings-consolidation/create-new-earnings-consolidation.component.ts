import { Component, OnInit,ElementRef ,ViewChild} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { KendoModalService } from '../../services';
import {EarningCopyStatementPopupComponent} from '../earning-copy-statement-popup/earning-copy-statement-popup.component'
import { newEarnings } from '../../models/newEarnings.model';
import { RestService } from '../../services';
import { environment } from 'apps/CreditPro/src/environments/environment';
import {ShareStatementDataService} from '../../services/earnings/shareStatementDataService'
import { Subject } from 'rxjs';
import { WindowRef } from '@progress/kendo-angular-dialog';
import { Icons } from '../../enum'
import {DateTransformPipe} from '../../pipes/dateTransform.pipe'
import { ErrorDesc, ErrorObj } from '../../models/errorDescription';
import { ConsoNewEarningsLinksComponent } from '../conso-new-earnings-links/conso-new-earnings-links.component';
import { EarningsLinkStatementComponent } from '../earnings/earnings-link-statement/earnings-link-statement.component';

@Component({
  selector: 'app-create-new-earnings-consolidation',
  templateUrl: './create-new-earnings-consolidation.component.html',
  styleUrls: ['./create-new-earnings-consolidation.component.scss']
})
export class CreateNewEarningsConsolidationComponent implements OnInit {
  public _icons = Icons;

  title = 'FPI';
  copyPopUpRef;
  public opened = true;
   public startDate: Date = null;
   public endDate: Date = null;
   public startValue: Date = new Date();
  public endValue: Date = new Date();
  public dataSaved = false;
  public earningStatement: any="earningStatement";
  errors : Array<string>=[];
  private popupRef;
  public toggleLinkArrowStyle = "<span class='k-icon k-i-arrow-60-right pl-2'></span>";
  errorDesc: ErrorDesc[];
  errorObj: ErrorObj[] = [];
  submitted: boolean;
  spanClass : string = "<span class='k-icon k-i-arrow-60-right pl-2'></span>";
  public value: Date = new Date();
  public TypeList: Array<any> = [{text:'Consolidation',value:'Consolidation'}];
  public Source_DateList: Array<any> = [{text:'Select data to consolidate',value:'-1'},
  {text:'Cash',value:'Cash'}, {text:'Accrual',value:'Accrual'}];
  public FinQualityList: Array<any> = [ {text: "Select financial quality", value: "-1" },
  {text:'Audit',value:'Audit'},
  {text:'Compilation',value:'Compilation'} , 
  {text:'Electronic Records - ACA',value:'Electronic Records - ACA'},
  {text:'Electronic Records - Other',value:'Electronic Records - Other'} ,
   {text:'Manual',value:'Manual'},{text:'Review',value:'Review'},
   {text:'Tax Return - ACA',value:'Tax Return - ACA'},
   {text:'Tax Return - Other',value:'Tax Return - Other'}];
  public ActiveTemplateList: Array<any> = [{text: "Select active template",value: "-1"},
  {text:'Ag Retail',value:'Ag Retail'}, 
    {text:'Aquatic',value:'Aquatic'},
  {text:'Cash Field',value:'Cash Field'} , 
  {text:'Carnberries',value:'Carnberries'} ,
  {text:'Dairy Livestock',value:'Dairy Livestock'} ,
  {text:'Equine',value:'Equine'} ,
  {text:'Forest Products',value:'Forest Products'} ,
  {text:'General',value:'General'} ,
  {text:'Greenhouse',value:'Greenhouse'} ,
  {text:'Master',value:'Master'} ,
  {text:'Winery',value:'Winery'} ];

  messageShow = false;

	@ViewChild("copyEarningComponentAnchorFirst") public copyEarningComponentAnchorFirst: ElementRef;
  @ViewChild("linkEarningAnchor") public linkEarningAnchor: ElementRef;
  unsubscribe$: Subject<boolean> = new Subject();
  earningstatement : any;

  
  public earingsOpeningBSData:Array<any>=[
    {
      CustomerBID: -1,
     CustomerTaskBID: -1,
     CustomerTaskCde: -1,
     FinancialStatementBID: -1, 
     FinancialStatementDesc: 'Select opening balance sheet',
     FinancialStatementEndDte: '',
     FinancialStatementStartDte: '',
     FinancialStatementSubTypeCde: -1,
     LastViewedDate: '',
     OwnerUserID: -1,
     TaskDescription: ''
  }
  ];
  

  public earingsClosingOpeningBSData: any={
    CustomerBID: -1,
   CustomerTaskBID: -1,
   CustomerTaskCde: -1,
   FinancialStatementBID: -1, 
   FinancialStatementDesc: '',
   FinancialStatementEndDte: 'Select closing balance sheet',
   FinancialStatementStartDte: '',
   FinancialStatementSubTypeCde: -1,
   LastViewedDate: '',
   OwnerUserID: -1,
   TaskDescription: ''
}
  newEarning =new newEarnings('-1',null,null,'',this.TypeList[0],this.Source_DateList[0],this.FinQualityList[0],this.ActiveTemplateList[0],null,null);

 
  public defaultOpenBSList: { FinancialStatementDesc: string; CustomerTaskBID: string } = {
    FinancialStatementDesc: "Select opening balance sheet",
    CustomerTaskBID: "-1",
  };

  public defaultClosingBSList: { FinancialStatementDesc: string; CustomerTaskBID: string } = {
    FinancialStatementDesc: "Select closing balance sheet",
    CustomerTaskBID: "-1",
  }; 

  constructor(private router:Router, 
    private restService:RestService,
    private kendoModalService:KendoModalService,
    private dataservice : ShareStatementDataService,
    private windowRef:WindowRef) { 
    const jsonUrl = environment.endpoints.earningCustomerBSURL;
    // To be used later for API Call
    //http://10.161.51.209:41751/MMCAServiceRest.svc/apinew/RetrieveFavoriteRecentCustomersByUserID 
    this.restService.get(jsonUrl).subscribe(data => {
      
      console.log("menu comp", data.CustomerTasks);
      this.earingsOpeningBSData = data.CustomerTasks;
      this.earingsClosingOpeningBSData = data.CustomerTasks;

      this.earingsOpeningBSData.unshift({
         CustomerBID: -1,
         CustomerTaskBID: -1,
         CustomerTaskCde: -1,
         FinancialStatementBID: -1, 
         FinancialStatementDesc: 'Select opening balance sheet',
         FinancialStatementEndDte: '',
         FinancialStatementStartDte: '',
         FinancialStatementSubTypeCde: -1,
         LastViewedDate: '',
         OwnerUserID: -1,
         TaskDescription: ''
  });

//   this.earingsClosingOpeningBSData.unshift({
//     CustomerBID: -1,
//     CustomerTaskBID: -1,
//     CustomerTaskCde: -1,
//     FinancialStatementBID: -1, 
//     FinancialStatementDesc: 'Select closing balance sheet',
//     FinancialStatementEndDte: '',
//     FinancialStatementStartDte: '',
//     FinancialStatementSubTypeCde: -1,
//     LastViewedDate: '',
//     OwnerUserID: -1,
//     TaskDescription: ''
// });
    });

    this.dataservice.getProfileObs().subscribe(earningstatement => {
      this.earningstatement = earningstatement
      
      if(this.earningstatement != null){
        const filterPipe = new DateTransformPipe();
        this.newEarning.startDate = new Date(filterPipe.transform(this.earningstatement.FinancialStatementStartDte,'MM/DD/yyyy'));//new Date(this.earningstatement.startdate);
        this.newEarning.endDate = new Date(filterPipe.transform(this.earningstatement.FinancialStatementEndDte,'MM/DD/yyyy'));// new Date(this.earningstatement.enddate);
        this.newEarning.type = this.TypeList.find(i => i.value === this.earningstatement.type);
        this.newEarning.sourceData = this.Source_DateList.find(i => i.value === this.earningstatement.sourcedate);
        this.newEarning.financialQty = this.FinQualityList.find(i => i.value === this.earningstatement.financialquality);
        this.newEarning.activeTemplate = this.ActiveTemplateList.find(i => i.value === this.earningstatement.activetemplate);
        this.startValue = new Date(filterPipe.transform(this.earningstatement.FinancialStatementStartDte,'MM/DD/yyyy'));
        this.endValue = new Date(filterPipe.transform(this.earningstatement.FinancialStatementEndDte,'MM/DD/yyyy'));
        // const fiteredArr = filterPipe.transform(this.earningstatement.startdate,'MM/DD/yyyy');
        // console.log('this.startDate : ',fiteredArr);
      }

      // console.log('this.earningstatement : ', this.earningstatement);
    });

  }

  // public newEarningsFrom: FormGroup = new FormGroup({
  //   labelvalue: new FormControl(),
  // });

  ngOnInit(): void {
    this.dataservice.getProfileObs().subscribe(earningstatement => this.earningstatement = earningstatement);
    // alert(JSON.stringify(this.earningstatement));
    console.log('earning statement from subject : ' + JSON.stringify(this.earningstatement))
  }

  //get f() { return this.newEarningsFrom.controls;}

  public close(event?) {
    this.opened = false;
  }

  public open() {
    this.opened = true;
  }

  // validateAll() {

   
  //   if(this.newEarning.startDate==null){
  //     this.errors.push("Start Date : Earning Statement Start Date is required for: Save");
  //   }

  //    if(this.newEarning.endDate==null){
  //     this.errors.push('EndDate : Earning Statement End Date is required for: Save');
  //    }

  //    if(this.newEarning.labelValue==null || this.newEarning.labelValue==""){
  //     this.errors.push('Description : Description is required for: Save');
  //    }

  //    if(this.newEarning.sourceData["value"]=="-1"){
  //     this.errors.push('Financial Source : Financial Source is required for: Save');
  //   }

  //    if(this.newEarning.activeTemplate["value"]=="-1"){
  //     this.errors.push('Active Template : Earning Statement Template is required for: Save');
  //    }

  //    if(this.errors==null)
  //    {
  //      alert("Earning statement save sicessfully");
  //    }
  // }

  // setErrorDesc(control: any, desc: string, fControlValue?: boolean, dateError?: boolean) {
  //   let _errorObj;
  //   // customErrorMessage = string.Format("{0} must be {1} character(s) long.", rule.DisplayName, length);


  //   if (this.newEditBSForm.controls[control].hasError('required') || fControlValue) {
  //     _errorObj = {
  //       key: this.map.get(control),
  //       value: `${desc} is required for: ${this.errorDesc[0].RequiredFieldTypeDesc}.`
  //     }
  //     fControlValue ? this.fControlError = _errorObj.value : this.errorObj.push(_errorObj);
  //     if (control == 'bsDate') {
  //       this.displayError = `${desc} is not in the correct format. The correct format is: Date (e.g. "02/02/1993")`;
  //     }
  //     else if (dateError == false && control == 'Balance Sheet Date') {
  //       this.displayError = "";
  //     }

  //   }

  //   else if (this.newEditBSForm.controls[control].hasError('maxlength')) {
  //     _errorObj = {
  //       key: this.map.get(control),
  //       value: `${desc} must be : ${this.newEditBSForm.controls[control].errors.maxlength.requiredLength} character(s) long.`
  //     }
  //     this.errorObj.push(_errorObj);
  //   }

  //   // this.errorObj.push(_errorObj);
  // }


  
  public submit(event?) {
    
    this.dataSaved = true;
    this.close();
  }

  copyEarningForm(copyEarningComponentAnchorFirst: ElementRef) {
    let params: any;

    params = {
      anchor: copyEarningComponentAnchorFirst,
      anchorAlign: {
        horizontal: "right", vertical: "top"
      },
      popupAlign: {
        horizontal: 'left', vertical: 'top', margin: '50px'
      }
    }
    
    if (this.copyPopUpRef) {
     this.closeAdditionalPopup(this.copyPopUpRef);
      this.copyPopUpRef = null;
    } else {
      this.closeAdditionalPopup(this.popupRef);
      this.popupRef = null;
      this.copyPopUpRef = this.kendoModalService.open('popup',
      'copyEarningForm',
      EarningCopyStatementPopupComponent,
      params);
    }
  }

  toggleLinkEarningStatements(linkEarningAnchor: ElementRef) {
    let params: any;
    params = {

      anchor: linkEarningAnchor,
      anchorAlign: {
        horizontal: "right", vertical: "top"
      },
      popupAlign: {
        horizontal: 'left', vertical: 'top', margin: '50px'
      }
    }
    if (this.popupRef) {
      this.closeAdditionalPopup(this.popupRef);
      this.popupRef = null;
    } else {
      this.closeAdditionalPopup(this.copyPopUpRef);
      this.copyPopUpRef = null;
      this.popupRef = this.kendoModalService.open('popup',
        'earningsStatementNewLinkForm',
        EarningsLinkStatementComponent,
        params);
      this.toggleLinkArrowStyle = "<span class='k-icon k-i-arrow-60-left pl-2'></span>";
    }

	}

  // ngOnDestroy(){
  //   this.kendoModalService.close('popup', this.popupRef);
  //   this.popupRef = null;
  // }


 
  ngOnDestroy(){

    if (this.popupRef) {
      this.closeAdditionalPopup(this.popupRef);
      this.popupRef = null;
    }else if(this.copyPopUpRef){
      this.closeAdditionalPopup(this.copyPopUpRef);
      this.popupRef = null;
    }
    
    // this.kendoModalService.close('popup', this.popupRef);
    // this.popupRef = null;

    // this.kendoModalService.close('popup', this.copyPopUpRef);
    // this.copyPopUpRef = null;

    

    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }


  onSubmit() { 
    console.log(JSON.stringify(this.newEarning));
    let _errorObj;
    if(this.newEarning.startDate==null){
     // this.errors.push("Start Date : Earning Statement Start Date is required for: Save");
     _errorObj = {
        key: "Start Date :",
        value: "Earning Statement Start Date is required for: Save"
      }
      this.errorObj.push(_errorObj);
    }

     if(this.newEarning.endDate==null){
     // this.errors.push('EndDate : Earning Statement End Date is required for: Save');
      _errorObj = {
        key: "End Date :",
        value: "Earning Statement End Date is required for: Save"
      }
      this.errorObj.push(_errorObj);
     }

     if(this.newEarning.labelValue==null){
       if(this.newEarning.labelValue==""){
//this.errors.push('Description : Description is required for: Save');
_errorObj = {
  key: "Description :",
  value: "Description is required for: Save"
}
this.errorObj.push(_errorObj);
       }
      
     }

     if(this.newEarning.sourceData["value"]=="-1"){
      //this.errors.push('Financial Source : Financial Source is required for: Save');
      _errorObj = {
        key: "Financial Source :",
        value: "Financial Source is required for: Save"
      }
      this.errorObj.push(_errorObj);
    }

     if(this.newEarning.activeTemplate["value"]=="-1"){
      //this.errors.push('Active Template : Earning Statement Template is required for: Save');
      _errorObj = {
        key: "Active Template :",
        value: "Earning Statement Template is required for: Save"
      }
      this.errorObj.push(_errorObj);
     }

     if(this.errorObj==null)
     {
       alert("Earning statement save sicessfully");
     }
     else
     {
      this.dataservice.setNewEarningStatment(this.newEarning);
      this.router.navigate(['/earnings']);
      this.windowRef.close();
     }
    this.dataSaved = true;
    this.earningWindowClose();
  }

  public earningWindowClose() {
    this.windowRef.close()
  }

  // public valueChange(typevalue?) {
  //   alert("valueChange", typevalue);
  // }
  closeAdditionalPopup(refPopUp: any) {
    if (refPopUp) {
      this.kendoModalService.close('popup', refPopUp);
      this.toggleLinkArrowStyle = "<span class='k-icon k-i-arrow-60-right pl-2'></span>";
    }
  }


  openFile(){
    let uploder = document.getElementById('fileUpload');
    uploder.click()
  }

  handle(e){
    console.log('Change input file')
  }
}

