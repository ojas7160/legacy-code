import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerLockAcquiredComponent } from './customer-lock-acquired.component';

describe('CustomerLockAcquiredComponent', () => {
  let component: CustomerLockAcquiredComponent;
  let fixture: ComponentFixture<CustomerLockAcquiredComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerLockAcquiredComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerLockAcquiredComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
