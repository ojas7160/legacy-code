import { Component, HostListener, OnInit, TemplateRef, ViewChild, ViewEncapsulation, SimpleChanges } from '@angular/core';
import { RestService } from '../../../../services/rest/rest-service.service';
import { BSHeaderPriorBS } from '../../../../models/balanceSheet/bsHeaderPriorBS';
import { TreeNode } from '../../../../models/balanceSheet/TreeNode';
import { Observable } from 'rxjs';
import { TreeItem } from "@progress/kendo-angular-treeview";
import { DropDownTreeComponent } from "@progress/kendo-angular-dropdowns";
import { FinancialStatementSubTypes } from "../../../../enum/financialStatementSubTypes";
import { AppConstant } from '../../../../constants/app-constants';
import { environment } from '../../../../../../../CreditPro/src/environments/environment';
import { select, Store } from '@ngrx/store';
import { AppState } from 'apps/Shared/src/lib/store';
import { benchmarkSelector } from 'apps/Shared/src/lib/store/selectors/benchmark/benchmark.selector';
import *  as benchmarkActions from 'apps/Shared/src/lib/store/actions/benchmark/benchmark.action'
import * as balanceSheet from 'apps/Shared/src/lib/store/actions/balanceSheet/balanceSheet.action';
import { commonSelector } from 'apps/Shared/src/lib/store/selectors/common.selector';
import { CachedLookups } from 'apps/Shared/src/lib/enum/cachedLookups';
import { KendoModalService, SelectedCustomerService } from 'apps/Shared/src/lib/services';
import { FinancialStatementLinkTypes } from 'apps/Shared/src/lib/enum/financialStatementLinkTypes';
import { sortBy } from 'lodash';
import * as moment from 'moment';
import { loadAllUsersSelector } from 'apps/Shared/src/lib/store/selectors/balanceSheet/balanceSheet-link-selector';

@Component({
  encapsulation: ViewEncapsulation.None,
  selector: 'uc-balance-sheet-header-link',
  templateUrl: './balance-sheet-header-link.component.html',
  styleUrls: ['./balance-sheet-header-link.component.scss']
})
export class BalanceSheetHeaderLinkComponent implements OnInit {

  @ViewChild("dropdownTree") public dropdownTree: DropDownTreeComponent;
  @ViewChild('benchmarkPopup') benchmarkPopupTemplate: TemplateRef<any>;
  anchor: any;
  tooltip = {prior: false, associated: false}
  tooltipValue: any;
  dateFormat = AppConstant.dateFormat

  @HostListener('document:click', ['$event'])
  public documentClick(event: any): void {

    if (!this.contains(event.target)) {
      this.benchmarkPopup && this.kendoModalService.close('popup', this.benchmarkPopup)
      this.benchmarkPopup = null
    }
  }

  public userId = 0;

  public priorBSForENW: BSHeaderPriorBS[];
  public selectedPriorBSForENW: any;
  public tlkpBenchmarkIndustryTemplate: any[];
  public linkedEarningsHeaders: any[] = [];
  public benchmarkIndustryTreeNodes: TreeNode[] = [];

  public opened = true;
  whichComponent = '';
  benchmarkPopup;

  //Tree related 
  /**
  * The field that holds the keys of the expanded nodes.
  */
  public expandedNodes: number[] = [];
  public expandedKeys: any[] = [];

  public show: boolean = false;

  public selectedKeys: any[] = [];
  public selectedBenchmarkData: TreeNode = {
    id: 0,
    desc: '',
    desc2: '',
    data: undefined,
    icon: false,
    iconPath: "",
    iconType: 0,
    children: [],
    nodeLevel: -1,
    parantid: 0,
    parantDesc: '',
    parantDesc2: ''

  };
  lookUps: any;


  constructor(private _restservice: RestService, 
    private store: Store<AppState>, 
    private kendoModalService: KendoModalService,
    private selectedCustServ : SelectedCustomerService) {

  }
   ngOnInit(): void {
    this.loadLookUps();
    this.initializeFormLoad();    
  }

  contains(e) {
    return (
      (this.anchor && this.anchor.contains(e)) ||
      (this.benchmarkPopup && this.benchmarkPopup.popupElement.contains(e))
    )
  }

  setBenchmarkTreeNodeData(data) {
    this.benchmarkIndustryTreeNodes = [];
    Object.keys(data).map(item => {
      this.benchmarkIndustryTreeNodes.push(data[item]);
    })
     this.benchmarkIndustryTreeNodes.unshift({data: {},
          id: 0,
          nodeLevel: 0,
          children: null,
          desc: 'Done',
          icon: false,
          iconPath: "",
          parantid: 0})
  }

  initializeFormLoad() {
    // this.getBenchmarkData();
    let paramsData: any = { "selectedFinancialStatementBIDs": [], "financialStatementType": FinancialStatementSubTypes.BalanceSheet };
    this.store.dispatch(benchmarkActions.loadBenchmarkData(paramsData))
    this.store.pipe(select(benchmarkSelector)).subscribe(val => {
      if(val && val.benchmarkBS){
        this.setBenchmarkTreeNodeData(val.benchmarkBS);
      }
    })
    setTimeout(() => {
      if (!this.whichComponent?.includes('Consolidation') || !this.priorBSForENW?.length) {
        this.loadPriorBSForENW();
      }
    }, 0)

  }

  updateLinkedEarningHeaders(data) {
    this.linkedEarningsHeaders = data.filter(val => 
      val.BalanceSheetHeaderFinancialStatementLinkTypeCde == FinancialStatementLinkTypes.EarningsToOpeningBalanceSheet ||
      val.BalanceSheetHeaderFinancialStatementLinkTypeCde == FinancialStatementLinkTypes.EarningsToClosingBalanceSheet
      );
    const linkedEarningData = this.linkedEarningsHeaders?.map(it => { return { ...it, FinancialStatementEndDte: new Date(moment.utc(it.FinancialStatementEndDte).format()) } })
    this.linkedEarningsHeaders = sortBy(linkedEarningData, 'FinancialStatementEndDte').reverse()
  }
 
  getInitialPriorData() : BSHeaderPriorBS{
    return {
      FinancialStatementBID: 0,
      CustomerBID: 0,
      FinancialStatementEndDte: '',
      FinancialStatementDesc: '',
      FinancialStatementStartDte: '',
      FinancialStatementSubTypeCde: 0,
      FinancialStatementTemplateCde: 0,
      IsDefault: true
    }
  }


  loadPriorBSForENW() {
    this.store.pipe(select(loadAllUsersSelector)).subscribe(val => {
      if(val && val.bSHeaderPriorBS.length !== 0) {
        let data = val.bSHeaderPriorBS.RetrieveBalanceSheetHeaderByIDResult;
        let balanceSheetHeaders = data.AvailableBalanceSheetHeaders;
        this.priorBSForENW = [];
        if(data?.LinkedEarningsHeaders?.length > 0){
          this.updateLinkedEarningHeaders(data.LinkedEarningsHeaders);
        }        
        const bsData = balanceSheetHeaders.map(element => this.mapToBSHeaderPriorBS(element));
        this.priorBSForENW = bsData.reverse();
        this.priorBSForENW.unshift(this.getInitialPriorData());
        this.selectedPriorBSForENW = this.getInitialPriorData()
      }
      else {
        const paramsData = {
          "customerBID": this.selectedCustServ.getCurrentSelectedCustomer2().customerId,
          "financialStatementBID": null, //this.selectedFinancialBID, 73288
          "groupBID": null,
          "Errors": []
        };
        this.store.dispatch(balanceSheet.priorBSForENW(paramsData));
      }
    })
  }

  mapToBSHeaderPriorBS(element: any): BSHeaderPriorBS {
    return {
      FinancialStatementBID: element.FinancialStatementBID,
      CustomerBID: element.CustomerBID,
      FinancialStatementEndDte: element.FinancialStatementEndDte,
      FinancialStatementDesc: element.FinancialStatementDesc,
      FinancialStatementStartDte: element.FinancialStatementStartDte,
      FinancialStatementSubTypeCde: element.FinancialStatementSubTypeCde,
      FinancialStatementTemplateCde: element.FinancialStatementTemplateCde,
      IsDefault: false
    };

  }

  loadLookUps() {
    this.store.pipe(select(commonSelector))
      .subscribe(res => {
        this.lookUps = res.GetLookupsResult?.length && res.GetLookupsResult;
      })
  }


  getBenchmarkData() {
    let paramsData: any = { "selectedFinancialStatementBIDs": [] };
    this._restservice.post(environment.baseURI + AppConstant.endpoints.retrieveBenchmarkNodes, paramsData)
    .subscribe(data => {
      let benchamrkLookUp = this.lookUps.find(it => it.Table.TableCde == CachedLookups.tlkpBenchmarkIndustryTemplate)
      this.tlkpBenchmarkIndustryTemplate = benchamrkLookUp?.LookupData;
      let groubedByBenchmarkIndustryTemplateCde = this.groupBy(data.RetrieveBenchmarkNodesResult.BenchmarkGroupNodes, 'BenchmarkIndustryTemplateCde');
      paramsData = {
        "benchmarkIDs": data.RetrieveBenchmarkNodesResult.BenchmarkNodes.map(val => val.BenchmarkID),
        "financialStatementType": FinancialStatementSubTypes.BalanceSheet,
        "Error": []
      };

      let lastLeafnodes: TreeNode[] = [];
      let benchmarkLastLeafNodeData = this.restMethodCall(environment.baseURI + AppConstant.endpoints.retrieveBenchmarkStatementNodesAll, paramsData).subscribe((e: any) => {
        let fhsCollections = e.RetrieveBenchmarkStatementNodesAllResult.flatMap((elem) => elem.FinancialSheetHeaders)


        lastLeafnodes = fhsCollections.map(leafchild => <TreeNode>{
          data: leafchild,
          id: leafchild.FinancialStatementBID,
          nodeLevel: 3,
          children: [],
          desc: leafchild.FinancialStatementEndDte,
          desc2: leafchild.FinancialStatementDesc,
          icon: true,
          iconType: leafchild.FinancialStatementSubTypeCde,
          iconPath: "",
          parantid: leafchild.DefaultBenchmarkID,
          parent: leafchild
        });
        this.benchmarkIndustryTreeNodes = [];

        for (let key in groubedByBenchmarkIndustryTemplateCde) {
          let industryTemplate = this.tlkpBenchmarkIndustryTemplate.find((x) => parseInt(x.Cde) === parseInt(key));
          let industryTemplatesData = this.LoadBenchmarkNode(this.tlkpBenchmarkIndustryTemplate, data, key, lastLeafnodes, ...groubedByBenchmarkIndustryTemplateCde[key]);

          this.benchmarkIndustryTreeNodes.push({
            data: industryTemplate,
            id: parseInt(industryTemplate?.Cde),
            nodeLevel: 0,
            children: industryTemplatesData,
            desc: industryTemplate?.Desc,
            icon: false,
            iconPath: "",
            parantid: 0
          });
        }
        benchmarkLastLeafNodeData.unsubscribe();
        this.benchmarkIndustryTreeNodes.sort((a, b) => a.desc < b.desc ? -1 : a.desc > b.desc ? 1 : 0);
        this.benchmarkIndustryTreeNodes.unshift({data: {},
          id: 0,
          nodeLevel: 0,
          children: null,
          desc: 'Done',
          icon: false,
          iconPath: "",
          parantid: 0})
      })

     
      });

     
  }


  LoadBenchmarkNode(tlkpBenchmarkIndustryTemplate: any, data: any, key: string, lastLeafnodes: TreeNode[], ...element): TreeNode[] {

    let benchmarkIndustryTreeNode: TreeNode[] = [];

    for (let e in element) {
      let nodes: any[] = [];
      let _d = data.RetrieveBenchmarkNodesResult.BenchmarkNodes.filter((bn) => bn.BenchmarkGroupBID === element[e].BenchmarkGroupBID)
      _d?.length && _d.forEach(ele => {


        nodes.push({
          data: ele,
          id: ele.BenchmarkID,
          nodeLevel: 2,
          children: lastLeafnodes.filter(x => x.parantid === ele.BenchmarkID),
          desc: ele.BenchmarkDesc,
          icon: false,
          iconPath: "",
          parantid: ele.BenchmarkGroupBID,
        });
      });

      benchmarkIndustryTreeNode.push({
        data: {
          BenchmarkGroupHeader: e,
          BenchmarkNodes: nodes
        },
        id: parseInt(element[e].BenchmarkGroupBID),
        nodeLevel: 1,
        children: nodes,
        desc: element[e].BenchmarkGroupName,
        icon: false,
        iconPath: ""
      });
    }

    return benchmarkIndustryTreeNode;

  }


  groupBy = function (xs, key) {
    return xs.reduce(function (rv, x) {
      (rv[x[key]] = rv[x[key]] || []).push(x);
      return rv;
    }, {});
  };






  /**
   * A function that checks whether a given node index exists in the expanded keys collection.
   * If the item ID can be found, the node is marked as expanded.
   */
  public isNodeExpanded = (node: any): boolean => {
    return this.expandedNodes.indexOf(node.id) !== -1;
  };

  /**
   * A `nodeCollapse` event handler that will remove the node data item ID
   * from the collection, collapsing its children.
   */
  public handleCollapse(args: TreeItem): void {
    this.expandedNodes = this.expandedNodes.filter(
      (id) => id !== args.dataItem.id
    );
  }

  /**
   * An `nodeExpand` event handler that will add the node data item ID
   * to the collection, expanding the its children.
   */
  public handleExpand(args: any): void {
    this.expandedNodes = this.expandedNodes.concat(args.dataItem.id);
    // this.BindStatementNode(args.index);

  }



  public onToggle(anchor): void {
    // this.show = !this.show;
    if (this.benchmarkPopup) {
      this.kendoModalService.close('popup', this.benchmarkPopup)
      this.benchmarkPopup = null
    } else {
      this.anchor = anchor
      this.benchmarkPopup = this.kendoModalService.open('popup', '', this.benchmarkPopupTemplate, { anchor: anchor, popupClass: 'AssociatedBenchmark' })
    }
  }

  public handleSelection(e: any): void {
    if (!e.dataItem.children || !e.dataItem.children.length) {
      this.selectedBenchmarkData = e.dataItem
      this.selectedBenchmarkData.parantDesc = e.dataItem.data?.FinancialStatementDesc;
      this.selectedBenchmarkData.parantDesc2 = e.dataItem.desc2;
      this.benchmarkPopup && this.kendoModalService.close('popup', this.benchmarkPopup)
      this.benchmarkPopup = null
    }
    else {
      this.selectedBenchmarkData = {
        id: 0,
        desc: '',
        desc2: '',
        data: undefined,
        icon: false,
        iconPath: "",
        iconType: 0,
        children: [],
        nodeLevel: -1,
        parantid: 0,
        parantDesc: '',
        parantDesc2: ''

      };
    }
  }



  restMethodCall(url, paramData): Observable<any> {
    return this._restservice.post(url, paramData);
  }

  getTooltipValue(event: any): void {
      this.tooltipValue = event.value;
  }

  showDidYouKnowTooltip (checked, anchor) {
    if (this.tooltipValue === 'none') {
      return;
    }
    this.tooltip = {prior: false, associated: false}
    this.tooltip[anchor] = checked
  }

  public itemDisabled (itemArgs: { dataItem: any; index: number }) {
    return itemArgs.dataItem.FinancialStatementBID == 0
  }

  priorSelection(e) {
    this.selectedPriorBSForENW = e
  }

  // onClose(e) {
  //   e.preventDefault();
  // }


}


