import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UcBalanceSheetHeaderComponent } from './uc-balance-sheet-header.component';

describe('UcBalanceSheetHeaderComponent', () => {
  let component: UcBalanceSheetHeaderComponent;
  let fixture: ComponentFixture<UcBalanceSheetHeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UcBalanceSheetHeaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UcBalanceSheetHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
