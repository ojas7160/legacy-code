/* eslint-disable eqeqeq */
import { Component, OnInit, ViewChild, ElementRef, Input, ViewEncapsulation, TemplateRef, OnDestroy, SimpleChanges } from '@angular/core'
import { KendoModalService, RestService, SelectedCustomerService } from '../../../services'
import { BalanceSheetLookUp } from '../../../models/balanceSheetLookUp'
import { FinancialStatementTypes } from '../../../enum/financialStatementTypes'
import { CachedLookups } from '../../../enum/cachedLookups'
import { LookupTable, LookupTables } from '../../../models/LookupTables'
import { ListControl } from '../../../models/listControl'
import { FormBuilder, FormGroup, Validators } from '@angular/forms'
import { DcCustomer } from '../../../models/customer'
import { ModalOpenMode } from '../../../enum/modelOpen'
import { CommentEditor } from '../../common/comments-editor/comments-editor.component'
import { DcComment } from '../../../models/comment'
import { DateValidator } from '../../../customValiadtions/dateValidation'
import { ErrorDesc, ErrorObj } from '../../../models/errorDescription'
import { BalanceSheetHeaderLinkComponent } from '../balance-sheet2/balance-sheet-header-link/balance-sheet-header-link.component'
import { environment } from 'apps/CreditPro/src/environments/environment'
import { DTOAction } from '../../../enum'
import { UtilityService } from '../../../services/utility/utility.service'
import { WindowRef } from '@progress/kendo-angular-dialog'
import { TooltipDirective } from '@progress/kendo-angular-tooltip'
import { FinancialStatementSubTypes } from '../../../enum/financialStatementSubTypes'
import * as commentsActions from '../../../store/actions/comments.action';
import { AppState } from '../../../store'
import { select, Store } from '@ngrx/store'
import { commentsSelector } from '../../../store/selectors/comments.selector'
import { forkJoin, Observable } from 'rxjs'
import { AppConstant } from '../../../constants/app-constants'
import * as moment from 'moment'
import { uniqBy } from 'lodash';
import { BsConsolidationCopyComponent } from '../../consolidations/bs-consolidation-copy/bs-consolidation-copy.component'
import { BalancesheetCopyStatementPopupComponent } from '../balancesheet-copy-statement-popup/balancesheet-copy-statement-popup.component'
import { DateTransformPipe } from '../../../pipes/dateTransform.pipe'

@Component({
  selector: 'lib-new-edit-balance-sheet',
  templateUrl: './new-edit-balance-sheet.component.html',
  styleUrls: ['./new-edit-balance-sheet.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class NewEditBalanceSheetComponent implements OnInit, OnDestroy {
  @Input() financialStatementBID: number;
  @Input() whichComponent = 'Balance Sheet'
  @Input() hideElement: any = {}
  @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;
  lookUps: any;
  summaryDescId: number;

  title = 'FPI';
  opened = true;
  closed = false;
  dataSaved = false;
  isShown = false;
  balanceSheetLookUp: BalanceSheetLookUp[];
  value: Date = new Date();
  OpenMode: number;
  showSumDescIcon: boolean;
  showCNIcon: boolean;
  cNDelRoatated = false;
  sumDescDelRoatated = false;

  fControlError: string | undefined;
  lookupTable: LookupTable[];
  lookupTables: LookupTables

  financialStatementTypes: FinancialStatementTypes;
  typeList: ListControl[] = [];
  activeTemplateList: ListControl[] = [];
  finQualityList: ListControl[] = [];
  costMarketList: ListControl[] = [];
  table: LookupTable;
  customer: DcCustomer;
  comment: DcComment;
  errorDesc: ErrorDesc[];
  errorObj: ErrorObj[] = [];
  submitted: boolean;
  newEditBSForm: FormGroup;
  errorData: string[] = [];
  fControlName: string;
  bsConsolidationRequiredFields;
  showAstersk: any = { costOrMarket: false, financial: false, template: false }
  map = new Map<string, string>();
  selectedGroup;
  sdComment: DcComment;
  cnComment: DcComment;

  popupRef;
  copyPopUpRef;
  closeDailog: boolean;
  toggleLinkArrowStyle = '<span class=\'k-icon k-i-arrow-60-right pl-2\'></span>';
  toggleCopyArrowStyle = '<span class=\'k-icon k-i-arrow-60-right pl-2\'></span>';
  selectedItem;
  costMarketSelected = null;
  financialSelectedItem = null;
  activeTemplateSelected = null;
  formBody: any = {}

  formErrors: any = {}

  @ViewChild('copyEarningAnchor') public copyEarningAnchor: ElementRef;
  @ViewChild('bSWindowTitleBar', { static: true, read: TemplateRef }) public bSWindowTitleBar;
  @ViewChild(TooltipDirective) tooltip: TooltipDirective;
  @ViewChild('first') first: ElementRef;
  @ViewChild('second') second: ElementRef;
  @ViewChild('third') third: ElementRef;
  pageName: string;
  priorBSData: any;
  infoToolTip: string
  showDidYouKnow: any
  linkPopupInstance: any


  // eslint-disable-next-line no-useless-constructor
  constructor(private store: Store<AppState>, private kendoModalService: KendoModalService, private fb: FormBuilder,
    private restService: RestService, private utilService: UtilityService, private windowRef: WindowRef,
    private selectedCustomerService: SelectedCustomerService) { }

  ngOnInit(): void {
    this.checkBSMode(this.financialStatementBID)
    this.sumDescDelRoatated = false;
    this.createFormGroup()
    this.setWindowTitle()
    if (this.whichComponent === 'Consolidation BS') {
      setTimeout(() => this.fetchBsControlDetails(this.lookUps), 0)
    } else {
      this.getBSLookUps()
    }

  }

  get f() { return this.newEditBSForm.controls }

  setWindowTitle() {
    //  this.utilService.setTitle(this.bSWindowTitleBar);
    this.utilService.dialogStatus.subscribe((response) => {
      this.closeDailog = response
      if (this.closeDailog) { this.popupRef ? this.closeAdditionalPopup(this.popupRef) : this.closeAdditionalPopup(this.copyPopUpRef) }
    })
  }

  showDeletBtn(param: string) {
    if (param === 'CN') {
      this.cNDelRoatated = !this.cNDelRoatated
    } else {
      this.sumDescDelRoatated = !this.sumDescDelRoatated
    }
  }

  onDeletewindowopen() {

  }

  ngOnDestroy() {
  }

  getBSLookUps() {
    this.lookupTable = [{
      Action: DTOAction.Nothing,
      UserID: 0,
      TableCde: 49,
      TableName: 'tlkpFilteredFinancialStatementSubType',
      EmptyOK: false
    },
    {
      Action: DTOAction.Nothing,
      UserID: 0,
      TableCde: 21,
      TableName: 'tlkpFinancialStatementTemplate',
      EmptyOK: false
    }, {
      Action: DTOAction.Nothing,
      UserID: 0,
      TableCde: 28,
      TableName: 'tlkpFinancialDataSourceType',
      EmptyOK: false
    }, {
      Action: DTOAction.Nothing,
      UserID: 0,
      TableCde: 30,
      TableName: 'tslkpCostOrMarketType',
      EmptyOK: false
    }
    ]

    this.lookupTables = {
      lookupTables: this.lookupTable
    }
    this.restService.post(environment.commonBaseURI + environment.endpoints.commonBaseURLPrefix + environment.endpoints.adminOptionsGetUserClaimsURL, this.lookupTables)
      .subscribe(
        result => {
          this.balanceSheetLookUp = result.GetLookupsResult
          this.fetchBsControlDetails(this.balanceSheetLookUp)
          this.updateFormControl();
        }
      )
  }

  updateFormControl() {
    this.newEditBSForm.patchValue({
      type: this.selectedItem
    })
  }

  deleteSDComment() {
    this.comment = null;
    this.sdComment = null;
    this.showSumDescIcon = false;
    this.sumDescDelRoatated = false;
    this.deleteComments(this.summaryDescId, 'SD');
  }

  deleteCNComment() {
    this.cnComment = null;
    this.showCNIcon = false
    this.cNDelRoatated = false
  }

  createFormGroup() {
    let group = {
      description: ['', Validators.compose([Validators.required, Validators.maxLength(100)])],
      date: [this.value, Validators.compose([Validators.required, DateValidator.dateValidator])],
      type: [this.selectedItem, Validators.required],
      financial: ['', Validators.required],
      costOrMarket: ['', Validators.required],
      template: ['', Validators.required],
      spouseStmt: true,
      collateral: false
    }
    for (let i in this.hideElement) {
      Object.keys(group).forEach(it => {
        if (i.includes(it) && this.hideElement[i]) {
          delete group[it]
        }
      })
    }
    this.newEditBSForm = this.fb.group(group)
    this.validationRequiements()
  }

  validationRequiements() {
    const params = {
      applicationCde: 5,
      applicationViewCde: 5,
      customChartOfAccountCde: null
    }
    // const consolidationRequired = []
    this.restService.post(environment.commonBaseURI + environment.endpoints.retAppViewRequirements, params)
      .subscribe(
        result => {
          this.errorDesc = result.RetrieveApplicationViewRequirementsResult.ApplicationViewDictionaryObjectRequirements
          // if (this.whichComponent === 'Consolidation BS') {
          //   this.bsConsolidationRequiredFields?.length && this.bsConsolidationRequiredFields.forEach(it => {
          //     this.errorDesc.forEach(error => {
          //       if(it === error.DictionaryObjectCde) {
          //         consolidationRequired.push(error)
          //       }
          //     })
          //   })
          // } 
          this.showAstersk = {}
          this.errorDesc.forEach(it => {
            if (it.DictionaryObjectDesc?.toLowerCase().includes('cost')) this.showAstersk.costOrMarket = true;
            else if (it.DictionaryObjectDesc?.toLowerCase().includes('financial')) this.showAstersk.financial = true;
            else if (it.DictionaryObjectDesc?.toLowerCase().includes('template')) this.showAstersk.template = true;
          })

          Object.keys(this.newEditBSForm.controls).forEach((key) => {
            this.errorDesc.forEach(it => {
              if (it?.DictionaryObjectDesc?.toLowerCase().includes(key.toLowerCase())) {
                this.map.set(key, it.DictionaryObjectDesc)
              }
            })
          })
        }
      )
  }

  checkBSMode(fStatementBID: number) {
    // this.OpenMode = fStatementBID ? ModalOpenMode.Open : ModalOpenMode.Create;
    this.OpenMode = 0
    // const titleText = this.OpenMode == ModalOpenMode.Create ? 'Create New Balance Sheet' : 'Edit Balance Sheet'

    if (this.OpenMode === ModalOpenMode.Create) {
      this.restService.get('./assets/json/CustomerBIDResult.json')
        .subscribe(
          result => {
            this.customer = result.RetrieveCustomerByCustomerBIDResult
            // const ModalTitle = titleText + ' - ' + this.customer.CustomerName
          }
        )
    }
    // BalanceSheetDate = (callback.Result.FinancialStatementBID.HasValue ? callback.Result.FinancialStatementEndDte.Value : defaultBalanceSheetDate);
    // this.value.setDate(0)

    // to set the last day of previous month
    this.value.setDate(1);
    this.value.setHours(-1);
    // let ModalTitle = titleText + " - " + (HeaderType == (int)FinancialStatementSubTypes.BalanceSheetConsolidation ? "Consolidation" : customerName);
  }

  openComentEditor(e, category: string) {
    let actionCde: number;
    let commentBID: number;
    if (this.whichComponent === "Consolidation BS") {
      if (category === 'SD') {
        actionCde = (this.summaryDescId === undefined || this.summaryDescId === null) ? DTOAction.Insert : DTOAction.Update;
        commentBID = this.summaryDescId;
      }
      if (commentBID != null || commentBID === undefined) {
        this.store.dispatch(commentsActions.initialCommentsDataLoad({
          commentBID: commentBID
        }));
      }
    }

    const dialog: any = this.kendoModalService.open('window', 'commentEditor', CommentEditor);
    if (this.whichComponent === 'Balance Sheet') {
      if (category === 'SD' && this.sdComment && this.sdComment.Comment) {
        dialog.content.instance.value = this.sdComment.Comment;
      }
      else if (category === 'CN' && this.cnComment && this.cnComment.Comment) {
        dialog.content.instance.value = this.cnComment.Comment;
      }
    }

    dialog.result.subscribe((response) => {
      if (response.action === 'OK') {
        const str = response.comment;
        const strippedText = str.replace(/(<([^>]+)>)/ig, "");

        if (this.whichComponent === 'Consolidation BS') {
          this.comment = {
            Action: actionCde,
            Comment: response.comment,
            CommentBID: commentBID,
            CommentPlainTxt: strippedText,
            UserID: 1997
          }

          this.store.dispatch(commentsActions.commentsDataSave({
            comment: this.comment
          }));

          this.saveComment(category, response);
        }
        else {
          if (category === 'SD') {
            this.sdComment = {
              Action: actionCde,
              Comment: response.comment,
              CommentBID: commentBID,
              CommentPlainTxt: strippedText,
              UserID: 1997
            }

            this.showSumDescIcon = true;
          }
          else {
            this.cnComment = {
              Action: actionCde,
              Comment: response.comment,
              CommentBID: commentBID,
              CommentPlainTxt: strippedText,
              UserID: 1997
            }

            this.showCNIcon = true;
          }

        }


      }
    })
  }

  saveComment(category, response: any) {
    this.pageName = 'BS'
    this.store.pipe(select(commentsSelector))
      .subscribe(data => {
        if (this.pageName === 'BS' && (data?.type === commentsActions.COMMENTS_SAVE_DATA || data?.type === commentsActions.COMMENTS_UPDATE_DATA)) {
          if (category === 'SD') {
            this.showSumDescIcon = true;
            this.summaryDescId = data?.SaveCommentResult;
          } else {
            this.showCNIcon = true;
          }
        }
      });

  }

  fetchBsControlDetails(lookUpDetails: BalanceSheetLookUp[]) {
    lookUpDetails.forEach((element) => {
      this.fillBsControls(element)
    })
    this.activeTemplateList = this.activeTemplateList.sort((a, b) => (a.text < b.text ? -1 : 1))
  }

  fillBsControls(bs: BalanceSheetLookUp) {
    const statementType = this.whichComponent == 'Consolidation BS' ? FinancialStatementSubTypes.BalanceSheetConsolidation : FinancialStatementTypes.BalanceSheet
    switch (bs.Table.TableName != '') {
      case (bs.Table.TableCde === CachedLookups.tlkpFilteredFinancialStatementSubType): {
        const list = bs.LookupData.find(x => x.Cde === Number(statementType))
        this.typeList.push(new ListControl(list.Desc, list.Cde))
        this.selectedItem = list.Cde
        this.formBody.type = { text: list.Desc, value: list.Cde }
        this.updateFormControl()
        break
      }

      case (bs.Table.TableCde === Number(CachedLookups.tlkpFinancialStatementTemplate)): {
        bs.LookupData.forEach((element, index) => {
          if (element.ExtendedValues.find(x => x.Value === statementType.toString())) {
            this.activeTemplateList.push(new ListControl(element.Desc, element.Cde))
          }
        })
        break
      }

      case (bs.Table.TableCde === Number(CachedLookups.tlkpFinancialDataSourceType)): {
        bs.LookupData.forEach((element) => {
          this.finQualityList.push(new ListControl(element.Desc, element.Cde))
        })
        break
      }

      case (bs.Table.TableCde === Number(CachedLookups.tslkpCostOrMarketType)): {
        bs.LookupData.forEach((element) => {
          this.costMarketList.push(new ListControl(element.Desc, element.Cde))
        })
        break
      }

      default:
        break
    }
  }

  close() {
    this.opened = false
  }

  open() {
    this.opened = true
  }

  validateControl(params: any) {
    if (params.control == 'date') {
      if (params.response === true || params.date != 'month/day/year') {
        // this.selectedItem = params.control == 'type' ? null : this.selectedItem
        // this.value = params.control == 'date' ? params.date : this.value
        this.fControlName = params.control
        this.formBody[params.control] = params.date
        const fControldesc = this.map.get(params.control)
        this.setErrorDesc(params.control, fControldesc, params.response)
        // this.fControlError ? this.tooltip.show(this.second) : '';
        this.showErrors(this.fControlName)
      } else {
        this.fControlError = ''
        this.tooltip?.hide()
        this.resetFormErrors()
      }
    } else {
      if (params.response === true) {
        this.selectedItem = params.control == 'type' ? null : this.selectedItem
        this.fControlName = params.control
        this.formBody[params.control] = params.value
        const fControldesc = this.map.get(params.control)
        this.setErrorDesc(params.control, fControldesc, params.response)
        // this.fControlError ? this.tooltip.show(this.second) : '';
        this.showErrors(this.fControlName)
      } else {
        this.formBody[params.control] = params.value
        this.fControlError = ''
        this.tooltip?.hide()
        this.resetFormErrors()
      }
    }
  }

  validateAll() {
    this.errorObj.length = 0
    Object.keys(this.newEditBSForm.controls).forEach((key) => {
      this.errorDesc.forEach(it => {
        if (it?.DictionaryObjectDesc?.toLowerCase().includes(key.toLowerCase())) {
          this.setErrorDesc(key, it.DictionaryObjectDesc)
        }
      })
    })
  }

  resetFormErrors() {
    if (Object.keys(this.formErrors)?.length) {
      for (let i in this.formErrors) {
        this.formErrors[i]['show'] = false
      }
    }
  }

  showErrorOnClick(control) {
    this.resetFormErrors()
    if (this.formErrors[control])
      this.formErrors[control]['show'] = this.formErrors[control]['error'] ? true : false
  }

  setErrorDesc(control: any, desc: string, fControlValue?: boolean) {
    let _errorObj

    if (control == 'date') {
      this.dateErrors(control, desc, fControlValue, _errorObj);
    } else {
      if (this.newEditBSForm.controls[control].hasError('required') || fControlValue) {

        this.map.get(control) ? _errorObj = {
          key: this.map.get(control),
          value: `${desc} is required for: ${this.errorDesc[0].RequiredFieldTypeDesc}.`
        } : null
        this.setFormErrors(fControlValue, _errorObj, control)

      } else if (this.newEditBSForm.controls[control].hasError('maxlength') && this.map.get(control)) {
        _errorObj = {
          key: this.map.get(control),
          value: `${desc} must be : 1-${this.newEditBSForm.controls[control].errors.maxlength.requiredLength} character(s) long.`
        }
        this.errorObj.push(_errorObj)
      }
    }

  }

  dateErrors(control, desc, fControlValue, _errorObj) {
    let dateDesc = '';
    // console.log(this.newEditBSForm.controls[control].value, this.newEditBSForm.controls[control].value.getFullYear())
    this.resetFormErrors()
    if (this.newEditBSForm.controls[control].value === 'month/day/year') {
      dateDesc = `${desc} is required for: ${this.errorDesc[0].RequiredFieldTypeDesc}.`
    } else if (this.newEditBSForm.controls[control].value && this.newEditBSForm.controls[control].value.toString().includes('year')) {
      dateDesc = `${desc} is not in the correct format. The correct format is: Date (e.g. "02/02/1993")`
      this.fControlError = dateDesc
    }
    else {
      fControlValue = true
      if (this.newEditBSForm.controls[control].value) {
        let currentDateYear = new Date().getFullYear().toString().substr(0, 2)
        let selectedDate = this.newEditBSForm.controls[control].value
        if (selectedDate.getFullYear().toString().length >= 3) {
          if (selectedDate.getFullYear() < 1900 || selectedDate.getFullYear() > 2100) {
            dateDesc = `${desc} must be between 1900 and 2100.`
          }
        } else {
          let updatedDateYear;
          if (selectedDate.getFullYear().toString().length == 1) {
            updatedDateYear = currentDateYear + `0${selectedDate.getFullYear().toString()}`
          } else {
            updatedDateYear = currentDateYear + `${selectedDate.getFullYear().toString()}`
          }
          let updatedDate = new Date(updatedDateYear, selectedDate.getMonth(), selectedDate.getDate())
          this.updateDateInForm(updatedDate)
        }
      }
      // if()
    }
    if (dateDesc) {
      this.map.get(control) ? _errorObj = {
        key: this.map.get(control),
        value: dateDesc
      } : null
      this.setFormErrors(fControlValue, _errorObj, control)
    }

  }

  updateDateInForm(updatedDate) {
    this.value = updatedDate
    this.newEditBSForm.patchValue({
      date: updatedDate
    })
    this.resetFormErrors()
  }

  setFormErrors(fControlValue, _errorObj, control) {
    if (fControlValue) {
      this.resetFormErrors()
      this.fControlError = _errorObj.value
      this.formErrors[control] = {}
      this.formErrors[control].show = true
      this.formErrors[control].error = _errorObj.value

    } else this.errorObj.push(_errorObj)
  }

  labelChange(e) {
    let _errorObj;
    if (this.newEditBSForm.controls['description'].hasError('required')) {
      this.map.get('description') ? _errorObj = {
        key: this.map.get('description'),
        value: `Balance Sheet Description is required for: ${this.errorDesc[0].RequiredFieldTypeDesc}.`
      } : null

      this.resetFormErrors()
      this.fControlError = _errorObj.value
      this.formErrors['description'] = {}
      this.formErrors['description'].show = true
      this.formErrors['description'].error = _errorObj.value

    }
  }

  showErrors(error) {
    this.tooltip?.hide()

    switch (error != '') {
      case error === 'date':
        // this.tooltip.show(this.first)
        break
      case error === 'type':
        // this.tooltip.show(this.second)
        break
      case error === 'template':
        // this.tooltip.show(this.third)
        break

      default:
        break
    }
  }

  submit(event?) {
    this.submitted = true
    this.tooltip?.hide()
    this.resetFormErrors()
    this.validateAll()
    if (this.newEditBSForm.invalid) {
      return
    }
    /// const dialog: any = this.kendoModalService.open('window', 'OK', EarningCopyStatementPopupComponent)

    this.dataSaved = true
    if (this.errorObj?.length) {
      return
    }
    console.log(this.linkPopupInstance)
    let body = {
      "financialSheetHeader": {
        "Action": DTOAction.Insert,
        "UserID": 1997,
        "CustomerBID": this.selectedCustomerService.getCurrentSelectedCustomer2().customerId,
        "FinancialStatementSubTypeCde": FinancialStatementSubTypes.BalanceSheetConsolidation,
        "FinancialStatementEndDte": `/Date(${moment(this.formBody.date).format('xZZ')})/`,
        "FinancialStatementStartDte": `/Date(${moment(this.formBody.date).format('xZZ')})/`,
        "FinancialStatementTemplateCde": 1, // master template
        "FinancialStatementDesc": this.newEditBSForm.value.description,
        "CommentBID": this.summaryDescId || null,
        "FinancialDataSourceTypeCde": this.formBody.financial.value,
        "CostOrMarketTypeCde": this.formBody.costOrMarket.value,
        
        "DefaultBenchmarkID": this.linkPopupInstance?.selectedBenchmarkData?.parantid,
        "DefaultBenchmarkStatementBID": this.linkPopupInstance?.selectedBenchmarkData?.id,
        "CombinedStatementWithSpouseInd": false,
        "CollateralStatementInd": false,
        "PriorBSForENWChangeFinancialStatementBID": this.linkPopupInstance?.selectedPriorBSForENW?.FinancialStatementBID
      }
    }

    
    this.restService.post(environment.baseURI + environment.endpoints.baseURLPrefix + environment.endpoints.saveConsolidation, body)
      .subscribe(res => {
        if (res.SaveConsolidationResult) {
          let statementJoinBody = {
            "records": [
              {
                "GroupBID": this.selectedGroup.GroupBID,
                "FinancialStatementBID": res.SaveConsolidationResult,
                "Action": DTOAction.Insert,
                "UserID": 1997
              }
            ]
          }
          this.restService.post(environment.baseURI + environment.endpoints.baseURLPrefix + environment.endpoints.saveStatementJoin, statementJoinBody)
          .subscribe(res => {
            this.kendoModalService.close('window', this.windowRef)
          }, err => {
            console.log(err)
          })
        }
      }, err => {
        console.log(err)
      })
    // this.close()
  }

  closePopUp() {
    this.popupRef ? this.closeAdditionalPopup(this.popupRef) : this.closeAdditionalPopup(this.copyPopUpRef)
    this.popupRef = null
    this.copyPopUpRef = null
    this.windowRef.close();
    this.deleteSDComment();
  }

  copyEarningForm(copyEarningAnchor: ElementRef) {
    this.tooltip?.hide()
    this.resetFormErrors()
    if (this.copyPopUpRef) {
      this.closeAdditionalPopup(this.copyPopUpRef)
      this.copyPopUpRef = null
    } else {
      this.closeAdditionalPopup(this.popupRef)
      this.popupRef = null
      let bsConsolidationClass;
      let component;
      if (this.whichComponent.includes('Consolidation')) {
        component = BsConsolidationCopyComponent
        bsConsolidationClass = 'bsConsolidationClass'
      } else
        component = BalancesheetCopyStatementPopupComponent
      this.copyPopUpRef = this.kendoModalService.open('popup', 'copyEarningForm', component, {
        anchor: copyEarningAnchor,
        anchorAlign: { horizontal: 'right', vertical: 'top' },
        popupAlign: { horizontal: 'left', vertical: 'top' },
        popupClass: '' + bsConsolidationClass
      })
      let instance = this.copyPopUpRef.content.instance
      instance.selectedGroup = this.selectedGroup
      this.toggleCopyArrowStyle = '<span class=\'k-icon k-i-arrow-60-left pl-2\'></span>'

      instance.onFinancialSelected && instance.onFinancialSelected.subscribe(val => {
        this.updateBSForm(val);
      });
    }
  }

  updateBSForm(val) {
    this.costMarketSelected = val.CostOrMarketTypeCde;
    this.financialSelectedItem = val.FinancialDataSourceTypeCde;
    this.activeTemplateSelected = val.FinancialStatementTemplateCde;
    const updatedDate = this.modifyDate(val.FinancialStatementStartDte);
    this.value = updatedDate;
    this.newEditBSForm.patchValue({
      date: updatedDate,
      spouseStmt: val.CombinedStatementWithSpouseInd,
      collateral: val.CollateralStatementInd
    });
  }

  modifyDate(date) {
    const filterPipe = new DateTransformPipe();
    const d = new Date(filterPipe.transform(date, 'MM/DD/yyyy'));
    return new Date(d.getFullYear() + 1, d.getMonth(), d.getDate());
  }

  togglePopup(newBalanceSheetAnchor) {
    this.tooltip?.hide()
    this.resetFormErrors()
    const params = {

      anchor: newBalanceSheetAnchor,
      anchorAlign: {
        horizontal: 'right', vertical: 'top'
      },
      popupAlign: {
        horizontal: 'left', vertical: 'top', padding: '50px'
      },
      popupClass: 'link-popup'
    }

    if (this.popupRef) {
      this.closeAdditionalPopup(this.popupRef)
      this.popupRef = null
    } else {
      this.closeAdditionalPopup(this.copyPopUpRef)
      this.copyPopUpRef = null
      this.popupRef = this.kendoModalService.open('popup',
        'balanceSheetNewLinkForm',
        BalanceSheetHeaderLinkComponent,
        params)
      this.linkPopupInstance = this.popupRef.content.instance
      this.linkPopupInstance.whichComponent = this.whichComponent;
      this.toggleLinkArrowStyle = '<span class=\'k-icon k-i-arrow-60-left pl-2\'></span>'
      if (this.whichComponent?.includes('Consolidation')) {
        this.linkPopupInstance.priorBSForENW = this.priorBSData
      }
    }
  }

  toggleLink(newBalanceSheetAnchor: ElementRef) {
    if (this.whichComponent?.includes('Consolidation')) {
      this.loadPriorBSData(newBalanceSheetAnchor)
    } else {
      this.togglePopup(newBalanceSheetAnchor)

    }
  }

  closeAdditionalPopup(refPopUp: any) {
    if (refPopUp) {
      this.kendoModalService.close('popup', refPopUp)
      this.toggleLinkArrowStyle = '<span class=\'k-icon k-i-arrow-60-right pl-2\'></span>'
      this.toggleCopyArrowStyle = '<span class=\'k-icon k-i-arrow-60-right pl-2\'></span>'
    }
  }

  /**
   * Delete the comments on the bais of selected category 
   * @param commentBID
   * @param category
   */
  deleteComments(commentBID: number, category: string): void {
    const params = [{ Action: DTOAction.Delete, UserID: 1997, CommentBID: commentBID }];
    this.store.dispatch(commentsActions.commentsDataDelete({
      comments: params
    }));
    this.comment = null;
    if (category === 'SD') {
      this.summaryDescId = null;
    }
  }

  loadPriorBSData(elem) {
    let paramsData: any = {
      "customerBID": this.selectedCustomerService.getCurrentSelectedCustomer2().customerId,
      "financialStatementBID": null,
      "groupBID": this.selectedGroup.GroupBID
    };
    let balanceSheetHeaderById: Observable<any> = this.restService.post(environment.baseURI + AppConstant.endpoints.retrieveBalanceSheetHeaderByID, paramsData);

    paramsData = {
      "customerBID": this.selectedCustomerService.getCurrentSelectedCustomer2().customerId,
      "includeBS": true,
      "includeES": false,
      "includeActiveGroupsOnly": false
    };
    let consolidationStatementHeader: Observable<any> = this.restService.post(environment.baseURI + AppConstant.endpoints.retrieveCustomerConsolidationFinancialStatement, paramsData);




    forkJoin([balanceSheetHeaderById, consolidationStatementHeader]).subscribe((data: any[]) => {
      if (data && data.length) {
        let bsHeader = []
        let consolidationHeader = []
        data.forEach(d => {
          if (d.RetrieveBalanceSheetHeaderByIDResult?.AvailableBalanceSheetHeaders && d.RetrieveBalanceSheetHeaderByIDResult?.AvailableBalanceSheetHeaders.length) {
            bsHeader = d.RetrieveBalanceSheetHeaderByIDResult.AvailableBalanceSheetHeaders.filter(it => {
              return (new Date(moment.utc(it.FinancialStatementEndDte).format()) < new Date(this.value) && it.FinancialStatementSubTypeCde === FinancialStatementSubTypes.BalanceSheetConsolidation)
            })
          }
          if (d.RetrieveCustomerConsolidationFinancialStatementHeadersResult?.length) {
            d.RetrieveCustomerConsolidationFinancialStatementHeadersResult.forEach(cs => {
              if (cs.FinancialStatements?.length) {
                consolidationHeader = [...consolidationHeader, ...cs.FinancialStatements.filter(it => {
                  return it.FinancialStatementSubTypeCde === FinancialStatementSubTypes.BalanceSheetConsolidation
                })]
              }
            })
          }
        })
        this.priorBSData = [...bsHeader, ...consolidationHeader]
        this.priorBSData = uniqBy(this.priorBSData, 'FinancialStatementBID').reverse()
        let bSHeaderPriorBS: any =
        {
          FinancialStatementBID: 0,
          CustomerBID: 0,
          FinancialStatementEndDte: '',
          FinancialStatementDesc: '',
          FinancialStatementStartDte: '',
          FinancialStatementSubTypeCde: 0,
          FinancialStatementTemplateCde: 0,
          IsDefault: true
        }
        this.priorBSData.unshift(bSHeaderPriorBS);
        this.togglePopup(elem)
      }
      // data && data.length && data[0].RetrieveBalanceSheetHeaderByIDResult?.AvailableBalanceSheetHeaders
    })
  }

  showDidYouKnowTooltip(checked) {
    if (this.infoToolTip === 'none') return
    if (checked) this.infoToolTip = 'hover'
    this.showDidYouKnow = checked
  }

  hideToolTip() {
    this.tooltipDir.hide();
    this.infoToolTip = 'hover';
    this.showDidYouKnow = false;
  }

}
