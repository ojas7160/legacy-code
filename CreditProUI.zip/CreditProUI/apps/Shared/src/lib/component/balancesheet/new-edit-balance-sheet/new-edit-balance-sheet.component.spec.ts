import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewEditBalanceSheetComponent } from './new-edit-balance-sheet.component';

describe('NewEditBalanceSheetComponent', () => {
  let component: NewEditBalanceSheetComponent;
  let fixture: ComponentFixture<NewEditBalanceSheetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewEditBalanceSheetComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NewEditBalanceSheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
