/* eslint-disable no-unused-vars */
import { Component, OnInit, OnDestroy, Output,EventEmitter } from '@angular/core';
import { Align, Offset } from '@progress/kendo-angular-popup';
import { ShareStatementDataService } from '../../../services/earnings/shareStatementDataService';
import { CustomerSearchResult } from '../../../models/customer-search-result.model';
import { environment } from 'apps/CreditPro/src/environments/environment';

@Component({
  selector: 'uc-balancesheet-copy-statement-popup',
  templateUrl: './balancesheet-copy-statement-popup.component.html',
  styleUrls: ['./balancesheet-copy-statement-popup.component.scss']
})

export class BalancesheetCopyStatementPopupComponent implements OnInit, OnDestroy {
  public headerContent = "Create New by Copying From:";
  public dialogOpened = false;
  public offset: Offset = { left: 100, top: 250 };
  public popupAlign: Align = { horizontal: "center", vertical: "center" };
  parameterList: any[];
  customerHeadersearchList: CustomerSearchResult = {};
  public currentSelectedCustomerId

  currentCustomer = true;
  customerHeading = 'Customer:';
  financialHeading = 'Financial Statements:';
  customerHeadingCSS = 'font-weight-bold mt-2';
  financialHeadingCSS = 'font-weight-bold mt-2';
  statementName = 'earning Sheet';
  apiUrl = environment.endpoints.retrieveBalanceSheet;
  apiUrlJsonKey = 'RetrieveBalanceSheetHeadersByCustomerBIDResult';
  imgSrc = 'assets/app-icons-imgs/Earnings_icon.jpg';
  selectedCustomer: any;
  disableparameterList = false;
  isActiveStartDate = true;
  
  @Output() onFinancialSelected = new EventEmitter();

  rmDisabled: boolean = false;

  constructor(private dataservice: ShareStatementDataService) {
    
  }
  
  getSelectedCustomerData(event) {
    this.selectedCustomer = event;
  }

  getSelectedFinancialData(event) {
    this.onFinancialSelected.emit(event);
  }

  ngOnInit(): void {
  }

  clearAll() {
    this.rmDisabled = false;
    this.dataservice.setProfileObs(null);
  }

  ngOnDestroy () { }
}
