/* eslint-disable no-unused-vars */
import { Component, OnInit, ViewChild, ElementRef, Input, ViewEncapsulation, TemplateRef, OnDestroy } from '@angular/core'
import { KendoModalService, RestService, SelectedCustomerService } from '../../../services'
import { BalanceSheetLookUp } from '../../../models/balanceSheetLookUp'
import { FinancialStatementTypes } from '../../../enum/financialStatementTypes'
import { CachedLookups } from '../../../enum/cachedLookups'
import { LookupTable, LookupTables } from '../../../models/LookupTables'
import { ListControl } from '../../../models/listControl'
import { FormBuilder, FormGroup, Validators } from '@angular/forms'
import { DcCustomer } from '../../../models/customer'
import { ModalOpenMode } from '../../../enum/modelOpen'
import { CommentEditor } from '../../common/comments-editor/comments-editor.component'
import { DcComment } from '../../../models/comment'
import { DateValidator } from '../../../customValiadtions/dateValidation'
import { ErrorDesc, ErrorObj } from '../../../models/errorDescription'
import { BalanceSheetHeaderLinkComponent } from '../balance-sheet2/balance-sheet-header-link/balance-sheet-header-link.component'
import { environment } from 'apps/CreditPro/src/environments/environment'
import { DTOAction } from '../../../enum'
import { UtilityService } from '../../../services/utility/utility.service'
import { WindowCloseResult, WindowRef } from '@progress/kendo-angular-dialog'
import { TooltipDirective } from '@progress/kendo-angular-tooltip'
import { FinancialStatementSubTypes } from '../../../enum/financialStatementSubTypes'
import * as commentsActions from '../../../store/actions/comments.action';
import { AppState } from '../../../store'
import { select, Store } from '@ngrx/store'
import { commentsSelector } from '../../../store/selectors/comments.selector'
import { forkJoin, Observable, Subscription } from 'rxjs'
import { AppConstant } from '../../../constants/app-constants'
import * as moment from 'moment'
import { uniqBy } from 'lodash';
import { BsConsolidationCopyComponent } from '../../consolidations/bs-consolidation-copy/bs-consolidation-copy.component'
import { BalancesheetCopyStatementPopupComponent } from '../balancesheet-copy-statement-popup/balancesheet-copy-statement-popup.component'
import { DateTransformPipe } from '../../../pipes/dateTransform.pipe'
import { EarningCopyStatementPopupComponent } from '../../earning-copy-statement-popup/earning-copy-statement-popup.component'
import { ShareStatementDataService } from '../../../services/earnings/shareStatementDataService'

@Component({
  selector: 'uc-new-projected-bs',
  templateUrl: './new-projected-bs.component.html',
  styleUrls: ['./new-projected-bs.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class NewProjectedBSComponent implements OnInit {
  /* #region Declaration */
  @Input() financialStatementBID: number;
  @Input() page: string;

  @Input() whichComponent = 'Balance Sheet'
  @Input() hideElement: any = {}
  @ViewChild(TooltipDirective) public tooltipDir: TooltipDirective;
  lookUps: any;
  summaryDescId: number;
  cnDescId: number;
  title = 'FPI';
  opened = true;
  closed = false;
  dataSaved = false;
  isShown = false;
  balanceSheetLookUp: BalanceSheetLookUp[];
  value: Date = new Date();
  OpenMode: number;
  showSumDescIcon: boolean;
  showCNIcon: boolean;
  cNDelRoatated = false;
  sumDescDelRoatated = false;
  showAdditionalInfo = false;

  fControlError: string | undefined;
  lookupTable: LookupTable[];
  lookupTables: LookupTables

  financialStatementTypes: FinancialStatementTypes;
  typeList: ListControl[] = [];
  activeTemplateList: ListControl[] = [];
  finQualityList: ListControl[] = [];
  costMarketList: ListControl[] = [];
  table: LookupTable;
  customer: DcCustomer;
  comment: DcComment;
  errorDesc: ErrorDesc[];
  errorObj: ErrorObj[] = [];
  submitted: boolean;
  newEditBSForm: FormGroup;
  errorData: string[] = [];
  fControlName: string;
  bsConsolidationRequiredFields;
  showAstersk: any = { costOrMarket: false, financial: false, template: false }
  map = new Map<string, string>();
  selectedGroup;
  sdComment: DcComment;
  cnComment: DcComment;

  popupRef;
  copyPopUpRef;
  closeDailog: boolean;
  toggleLinkArrowStyle = '<span class=\'k-icon k-i-arrow-60-right pl-2\'></span>';
  toggleCopyArrowStyle = '<span class=\'k-icon k-i-arrow-60-right pl-2\'></span>';
  selectedItem;
  costMarketSelected = null;
  financialSelectedItem = null;
  activeTemplateSelected = null;

  formErrors: any = {}

  @ViewChild('copyEarningAnchor') public copyEarningAnchor: ElementRef;
  @ViewChild('bSWindowTitleBar', { static: true, read: TemplateRef }) public bSWindowTitleBar;
  @ViewChild(TooltipDirective) tooltip: TooltipDirective;
  @ViewChild('first') first: ElementRef;
  @ViewChild('second') second: ElementRef;
  @ViewChild('third') third: ElementRef;
  pageName: string;
  priorBSData: any;
  infoToolTip: string
  showDidYouKnow: any
  projectedDataSub: Subscription;
  /* #endregion */
  public customerID = this.selectedCustomerService.getCurrentSelectedCustomer2();
  projectedstatement: any
  public startDate: Date;
  public endDate: Date;
  earninglable: string = '';
  selectedSourceData;
  selectedFinanceQuality;
  selectedActiveTemplate;
  selectedOpeningBS;
  selectedClosingBs
  newEditProjectedForm: FormGroup;
  selectedType: any
  public selectedProjectedOpeningBSData: any;
  public selectedProjectedClosingOpeningBSData: any;
  // eslint-disable-next-line no-useless-constructor
  constructor(private dataservice: ShareStatementDataService, private utiltyService: UtilityService, private store: Store<AppState>, private kendoModalService: KendoModalService, private fb: FormBuilder,
    private restService: RestService, private utilService: UtilityService, private windowRef: WindowRef,
    private selectedCustomerService: SelectedCustomerService) {
  }

  ngOnInit(): void {
    this.checkBSMode(this.financialStatementBID)
    this.sumDescDelRoatated = false;
    this.createFormGroup()
    this.setWindowTitle()
    this.copyStatement();
    if (this.whichComponent === 'Consolidation BS') {
      setTimeout(() => this.fetchBsControlDetails(this.lookUps), 0)
    } else {
      this.getBSLookUps()
    }

  }

  get f() { return this.newEditBSForm.controls }

  setWindowTitle() {
    this.utilService.dialogStatus.subscribe((response) => {
      this.closeDailog = response
      if (this.closeDailog) { this.popupRef ? this.closeAdditionalPopup(this.popupRef) : this.closeAdditionalPopup(this.copyPopUpRef) }
    })
  }

  showDeletBtn(param: string) {
    if (param === 'CN') {
      this.cNDelRoatated = !this.cNDelRoatated
    } else {
      this.sumDescDelRoatated = !this.sumDescDelRoatated
    }
  }

  copyStatement() {
    this.projectedDataSub = this.dataservice.getProfileObs().subscribe(projectedstatement => {
      this.projectedstatement = projectedstatement;
      if (this.projectedstatement) {              
        const filterPipe = new DateTransformPipe();
        this.endDate = new Date(filterPipe.transform(this.projectedstatement.FinancialStatementEndDte, AppConstant.dateFormat));
        this.endDate.setFullYear(this.endDate.getFullYear() + 1);
        this.selectedSourceData = this.projectedstatement.FinancialSourceTypeCde;
        this.selectedFinanceQuality = this.projectedstatement.FinancialQualityCde;
        this.selectedActiveTemplate = this.projectedstatement.FinancialStatementTemplateCde;
        
      }
    });
  }

  setProjectedValues(): void {
    if (this.projectedstatement != null) {
      const filterPipe = new DateTransformPipe();
      this.startDate = new Date(filterPipe.transform(this.projectedstatement.FinancialStatementStartDte, AppConstant.dateFormat));
      this.endDate = new Date(filterPipe.transform(this.projectedstatement.FinancialStatementEndDte, AppConstant.dateFormat));
      this.newEditProjectedForm.setValue({
        sourceData: this.projectedstatement?.FinancialSourceTypeCdeField,
        labelValue: this.projectedstatement?.FinancialStatementDescField,
        endDate: this.endDate,
        startDate: this.startDate,
        type: this.projectedstatement?.FinancialStatementSubTypeCdeField,
        activeTemplate: this.projectedstatement?.FinancialStatementTemplateCdeField,
        combStat: this.projectedstatement?.CombinedStatementWithSpouseIndField,
        finQty: this.projectedstatement?.FinancialQualityCdeField,
        earingsopeningBSData: this.projectedstatement?.OpeningBSFinancialStatementBIDField,
        earingsclosingBSData: this.projectedstatement?.ClosingBSFinancialStatementBIDField
      });
    }
  }

  onDeletewindowopen() {

  }

  getBSLookUps() {
    this.lookupTable = [{
      Action: DTOAction.Nothing,
      UserID: 0,
      TableCde: 49,
      TableName: 'tlkpFilteredFinancialStatementSubType',
      EmptyOK: false
    },
    {
      Action: DTOAction.Nothing,
      UserID: 0,
      TableCde: 21,
      TableName: 'tlkpFinancialStatementTemplate',
      EmptyOK: false
    }, {
      Action: DTOAction.Nothing,
      UserID: 0,
      TableCde: 28,
      TableName: 'tlkpFinancialDataSourceType',
      EmptyOK: false
    }, {
      Action: DTOAction.Nothing,
      UserID: 0,
      TableCde: 30,
      TableName: 'tslkpCostOrMarketType',
      EmptyOK: false
    }
    ]

    this.lookupTables = {
      lookupTables: this.lookupTable
    }
    this.restService.post(environment.commonBaseURI + environment.endpoints.commonBaseURLPrefix + environment.endpoints.adminOptionsGetUserClaimsURL, this.lookupTables)
      .subscribe(
        result => {
          this.balanceSheetLookUp = result.GetLookupsResult
          this.fetchBsControlDetails(this.balanceSheetLookUp)
        }
      )
  }


  deleteSDComment() {
    this.comment = null;
    this.sdComment = null;
    this.showSumDescIcon = false;
    this.sumDescDelRoatated = false;
    this.deleteComments(this.summaryDescId, 'SD');

  }

  deleteCNComment() {
    this.cnComment = null;
    this.showCNIcon = false
    this.cNDelRoatated = false
    this.deleteComments(this.cnDescId, 'CN');
  }

  createFormGroup() {
    let group = {
      description: ['', Validators.compose([Validators.required, Validators.maxLength(100)])],
      date: [this.value, Validators.compose([Validators.required, DateValidator.dateValidator])],
      type: ['', Validators.required],
      financial: ['', Validators.required],
      costOrMarket: ['', Validators.required],
      template: ['', Validators.required],
      spouseStmt: true,
      collateral: false
    }
    for (let i in this.hideElement) {
      Object.keys(group).forEach(it => {
        if (i.includes(it) && this.hideElement[i]) {
          delete group[it]
        }
      })
    }
    this.newEditBSForm = this.fb.group(group)
    this.validationRequiements()
  }

  validationRequiements() {
    const params = {
      applicationCde: 5,
      applicationViewCde: 5,
      customChartOfAccountCde: null
    }
    this.restService.post(environment.commonBaseURI + environment.endpoints.retAppViewRequirements, params)
      .subscribe(
        result => {
          this.errorDesc = result.RetrieveApplicationViewRequirementsResult.ApplicationViewDictionaryObjectRequirements
          this.showAstersk = {}
          this.errorDesc.forEach(it => {
            if (it.DictionaryObjectDesc?.toLowerCase().includes('cost')) this.showAstersk.costOrMarket = true;
            else if (it.DictionaryObjectDesc?.toLowerCase().includes('financial')) this.showAstersk.financial = true;
            else if (it.DictionaryObjectDesc?.toLowerCase().includes('template')) this.showAstersk.template = true;
          })

          Object.keys(this.newEditBSForm.controls).forEach((key) => {
            this.errorDesc.forEach(it => {
              if (it?.DictionaryObjectDesc?.toLowerCase().includes(key.toLowerCase())) {
                this.map.set(key, it.DictionaryObjectDesc)
              }
            })
          })
        }
      )
  }

  checkBSMode(fStatementBID: number) {
    this.OpenMode = 0
    if (this.OpenMode === ModalOpenMode.Create) {
      this.restService.get('./assets/json/CustomerBIDResult.json')
        .subscribe(
          result => {
            this.customer = result.RetrieveCustomerByCustomerBIDResult
          }
        )
    }

    // to set the last day of previous month
    this.value.setDate(1);
    this.value.setHours(-1);
  }

  openComentEditor(e, category: string) {
    let customerID: number = this.customerID.customerId;
    let actionCde: number;
    let commentBID: number = null;
    let actionCde1: number;
    let commentBID1: number = null;
    if (category === 'SD') {
      actionCde = (this.summaryDescId === undefined || this.summaryDescId === null) ? DTOAction.Insert : DTOAction.Update;
      commentBID = this.summaryDescId;
      if (commentBID != null || commentBID === undefined) {
        this.store.dispatch(commentsActions.initialCommentsDataLoad({
          commentBID: commentBID
        }));
      }
    }
    if (category === 'CN') {
      actionCde1 = (this.cnDescId === undefined || this.cnDescId === null) ? DTOAction.Insert : DTOAction.Update;
      commentBID1 = this.cnDescId;

      if (commentBID1 != null || commentBID1 === undefined) {
        this.store.dispatch(commentsActions.initialCommentsDataLoad({
          commentBID: commentBID1
        }));
      }
    }
    const dialog: any = this.kendoModalService.open('window', 'commentEditor', CommentEditor);
    const overlay = this.kendoModalService.addOverlay();
    if (category === 'SD' && this.sdComment && this.sdComment.Comment) {
      dialog.content.instance.value = this.sdComment.Comment;
    }
    else if (category === 'CN' && this.cnComment && this.cnComment.Comment) {
      dialog.content.instance.value = this.cnComment.Comment;
    }
    dialog.result.subscribe((response) => {
      this.kendoModalService.removeOverlay(overlay);
      if (response.action === 'OK') {
        const str = response.comment;
        const strippedText = str.replace(/(<([^>]+)>)/ig, "");
        if (category === 'CN') {
          this.sdComment = {
            Action: actionCde,
            Comment: response.comment,
            CommentBID: commentBID,
            CommentPlainTxt: strippedText,
            UserID: 1997
          }
          this.store.dispatch(commentsActions.commentsDataSave({
            comment: this.sdComment
          }));
          this.saveComment(category, response);
        }
        else {
          this.cnComment = {
            Action: actionCde,
            Comment: response.comment,
            CommentBID: commentBID1,
            CommentPlainTxt: strippedText,
            UserID: 1997
          }
          this.store.dispatch(commentsActions.commentsDataSave({
            comment: this.cnComment
          }));
          this.saveComment(category, response);
        }
      }
    })
  }

  saveComment(category, response: any) {    
    this.pageName = 'BS'
    this.store.pipe(select(commentsSelector))
      .subscribe(data => {
        if (this.pageName === 'BS' && (data?.type === commentsActions.COMMENTS_SAVE_DATA || data?.type === commentsActions.COMMENTS_UPDATE_DATA)) {
          if (category === 'SD') {
            this.showSumDescIcon = true;
            this.summaryDescId = data?.SaveCommentResult;
          } else {
            this.showCNIcon = true;
            this.cnDescId = data?.SaveCommentResult;
          }
        }
      });

  }

  fetchBsControlDetails(lookUpDetails: BalanceSheetLookUp[]) {
    const statementType = this.subTypesToCheck();
    lookUpDetails.forEach((element) => {    
       this.fillBsControls(element,statementType)
    })
    this.activeTemplateList = this.activeTemplateList.sort((a, b) => (a.text < b.text ? -1 : 1))
  }
 

  fillBsControls(bs: BalanceSheetLookUp, statementType: Number[]) {
    const statementType1 = this.whichComponent == 'Consolidation BS' ? FinancialStatementSubTypes.BalanceSheetConsolidation : FinancialStatementTypes.BalanceSheet
    switch (bs.Table.TableName != '') {
      case (bs.Table.TableCde === CachedLookups.tlkpFilteredFinancialStatementSubType): {
        bs.LookupData.forEach((element) => {
          if (statementType.indexOf(element.Cde) >= 0) {
            this.typeList.push(new ListControl(element.Desc, element.Cde))
          }
        })
        break
      }
      
      case (bs.Table.TableCde === Number(CachedLookups.tlkpFinancialStatementTemplate)): {
        bs.LookupData.forEach((element) => {
          if (element.ExtendedValues.find(x => x.Value === statementType1.toString())) {
            this.activeTemplateList.push(new ListControl(element.Desc, element.Cde))
          }
        })
        break
      }
      case (bs.Table.TableCde === Number(CachedLookups.tlkpFinancialDataSourceType)): {
        bs.LookupData.forEach((element) => {
          this.finQualityList.push(new ListControl(element.Desc, element.Cde))
        })
        break
      }

      case (bs.Table.TableCde === Number(CachedLookups.tslkpCostOrMarketType)): {
        bs.LookupData.forEach((element) => {
          this.costMarketList.push(new ListControl(element.Desc, element.Cde))
        })
        break
      }

      default:
        break
    }
  }

  subTypesToCheck(): Number[] {
    let subTypes: Number[];
    subTypes = [FinancialStatementSubTypes.BalanceSheetSimpleProforma,
    FinancialStatementSubTypes.BalanceSheetAdvancedProforma,
    FinancialStatementSubTypes.BalanceSheetSimplePostClose,
    FinancialStatementSubTypes.BalanceSheetAdvancedPostClose]

    return subTypes;
  }

  close() {
    this.opened = false
  }

  open() {
    this.opened = true
  }

  validateControl(params: any) {
    if (params.response === true) {
      this.selectedItem = params.control == 'type' ? null : this.selectedItem
      this.fControlName = params.control
      const fControldesc = this.map.get(params.control)
      this.setErrorDesc(params.control, fControldesc, params.response)
      this.showErrors(this.fControlName)
      this.showAdditionalInfo = false;
    } else {
      this.fControlError = ''
      this.tooltip?.hide()
      this.resetFormErrors()
      this.showAdditionalInfo = true;
    }
  }

  validateAll() {
    this.errorObj.length = 0
    Object.keys(this.newEditBSForm.controls).forEach((key) => {
      this.errorDesc.forEach(it => {
        if (it?.DictionaryObjectDesc?.toLowerCase().includes(key.toLowerCase())) {
          this.setErrorDesc(key, it.DictionaryObjectDesc)
        }
      })
    })
  }

  resetFormErrors() {
    if (Object.keys(this.formErrors)?.length) {
      for (let i in this.formErrors) {
        this.formErrors[i]['show'] = false
      }
    }
  }

  showErrorOnClick(control) {
    this.resetFormErrors()
    if (this.formErrors[control])
      this.formErrors[control]['show'] = this.formErrors[control]['error'] ? true : false
  }

  setErrorDesc(control: any, desc: string, fControlValue?: boolean) {
    let _errorObj

    if (control == 'date') {
      let dateDesc;
      if (this.newEditBSForm.controls[control].hasError('dateValidator')) {
        if (this.newEditBSForm.controls[control].value === 'month/day/year') {
          dateDesc = `${desc} is required for: ${this.errorDesc[0].RequiredFieldTypeDesc}.`
        } else {
          this.fControlError = dateDesc
          dateDesc = `${desc} is not in the correct format. The correct format is: Date (e.g. "02/02/1993")`
        }
        this.map.get(control) ? _errorObj = {
          key: this.map.get(control),
          value: dateDesc
        } : null
        this.setFormErrors(fControlValue, _errorObj, control)
      } else if (this.newEditBSForm.controls[control].hasError('required') || fControlValue) {
        this.map.get(control) ? _errorObj = {
          key: this.map.get(control),
          value: `${desc} is required for: ${this.errorDesc[0].RequiredFieldTypeDesc}.`
        } : null
        this.setFormErrors(fControlValue, _errorObj, control)
      }
    } else {
      if (this.newEditBSForm.controls[control].hasError('required') || fControlValue) {

        this.map.get(control) ? _errorObj = {
          key: this.map.get(control),
          value: `${desc} is required for: ${this.errorDesc[0].RequiredFieldTypeDesc}.`
        } : null
        this.setFormErrors(fControlValue, _errorObj, control)

      } else if (this.newEditBSForm.controls[control].hasError('maxlength') && this.map.get(control)) {
        _errorObj = {
          key: this.map.get(control),
          value: `${desc} must be : 1-${this.newEditBSForm.controls[control].errors.maxlength.requiredLength} character(s) long.`
        }
        this.errorObj.push(_errorObj)
      }
    }

  }

  setFormErrors(fControlValue, _errorObj, control) {
    if (fControlValue) {
      this.resetFormErrors()
      this.fControlError = _errorObj.value
      this.formErrors[control] = {}
      this.formErrors[control].show = true
      this.formErrors[control].error = _errorObj.value
    } else this.errorObj.push(_errorObj)
  }

  labelChange(e) {
    let _errorObj;
    if (this.newEditBSForm.controls['description'].hasError('required')) {
      this.map.get('description') ? _errorObj = {
        key: this.map.get('description'),
        value: `Balance Sheet Description is required for: ${this.errorDesc[0].RequiredFieldTypeDesc}.`
      } : null

      this.resetFormErrors()
      this.fControlError = _errorObj.value
      this.formErrors['description'] = {}
      this.formErrors['description'].show = true
      this.formErrors['description'].error = _errorObj.value

    }
  }

  showErrors(error) {
    this.tooltip?.hide()

    switch (error != '') {
      case error === 'date':
        // this.tooltip.show(this.first)
        break
      case error === 'type':
        // this.tooltip.show(this.second)
        break
      case error === 'template':
        // this.tooltip.show(this.third)
        break

      default:
        break
    }
  }

  submit(event?) {
    this.submitted = true
    this.tooltip?.hide()
    this.resetFormErrors()
    this.validateAll()
    if (this.newEditBSForm.invalid) {
      return
    }
    /// const dialog: any = this.kendoModalService.open('window', 'OK', EarningCopyStatementPopupComponent)

    this.dataSaved = true
    // this.close()
  }

  closePopUp() {
    this.popupRef ? this.closeAdditionalPopup(this.popupRef) : this.closeAdditionalPopup(this.copyPopUpRef)
    this.popupRef = null
    this.copyPopUpRef = null
    this.windowRef.close();
    this.deleteSDComment();
  }

  copyEarningForm(copyEarningAnchor: ElementRef) {
    this.tooltip?.hide()
    this.resetFormErrors()
    if (this.copyPopUpRef) {
      // this.kendoModalService.close('popup', this.copyPopUpRef);
      this.closeAdditionalPopup(this.copyPopUpRef)
      this.copyPopUpRef = null
    } else {
      this.closeAdditionalPopup(this.popupRef)
      this.popupRef = null
      let bsConsolidationClass;
      let component;
      if (this.whichComponent.includes('Consolidation')) {
        component = BsConsolidationCopyComponent
        bsConsolidationClass = 'bsConsolidationClass'
      } else
        this.copyPopUpRef = this.kendoModalService.open('popup', 'copyEarningForm', EarningCopyStatementPopupComponent, {
          anchor: copyEarningAnchor,
          anchorAlign: { horizontal: 'right', vertical: 'top' },
          popupAlign: { horizontal: 'left', vertical: 'top' },
          popupClass: '' + bsConsolidationClass
        })
      let instance = this.copyPopUpRef.content.instance
      instance.page = "Projection"
      this.toggleCopyArrowStyle = '<span class=\'k-icon k-i-arrow-60-left pl-2\'></span>'

      instance.onFinancialSelected && instance.onFinancialSelected.subscribe(val => {
        this.updateBSForm(val);
      });

    }
  }

  updateBSForm(val) {
    this.costMarketSelected = val.CostOrMarketTypeCde;
    this.financialSelectedItem = val.FinancialDataSourceTypeCde;
    this.activeTemplateSelected = val.FinancialStatementTemplateCde;
    const updatedDate = this.modifyDate(val.FinancialStatementStartDte);
    this.value = updatedDate;
    this.newEditBSForm.patchValue({
      date: updatedDate,
      spouseStmt: val.CombinedStatementWithSpouseInd,
      collateral: val.CollateralStatementInd
    });
  }

  modifyDate(date) {
    const filterPipe = new DateTransformPipe();
    const d = new Date(filterPipe.transform(date, 'MM/DD/yyyy'));
    return new Date(d.getFullYear() + 1, d.getMonth(), d.getDate());
  }

  togglePopup(newBalanceSheetAnchor) {
    this.tooltip?.hide()
    this.resetFormErrors()
    const params = {

      anchor: newBalanceSheetAnchor,
      anchorAlign: {
        horizontal: 'right', vertical: 'top'
      },
      popupAlign: {
        horizontal: 'left', vertical: 'top', padding: '50px'
      },
      popupClass: 'link-popup'
    }

    if (this.popupRef) {
      this.closeAdditionalPopup(this.popupRef)
      this.popupRef = null
    } else {
      this.closeAdditionalPopup(this.copyPopUpRef)
      this.copyPopUpRef = null
      this.popupRef = this.kendoModalService.open('popup',
        'balanceSheetNewLinkForm',
        BalanceSheetHeaderLinkComponent,
        params)
      const instance = this.popupRef.content.instance
      instance.whichComponent = this.whichComponent;
      this.toggleLinkArrowStyle = '<span class=\'k-icon k-i-arrow-60-left pl-2\'></span>'
      if (this.whichComponent?.includes('Consolidation')) {
        instance.priorBSForENW = this.priorBSData
      }
    }
  }

  toggleLink(newBalanceSheetAnchor: ElementRef) {
    if (this.whichComponent?.includes('Consolidation')) {
      this.loadPriorBSData(newBalanceSheetAnchor)
    } else {
      this.togglePopup(newBalanceSheetAnchor)

    }
  }

  closeAdditionalPopup(refPopUp: any) {
    if (refPopUp) {
      this.kendoModalService.close('popup', refPopUp)
      this.toggleLinkArrowStyle = '<span class=\'k-icon k-i-arrow-60-right pl-2\'></span>'
      this.toggleCopyArrowStyle = '<span class=\'k-icon k-i-arrow-60-right pl-2\'></span>'
    }
  }

  /**
   * Delete the comments on the bais of selected category 
   * @param commentBID
   * @param category
   */
  deleteComments(commentBID: number, category: string): void {
    const params = [{ Action: DTOAction.Delete, UserID: 1997, CommentBID: commentBID }];
    this.store.dispatch(commentsActions.commentsDataDelete({
      comments: params
    }));
    this.comment = null;
    if (category === 'SD') {
      this.summaryDescId = null;
    }
    else if (category === 'CN') {
      this.cnDescId = null;
    }
  }

  loadPriorBSData(elem) {
    let paramsData: any = {
      "customerBID": this.selectedCustomerService.getCurrentSelectedCustomer2().customerId,
      "financialStatementBID": null,
      "groupBID": this.selectedGroup.GroupBID
    };
    let balanceSheetHeaderById: Observable<any> = this.restService.post(environment.baseURI + AppConstant.endpoints.retrieveBalanceSheetHeaderByID, paramsData);

    paramsData = {
      "customerBID": this.selectedCustomerService.getCurrentSelectedCustomer2().customerId,
      "includeBS": true,
      "includeES": false,
      "includeActiveGroupsOnly": false
    };
    let consolidationStatementHeader: Observable<any> = this.restService.post(environment.baseURI + AppConstant.endpoints.retrieveCustomerConsolidationFinancialStatement, paramsData);




    forkJoin([balanceSheetHeaderById, consolidationStatementHeader]).subscribe((data: any[]) => {
      if (data && data.length) {
        let bsHeader = []
        let consolidationHeader = []
        data.forEach(d => {
          if (d.RetrieveBalanceSheetHeaderByIDResult?.AvailableBalanceSheetHeaders && d.RetrieveBalanceSheetHeaderByIDResult?.AvailableBalanceSheetHeaders.length) {
            bsHeader = d.RetrieveBalanceSheetHeaderByIDResult.AvailableBalanceSheetHeaders.filter(it => {
              return (new Date(moment.utc(it.FinancialStatementEndDte).format()) < new Date(this.value) && it.FinancialStatementSubTypeCde === FinancialStatementSubTypes.BalanceSheetConsolidation)
            })
          }
          if (d.RetrieveCustomerConsolidationFinancialStatementHeadersResult?.length) {
            d.RetrieveCustomerConsolidationFinancialStatementHeadersResult.forEach(cs => {
              if (cs.FinancialStatements?.length) {
                consolidationHeader = [...consolidationHeader, ...cs.FinancialStatements.filter(it => {
                  return it.FinancialStatementSubTypeCde === FinancialStatementSubTypes.BalanceSheetConsolidation
                })]
              }
            })
          }
        })
        this.priorBSData = [...bsHeader, ...consolidationHeader]
        this.priorBSData = uniqBy(this.priorBSData, 'FinancialStatementBID').reverse()
        let bSHeaderPriorBS: any =
        {
          FinancialStatementBID: 0,
          CustomerBID: 0,
          FinancialStatementEndDte: '',
          FinancialStatementDesc: '',
          FinancialStatementStartDte: '',
          FinancialStatementSubTypeCde: 0,
          FinancialStatementTemplateCde: 0,
          IsDefault: true
        }
        this.priorBSData.unshift(bSHeaderPriorBS);
        this.togglePopup(elem)
      }
      // data && data.length && data[0].RetrieveBalanceSheetHeaderByIDResult?.AvailableBalanceSheetHeaders
    })
  }

  showDidYouKnowTooltip(checked) {
    if (this.infoToolTip === 'none') return
    if (checked) this.infoToolTip = 'hover'
    this.showDidYouKnow = checked
  }

  hideToolTip() {
    this.tooltipDir.hide();
    this.infoToolTip = 'hover';
    this.showDidYouKnow = false;
  }

}
