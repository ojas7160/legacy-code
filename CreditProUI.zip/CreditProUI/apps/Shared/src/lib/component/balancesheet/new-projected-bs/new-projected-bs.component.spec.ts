import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewProjectedBSComponent } from './new-projected-bs.component';

describe('NewProjectedBSComponent', () => {
  let component: NewProjectedBSComponent;
  let fixture: ComponentFixture<NewProjectedBSComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewProjectedBSComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NewProjectedBSComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
