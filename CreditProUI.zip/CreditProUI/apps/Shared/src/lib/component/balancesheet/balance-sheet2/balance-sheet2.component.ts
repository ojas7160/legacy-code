import { Component, ElementRef, OnInit, ViewChild, OnDestroy, AfterViewInit } from '@angular/core';
import { LoggerService, SelectedCustomerService, SignalRService, KendoModalService } from '../../../services';
import { AppConstant } from '../../../constants/app-constants';
import { select, Store } from '@ngrx/store';
import { AppState } from '../../../store';
import { gridDataSelector } from '../../../store/selectors/grid.selector';
import { CommentEditor } from '../../common/comments-editor/comments-editor.component';
import { cloneDeep } from 'lodash';

import { CustomerDetails } from '../../../models/customerDetails.model';
import { CustomerSearchResult } from '../../../models/customer-search-result.model';
import { GridService } from '../../../services/grid/grid.service';
// import { WindowService } from '@progress/kendo-angular-dialog';

@Component({
  selector: 'lib-balancesheet2',
  templateUrl: './balance-sheet2.component.html',
  styleUrls: ['./balance-sheet2.component.scss']
})
export class Balancesheet2Component implements OnInit, OnDestroy, AfterViewInit {
  // public gridData: any[] = sampleProducts;
  @ViewChild('copyLogicAnchor') public copyLogicAnchor: ElementRef;
  @ViewChild('exportOptionAnchor') public exportOptionAnchor: ElementRef;
  @ViewChild('changeViewAnchor') public changeViewAnchor: ElementRef;
  @ViewChild(CommentEditor) commentEditor: any;

  balanceSheetData: any[];
  opened: boolean = false;
  missingData = [];
  columns: any = AppConstant.gridColumns;
  balanceSheetMenus = AppConstant.secondaryMenu.balanceSheet
  columnGroupData: any;
  windowRef: any;
  statementActions = AppConstant.statementActions.balancesheet

  // Customer related details
  public selectedCustomerDetails: CustomerDetails = {};
  public customers: any[];
  public showCustomer: boolean = false;
  public customerData: CustomerSearchResult = {};
  customer = { name: '', branch: '', address1: '', type: '', city: '', state: '', country: '', zip: '', ext: '', phone: '' };

  constructor (
    private loggerService: LoggerService,
    private signalRService: SignalRService,
    private store: Store<AppState>,
    private kendoModalService: KendoModalService,
    private _selectedCustomerService: SelectedCustomerService,
    private gridService: GridService

  ) {
    this.gridService.gridData.subscribe(response => {
      console.log(response);
      this.balanceSheetData = response
    })
  }

  ngOnInit (): void {
    const selectedBSNavigatedData = history.state;
    if (history.state) { this.getSelectedCustomerInfo(selectedBSNavigatedData); }

    this.store.pipe(select(gridDataSelector))
      .subscribe(data => {
        this.columnGroupData = cloneDeep(data.gridData).filter(it => it.type.toLowerCase().includes('balance'))
        this.columns = cloneDeep(data.columnData)
        this.columnGroupData?.length && this.columnGroupData.forEach(it => {
          it.coas = it.coas?.length && it.coas.map(coa => {
            this.columns?.length && this.columns.forEach(column => {
              if (column.id === coa.columnId) {
                coa.columnName = column.dataBindingName
                coa.cellTemplateSelector = column.cellTemplateSelector
              }
            })
            return coa
          })
        })
        this.balanceSheetData = this.transform(cloneDeep(data.coa))
        this.columnGroupData = this.columnGroupData?.length && this.columnGroupData.map(it => {
          if (!it.columns || !it.columns.length) {
            it.columns = this.columns.map(it => Object.assign({}, it))
          }
          return it
        })
      });

    // this.columnGroupData = cloneDeep(data.gridData).filter(it => it.type.toLowerCase().includes('balance'))
    // this.columns = cloneDeep(data.columnData)
    // this.balanceSheetData = this.transformCoa(cloneDeep(data.coa))
    // this.columnGroupData = this.columnGroupData.map(it => {
    //   if (!it.columns || !it.columns.length) {
    //     it.columns = this.columns.map(it => Object.assign({}, it))
    //   }
    //   return it
    // })
    // this.openStatementWindow();
    /**
     * commenting signalR configuration until its up and running to use.
     */

    // this.signalRService.startConnection();
    // this.signalRService.dataListener();

    /**
     *
     * code for tunneling the api data after connection to signalR
     * like hitting the restful service/api for some data.
     */
  }

  transform (coa) {
    return coa?.length && coa.map(chartOfAcc => {
      this.columnGroupData?.length && this.columnGroupData.forEach(statement => {
        chartOfAcc.statementId = statement.id
        chartOfAcc.statementType = statement.type
        statement.coas?.length && statement.coas.forEach(_statement => {
          // chartOfAcc[`${_statement.columnName}${statement.id}`] = ''
          if (chartOfAcc.coaCde === _statement.coaCde) {
            chartOfAcc[`${_statement.columnName}${statement.id}`] = _statement.value
            chartOfAcc.cellTemplateSelector = _statement.cellTemplateSelector
          }
          chartOfAcc[`${_statement.columnName}${statement.id}`] = chartOfAcc[`${_statement.columnName}${statement.id}`] ? chartOfAcc[`${_statement.columnName}${statement.id}`] : ''
        })
      })
      if (chartOfAcc.children && chartOfAcc.children.length) {
        chartOfAcc.children = this.transform(chartOfAcc.children)
      }
      return chartOfAcc
    })
  }

  getSelectedCustomerInfo (selectedBSNavigatedData) {
    this._selectedCustomerService.getCurrentSelectedCustomer().subscribe(data => {
      if (data !== undefined) {
        if (data !== undefined) {
          this.selectedCustomerDetails = { customerBID: data.customerId, customerName: data.customerName };
          this.showCustomer = this.selectedCustomerDetails.customerBID > 0;
        }
      }
    });
    // }
  }

  transformCoa (coa) {
    return coa.map(it => {
      this.columns.forEach(column => {
        column.coas && column.coas.length && column.coas.forEach(columnCoa => {
          if (it.coaCde === columnCoa.coaCde) {
            it = Object.assign({}, { ...it, [column.dataBindingName]: columnCoa.value, cellTemplateSelector: columnCoa.cellTemplateSelector })
          }
        })
      })
      if (it.children && it.children.length) {
        it.children = this.transformCoa(it.children)
      }

      return { ...it }
    })
  }

  ngAfterViewInit () {
    // this.commentEditor.value = "This is passed from parent into child"
  }

  save () {
    this.missingData = []
    for (const c in this.customer) {
      if (!this.customer[c].length) {
        this.missingData.push(`${c} is missing here.`)
      }
    }
  }

  openCommentEditor () {
    this.kendoModalService.open('dialog', 'commentEditor', CommentEditor);
  }

  ngOnDestroy () {
    this.windowRef && this.kendoModalService.close('window', this.windowRef);
    this.windowRef = null;
  }
}
