import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from "rxjs";
import { BalanceSheetHeaderLinkComponent } from './balance-sheet-header-link.component';

describe('BalanceSheetHeaderLinkComponent', () => {
  let component: BalanceSheetHeaderLinkComponent;
  let fixture: ComponentFixture<BalanceSheetHeaderLinkComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BalanceSheetHeaderLinkComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BalanceSheetHeaderLinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
