import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'uc-trend-view',
  templateUrl: './trend-view.component.html',
  styleUrls: ['./trend-view.component.scss']
})
export class TrendViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
