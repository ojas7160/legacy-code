import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BalancesheetCopyStatementPopupComponent } from './balancesheet-copy-statement-popup.component';

describe('BalancesheetCopyStatementPopupComponent', () => {
  let component: BalancesheetCopyStatementPopupComponent;
  let fixture: ComponentFixture<BalancesheetCopyStatementPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BalancesheetCopyStatementPopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BalancesheetCopyStatementPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
