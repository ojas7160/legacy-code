import { Component, OnInit, TemplateRef } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { FinancialService } from 'apps/Shared/src/lib/services';
import { ToasterService } from '../../../services';
import  { AppState } from '../../../store'
import { purchases, purchaseSuccess } from '../../../store/actions';

// import { DcGroupConsolidations } from '../../../models/DcGroupConsolidations';

@Component({
  selector: 'lib-uc-balance-sheet-header',
  templateUrl: './uc-balance-sheet-header.component.html',
  styleUrls: ['./uc-balance-sheet-header.component.scss'],
})
export class UcBalanceSheetHeaderComponent implements OnInit {
  ModalTitle: string;
  BalanceSheetDate: Date = new Date();
  BalanceSheetDescription: string;
  //tlkpFilteredFinancialStatementSubType: DcLookupTableValues[];
  tlkpFilteredFinancialStatementSubType: any[];
  opened;

  tslkpCostOrMarketType: Array<string> = [
    'Cost',
    'Market'
  ];
  tlkpFinancialDataSourceType: any[];
  tlkpFinancialStatementTemplate: any[];
  CombinedStatementWithSpouseInd: boolean;

  CollateralStatementInd: boolean;

  constructor(
    private financialService: FinancialService,
    private toasterService: ToasterService,
    private _store: Store<AppState>
  ) {
    this._store.dispatch(purchases({hello: 'test'}))
    // console.log(this._store.pipe(select(userPurchases)))
    // this._store.pipe(select(userPurchases)).subscribe(data => {
    //   console.log(data)
    // })
  }

  ngOnInit(): void {}

  openModal(id: string) {
  }

  closeModal(id: string) {
  }

  openModalWithClass(a) {}

  OpenCollateralComment() {}

  links() {}

  copy() {}

  cancel() {}
  ok() {}

  AssociatedCustomerBID: number = 1;
  dcGroupConsolidations;
  Load() {
    this.dcGroupConsolidations =
      this.financialService.RetrieveCustomerConsolidationFinancialStatementHeaders(
        this.AssociatedCustomerBID,
        true,
        false,
        false
      );
  }

  toast(type) {
    switch(type) {
      case 'success':
        this.toasterService.success();
        break;
      case 'error':
        this.toasterService.error();
        break;
      case 'info':
        this.toasterService.info();
        break;
      case 'warning':
        this.toasterService.warning();
        break;
      default:
        break;

    }
  }
}
