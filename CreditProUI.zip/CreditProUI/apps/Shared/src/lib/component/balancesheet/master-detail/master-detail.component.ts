import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-master-detail',
  templateUrl: './master-detail.component.html',
  styleUrls: ['./master-detail.component.scss']
})
export class MasterDetailComponent implements OnInit {
  errors!: any[]
  public opened = true;
  public dataSaved = false;
  public dialogOpened = false;
  public windowOpened = false;

  constructor() { }

  ngOnInit(): void {
  }

  public submit() {
      this.dataSaved = true;
      // this.close();
  }

  public close(component?: any) {
   this.dialogOpened = false;
  }

  public open(component?: any) {
   this.dialogOpened = true;
  }

  public action(status: any) {
    console.log(`Dialog result: ${status}`);
    this.dialogOpened = false;
  }
}
