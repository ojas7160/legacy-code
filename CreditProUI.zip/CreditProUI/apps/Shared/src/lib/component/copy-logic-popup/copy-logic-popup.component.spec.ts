import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CopyLogicPopupComponent } from './copy-logic-popup.component';

describe('CopyLogicPopupComponent', () => {
  let component: CopyLogicPopupComponent;
  let fixture: ComponentFixture<CopyLogicPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CopyLogicPopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CopyLogicPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
