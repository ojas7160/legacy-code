import { Component, OnInit } from '@angular/core';
import { Align, Offset } from '@progress/kendo-angular-popup';

@Component({
  selector: 'lib-copy-logic-popup',
  templateUrl: './copy-logic-popup.component.html',
  styleUrls: ['./copy-logic-popup.component.scss']
})
export class CopyLogicPopupComponent implements OnInit {
  public toggleText = "UC-CopyLogicPopup";
  public headerContent = "Copy To FCS Options:";
  public dialogOpened = false;
  public offset: Offset = { left: 100, top: 250 };
  public popupAlign: Align = { horizontal: "center", vertical: "center" };
  constructor() { }

  ngOnInit(): void {
  }

  public onToggle(): void {
    this.dialogOpened = !this.dialogOpened;
  }

}
