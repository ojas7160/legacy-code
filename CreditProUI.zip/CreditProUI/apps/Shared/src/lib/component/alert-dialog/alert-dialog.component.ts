import { Component, Input, OnInit } from '@angular/core';
import { DialogRef } from '@progress/kendo-angular-dialog';

@Component({
  selector: 'uc-alert-dialog',
  templateUrl: './alert-dialog.component.html',
  styleUrls: ['./alert-dialog.component.scss']
})
export class AlertDialogComponent {

  @Input() body; 
  @Input() header;
  @Input() showCancelbtn = true;
  @Input() alertImgshow = false;
  constructor(private dialog: DialogRef) { }

  close(param?: string) {
    this.dialog.close(param);
  }

}
