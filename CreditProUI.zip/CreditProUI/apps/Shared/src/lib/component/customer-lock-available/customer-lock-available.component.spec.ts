import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerLockAvailableComponent } from './customer-lock-available.component';

describe('CustomerLockAvailableComponent', () => {
  let component: CustomerLockAvailableComponent;
  let fixture: ComponentFixture<CustomerLockAvailableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerLockAvailableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerLockAvailableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
