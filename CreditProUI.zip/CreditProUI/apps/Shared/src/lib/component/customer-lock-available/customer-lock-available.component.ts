import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-customer-lock-available',
  templateUrl: './customer-lock-available.component.html',
  styleUrls: ['./customer-lock-available.component.scss']
})
export class CustomerLockAvailableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
