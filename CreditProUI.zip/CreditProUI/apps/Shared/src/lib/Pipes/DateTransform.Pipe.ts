import { Pipe, PipeTransform } from "@angular/core";
import * as moment from "moment";


@Pipe({
    name: 'dateTransform'
})
export class DateTransformPipe implements PipeTransform {

    transform(value: string, format: string): string {        
        if (format === undefined)
            format = 'DD-MM-yyyy'
        let date = moment.utc(value).format(format);
        return date;

    }
}