import { Pipe, PipeTransform } from "@angular/core";
import { FinancialStatementSubTypes } from "../enum/financialStatementSubTypes";


@Pipe({
    name: 'financialStatementLogo'
})
export class FinancialStatemntLogoPipe implements PipeTransform {
  
    public rootFinancialStatmentLogoPath = 'assets/img/';
    constructor() {


    }

    transform(value: number, type:string): string {
        this.rootFinancialStatmentLogoPath = type && type.includes('app-icons-imgs') ? 'assets/app-icons-imgs/' : 'assets/img/';
        if (value == FinancialStatementSubTypes.EarningsStatementProjection ||
            value == FinancialStatementSubTypes.EarningsStatementSimpleProjection ||
            value == FinancialStatementSubTypes.BalanceSheetProjection) {
            return this.rootFinancialStatmentLogoPath + "Projection_icon.jpg";
        }
        else if (value == FinancialStatementSubTypes.BalanceSheetAdvancedPostClose ||
            value == FinancialStatementSubTypes.BalanceSheetSimplePostClose) {
            return this.rootFinancialStatmentLogoPath + "thumbnail_postclose.png";
        }
        else if (value == FinancialStatementSubTypes.BalanceSheetAdvancedProforma ||
            value == FinancialStatementSubTypes.BalanceSheetSimpleProforma) {
            return this.rootFinancialStatmentLogoPath + "thumbnail_proforma.PNG";
        }
        else if (value == FinancialStatementSubTypes.BalanceSheetConsolidation) {
            return this.rootFinancialStatmentLogoPath + "consol_bs.png";
        }
        else if (value == FinancialStatementSubTypes.EarningsStatementConsolidation) {
            return this.rootFinancialStatmentLogoPath + "consol_es.png";
        }
        //Balance Sheet Icons
        else if (value == FinancialStatementSubTypes.BalanceSheet) {
            return this.rootFinancialStatmentLogoPath + "balance_icon.jpg";
        }
        //Earnings Statement Icons
        else if (value == FinancialStatementSubTypes.EarningsStatement)
        {
            return this.rootFinancialStatmentLogoPath + "Earnings_icon.jpg";
        }
        else if(value == FinancialStatementSubTypes.EarningsStatementBenchmark) 
        return this.rootFinancialStatmentLogoPath + 'be_benchmarkearnings.png'
        else if (value == FinancialStatementSubTypes.BalanceSheetBenchmark)
        {
            return this.rootFinancialStatmentLogoPath + "bb_benchmarkbalancesheet.png";
        }
        else if (value == FinancialStatementSubTypes.NewStatement)
        {
           return this.rootFinancialStatmentLogoPath + "NewStatement_icon.png";
        }
    }

    
}