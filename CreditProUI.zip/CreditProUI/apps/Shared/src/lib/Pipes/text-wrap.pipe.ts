import { Pipe, PipeTransform } from "@angular/core";


@Pipe({
    name: 'textwrap'
})
export class TextWrapPipe implements PipeTransform {
     size = 20;
    constructor() { }

    transform(value: string, size:number) {   
        if(value !== null) {
            if(value && value.length <= this.size) {
                return value;
            }
            let data;
            if(!size){
                data = value.substr(0, this.size);
            }
            else {
                data = value.substr(0, size);
            }
    
            return data+'...';
        }
        return value;
    }
}