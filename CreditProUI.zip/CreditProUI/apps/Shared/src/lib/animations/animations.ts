import { trigger, state, style, transition, animate } from '@angular/animations';

export const rotatedState = trigger('rotatedState', [
    state('default', style({ transform: 'rotate(0)' })),
    state('rotated', style({ transform: 'rotate(90deg)' })),
    transition('rotated => default', animate('400ms ease-out')),
    transition('default => rotated', animate('400ms ease-in'))
]);

export const slide = trigger('slide', [
    state('right', style({transform: 'translateX(0)'})),
    state('left', style({transform: 'translateX(-100%'})),
    state('enter', style({transform: 'translateX(-100%'})),
    transition('left => right', animate(400)),
    transition('right => left', animate(400)),
    transition('enter => left', animate(400)),
    transition('* => enter', animate(0))
  ]);

