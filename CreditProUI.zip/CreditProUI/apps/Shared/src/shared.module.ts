import {
  NgModule,
  CUSTOM_ELEMENTS_SCHEMA,
  NO_ERRORS_SCHEMA
} from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ExcelModule, GridModule } from '@progress/kendo-angular-grid';
import { DeviceDetectorService } from 'ngx-device-detector';
import { AppUniversalDeviceDetectorService } from './lib/services/utility/app-universal-device-detector.service';
import { SharedLibraryService } from './lib/services/wcf/shared-library.service';
import { SHARED_COMPONENTS } from './lib/component';

import {
  WindowService,
  WindowContainerDirective,
  DialogContainerDirective,
  DialogRef
} from '@progress/kendo-angular-dialog';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TreeViewModule } from '@progress/kendo-angular-treeview';
import { ListViewModule } from '@progress/kendo-angular-listview';
import { UcConsolidationsComponent } from './lib/component/consolidations/uc-consolidations/uc-consolidations.component';
import { UcReportsComponent } from './lib/component/uc-reports/uc-reports.component';
import { ProjectionsComponent } from './lib/component/projections/projections.component';
import { LoaderModule } from '@progress/kendo-angular-indicators';
import { TooltipModule } from '@progress/kendo-angular-tooltip';

// Store
import { StoreModule } from '@ngrx/store';
import { LoaderInterceptor } from './lib/services/rest/loader.interceptor';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ToastrModule } from 'ngx-toastr';
import { ConnectionStatusSignalRComponent } from './lib/component/connection-status-signal-r/connection-status-signal-r.component';
import { EffectsModule } from '@ngrx/effects';
import { UsersEffects } from './lib/store/effects/users/users.effects';
import { AdminOptionsEffects } from './lib/store/effects/adminOptionsEffects/adminOptions.effects';
import { metaReducers, reducers } from './lib/store';
import { LoggerService, SignalRService } from './lib/services';
import { SharedRoutingModule } from './shared.routing';
import { CommonModule, DatePipe } from '@angular/common';
import { COMMON_SHARED_MODULES } from './modules/common-shared-modules/common-shared-modules';

import { CommonSharedModule } from './modules/common-shared-modules/common-shared.module';
import { CustomersEffects } from './lib/store/effects/customers/customers.effects';

import { EarningStatementsEffects } from './lib/store/effects/earningStatementEffects/earningstatement.effects';
import { CustomersListWithEarningStatementEffect } from './lib/store/effects/earningStatementEffects/customerListwithEarningsStatement.effects';

import { ReportsEffects } from './lib/store/effects/reports/reports.effects';
import { GridEffects } from './lib/store/effects/grid.effects';
import { BalanceSheetEffects } from './lib/store/effects/balanceSheet/balanceSheet.effects';
import { ReportService } from './lib/services/report/report.service';
import { CommonService } from './lib/services/common/common.service';
import { ReportExportComponent } from './lib/component/uc-reports/report-export/report-export.component';
import { CustomerBottomTabComponent } from './lib/component/common/customer-bottom-tab/customer-bottom-tab.component';
import { ReportToolbarComponent } from './lib/component/uc-reports/report-export/report-toolbar/report-toolbar.component'
import { OpenStatementEffects } from './lib/store/effects/balanceSheet/openStatement.effect'
import { ReportExportService } from './lib/services/report/report-export.service'
import { LayoutModule } from '@progress/kendo-angular-layout'

import { ConsolidationsEffects } from './lib/store/effects/consolidations/consolidations.effects';
import { OpenConsolidationsEffects } from './lib/store/effects/consolidations/open-consolidations.effects';
// import { ReportViewPdfComponent } from './lib/component/uc-reports/report-view-pdf/report-view-pdf.component';
import { TrendViewComponent } from './lib/component/balancesheet/trend-view/trend-view.component';
import { CommonEffects } from './lib/store/effects/common.effects';
import { CommentsEffects } from './lib/store/effects/comments.effects';
import { FinancialStatementEffects } from './lib/store/effects/balanceSheet/financialStatement.effects';
import { customerStatementEffects } from './lib/store/effects/customers/customerStatement.effects';
import { earningsMultiYearAverageEffects } from './lib/store/effects/earningStatementEffects/earningsMultiYearAverage.effects';
import { BenchmarkEffects } from './lib/store/effects/benchmark/benchmark.effects';
// Feature Modules

@NgModule({
  declarations: [
    SHARED_COMPONENTS,
    UcConsolidationsComponent,
    UcReportsComponent,
    ConnectionStatusSignalRComponent,
    ProjectionsComponent,
    ReportExportComponent,
    CustomerBottomTabComponent,
    ReportToolbarComponent,
    // ReportViewPdfComponent,
    TrendViewComponent

  ],
  imports: [
    CommonModule,
    TranslateModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    // FEATURE_MODULES,
    GridModule,
    ExcelModule,
    LayoutModule,
    TreeViewModule,
    ListViewModule,
    TooltipModule,
    SharedRoutingModule,
    NgbModule,
    COMMON_SHARED_MODULES,
    // IndicatorsModule,
    LoaderModule,
    ToastrModule.forRoot({}),
    StoreModule.forRoot(reducers, {
      metaReducers,
      runtimeChecks: {
        strictStateImmutability: false,
        strictActionImmutability: false,
        strictStateSerializability: false,
        strictActionSerializability: false,
        strictActionWithinNgZone: false,
        strictActionTypeUniqueness: false
      }
    }),
    EffectsModule.forRoot(
      [
        UsersEffects,
        AdminOptionsEffects,
        CustomersEffects,
        EarningStatementsEffects,
        ReportsEffects,
        GridEffects,
        BalanceSheetEffects,
        CustomersListWithEarningStatementEffect,
        ConsolidationsEffects,
        OpenConsolidationsEffects,
        CommonEffects,
        OpenStatementEffects,
        FinancialStatementEffects,
        customerStatementEffects,
        earningsMultiYearAverageEffects,
        CommentsEffects,
        BenchmarkEffects
      ]),
    CommonSharedModule
  ],
  exports: [SHARED_COMPONENTS, WindowContainerDirective, DialogContainerDirective, CommonSharedModule],
  providers: [
    SharedLibraryService,
    LoggerService,
    ReportService,
    ReportExportService,
    CommonService,
    WindowService,
    DialogRef,
    SignalRService,
    {
      provide: DeviceDetectorService,
      useClass: AppUniversalDeviceDetectorService
    },
    { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true },
    DatePipe
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
})
export class SharedModule { }
