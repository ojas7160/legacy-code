import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { SharedModule } from '../../../Shared/src/shared.module';
import { BalanceSheetTrendComponent } from './views/VwBalanceSheetTrend';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PagerModule } from '@progress/kendo-angular-pager';
import { ToolBarModule } from '@progress/kendo-angular-toolbar';

// import { ListViewModule } from '@progress/kendo-angular-listview';
// import { LayoutModule } from '@progress/kendo-angular-layout';
// import { TreeViewModule } from '@progress/kendo-angular-treeview';
// import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
// import { MenuModule } from '@progress/kendo-angular-menu';

@NgModule({
  declarations: [
    AppComponent,
    BalanceSheetTrendComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    SharedModule,
    FormsModule,
    PagerModule,
    ToolBarModule
    // TreeViewModule,
    // DropDownsModule,
    // MenuModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
})
export class AppModule { }
