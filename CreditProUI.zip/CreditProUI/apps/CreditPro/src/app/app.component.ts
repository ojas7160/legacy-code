import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { UcBalanceSheetHeaderComponent } from 'apps/Shared/src/lib/component';
import { ErrorObj } from 'apps/Shared/src/lib/models/errorDescription';
import { CommonService } from 'apps/Shared/src/lib/services/common/common.service';
import { AppState } from 'apps/Shared/src/lib/store';
import * as actions from '../../../Shared/src/lib/store/actions'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'fpiApplication2';

  /**
   *
   */
  constructor(private http: HttpClient, private store: Store<AppState>) {

  }

  ngOnInit() {
    const lookUpTableRequest = {
      lookupTables: [
        {
          TableCde: 28,
          TableName: "tlkpFinancialDataSourceType",
          EmptyOK: false
        },
        {
          TableCde: 21,
          TableName: "tlkpFinancialStatementTemplate",
          EmptyOK: false
        },
        {
          TableCde: 30,
          TableName: "tslkpCostOrMarketType",
          EmptyOK: false
        },
        {
          TableCde: 49,
          TableName: 'tlkpFilteredFinancialStatementSubType',
          EmptyOK: false
        },
        {
          TableCde: 40,
          TableName: 'tlkpGroupType',
          EmptyOK: false
        },
        {
          TableCde: 103,
          TableName: 'tlkpBenchmarkIndustryTemplate',
          EmptyOK: true
        }
      ]
    }
    this.store.dispatch(actions.initialCommonDataLoad(lookUpTableRequest))
    // this.http.get('https://reqres.in/api/users?page=2')
    //   .subscribe(data => {
    //     console.log(data);
    //   })
  }
}
