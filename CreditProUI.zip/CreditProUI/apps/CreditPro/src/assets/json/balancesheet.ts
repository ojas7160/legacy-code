export interface Entry {
  name: string;
  id: number;
  Indicators: 'Special_Schedules' | 'Current_Assets' | 'Intermediate_Assets' | 'Long_Term_Assets' |
  'Current_Libilities' | 'Intermediate_Libilities' | 'Net_Worth' | 'file' | 'directory';
  time: Date;
  FCSValue?: number;
  calc?: boolean;
  contents?: Entry[];
}

let counter = 0;
const nextId = () => counter++;

export const filesystem: Entry[] = [
  {
    Indicators: 'Special_Schedules',
    id: nextId(),
    name: 'Special Schedules',
    FCSValue: 3000000,
    time: new Date('2019-12-18T15:06:11'),
    contents: [
      { Indicators: 'Special_Schedules', calc: true, id: nextId(), name: 'Investment Activity', FCSValue: 25000, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Special_Schedules', id: nextId(), name: 'Livestock Change Analysis', FCSValue: 100000, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Special_Schedules', id: nextId(), name: 'Loan Activity', FCSValue: 11000, time: new Date('2019-12-18T15:06:11') }]
  },

  {
    Indicators: 'Current_Assets',
    id: nextId(),
    name: 'Current Assets',
    time: new Date('2019-12-18T15:06:11'),
    contents: [
      { Indicators: 'Current_Assets', calc: true, id: nextId(), name: 'Cash and Savings', FCSValue: 12500, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Current_Assets', id: nextId(), name: 'Accounts Receiveable', FCSValue: 20000, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Current_Assets', calc: true, id: nextId(), name: 'Bonus Receiveable', FCSValue: 23000, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Current_Assets', id: nextId(), name: 'Finished Inventory', FCSValue: 200000, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Current_Assets', id: nextId(), name: 'Work In Progress', FCSValue: 37604, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Current_Assets', id: nextId(), name: 'Raw Materials', FCSValue: 87601, time: new Date('2019-12-18T15:06:11') }]
  },

  {
    Indicators: 'Intermediate_Assets',
    id: nextId(),
    name: 'Intermediate Assets',
    time: new Date('2019-12-18T15:06:11'),
    contents: [
      { Indicators: 'Intermediate_Assets', id: nextId(), name: 'Cash Valus Life Insurance', FCSValue: 1153, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Intermediate_Assets', id: nextId(), name: 'Cooperative Stocks', FCSValue: 1153, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Intermediate_Assets', id: nextId(), name: 'Vehicles', FCSValue: 37604, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Intermediate_Assets', id: nextId(), name: 'Reteirement Funds', FCSValue: 1153, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Intermediate_Assets', id: nextId(), name: 'Other Intermediate Assets', FCSValue: 37604, time: new Date('2019-12-18T15:06:11') }
    ]
  },
  {
    Indicators: 'Long_Term_Assets',
    id: nextId(),
    name: 'Long Term Assets',
    time: new Date('2019-12-18T15:06:11'),
    contents: [
      { Indicators: 'Long_Term_Assets', id: nextId(), name: 'Farm Real Estate', FCSValue: 1153, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Long_Term_Assets', id: nextId(), name: 'Residence', FCSValue: 7657, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Long_Term_Assets', id: nextId(), name: 'Other Real Estate', FCSValue: 37604, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Long_Term_Assets', id: nextId(), name: 'Motegage', FCSValue: 45, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Long_Term_Assets', id: nextId(), name: 'Intengible', FCSValue: 6756, time: new Date('2019-12-18T15:06:11') }
    ]
  },
  {
    Indicators: 'Current_Libilities',
    id: nextId(),
    name: 'Current Libilities',
    time: new Date('2019-12-18T15:06:11'),
    contents: [
      { Indicators: 'Current_Libilities', id: nextId(), name: 'Overdraft', FCSValue: 256546, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Current_Libilities', id: nextId(), name: 'Accounts Payable', FCSValue: 32423, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Current_Libilities', id: nextId(), name: 'Insurance Payable', FCSValue: 342, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Current_Libilities', id: nextId(), name: 'Accured Interest', FCSValue: 89789, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Current_Libilities', id: nextId(), name: 'CCC Loan', FCSValue: 37604, time: new Date('2019-12-18T15:06:11') }
    ]
  },
  {
    Indicators: 'Intermediate_Libilities',
    id: nextId(),
    name: 'Intermediate Libilities',
    time: new Date('2019-12-18T15:06:11'),
    contents: [
      { Indicators: 'Intermediate_Libilities', id: nextId(), name: 'Farm Credit', FCSValue: 65467, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Intermediate_Libilities', id: nextId(), name: 'Operating Loss carryover', FCSValue: 876876, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Intermediate_Libilities', id: nextId(), name: 'Fishing vessal Loan', FCSValue: 45656, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Intermediate_Libilities', id: nextId(), name: 'Capital Leases', FCSValue: 456456, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Intermediate_Libilities', id: nextId(), name: 'Livestock Loan', FCSValue: 3245435, time: new Date('2019-12-18T15:06:11') }
    ]
  },
  {
    Indicators: 'Net_Worth',
    id: nextId(),
    name: 'Net Worth',
    time: new Date('2019-12-18T15:06:11'),
    contents: [
      { Indicators: 'Net_Worth', id: nextId(), name: 'Retained Earnings ', FCSValue: 1153, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Net_Worth', id: nextId(), name: 'Evolutions', FCSValue: 11533, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Net_Worth', id: nextId(), name: 'Pais in Capital', FCSValue: 376045, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Net_Worth', id: nextId(), name: 'Common Stocks', FCSValue: 115334, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'Net_Worth', id: nextId(), name: 'Preferred Stocks', FCSValue: 120000, time: new Date('2019-12-18T15:06:11') }
    ]
  },
  // {Indicators: 'file', id: nextId(), name: 'LICENSE.md', FCSValue: 636, time: new Date('2019-12-18T15:06:11')},
  // {Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 4460, time: new Date('2019-12-18T15:06:11')},
  // {Indicators: 'file', id: nextId(), name: 'SUPPORT.md', FCSValue: 3181, time: new Date('2019-12-18T15:06:11')},
  {
    Indicators: 'directory',
    id: nextId(),
    name: 'examples',
    time: new Date('2019-12-18T15:06:11'),
    contents: [
      { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 1153, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'file', id: nextId(), name: 'angular.json', FCSValue: 37604, time: new Date('2019-12-18T15:06:11') },
      {
        Indicators: 'directory',
        id: nextId(),
        name: 'bin',
        time: new Date('2019-12-18T15:06:11'),
        contents: [
          { Indicators: 'file', id: nextId(), name: 'build-all.js', FCSValue: 597, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'publish-gh-pages', FCSValue: 164, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'serve-project.js', FCSValue: 345, time: new Date('2019-12-18T15:06:11') }
        ]
      },
      { Indicators: 'file', id: nextId(), name: 'package-lock.json', FCSValue: 448632, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'file', id: nextId(), name: 'package.json', FCSValue: 3050, time: new Date('2019-12-18T15:06:11') },
      {
        Indicators: 'directory',
        id: nextId(),
        name: 'projects',
        time: new Date('2019-12-18T15:06:11'),
        contents: [
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'chart-websockets',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 1294, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'browserslist', FCSValue: 388, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'karma.conf.js', FCSValue: 1032, time: new Date('2019-12-18T15:06:11') },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'server',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  { Indicators: 'file', id: nextId(), name: 'index.js', FCSValue: 1419, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'package-lock.json', FCSValue: 13649, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'package.json', FCSValue: 304, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'src',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'app',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'app.component.css', FCSValue: 0, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.html', FCSValue: 875, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.spec.ts', FCSValue: 1008, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.ts', FCSValue: 1383, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.module.ts', FCSValue: 595, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'websocket.service.ts', FCSValue: 575, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'assets',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'environments',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'environment.prod.ts', FCSValue: 51, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'environment.ts', FCSValue: 662, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'favicon.ico', FCSValue: 5430, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'index.html', FCSValue: 302, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'main.ts', FCSValue: 372, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'polyfills.ts', FCSValue: 2838, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'styles.css', FCSValue: 80, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'test.ts', FCSValue: 642, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.app.json', FCSValue: 172, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.spec.json', FCSValue: 270, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 247, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'grid-firebase',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 1309, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'browserslist', FCSValue: 385, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'firebase.json', FCSValue: 234, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'karma.conf.js', FCSValue: 1029, time: new Date('2019-12-18T15:06:11') },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'src',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'app',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'app.component.html', FCSValue: 1221, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.spec.ts', FCSValue: 1035, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.ts', FCSValue: 2274, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.module.ts', FCSValue: 1169, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'edit.service.ts', FCSValue: 945, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'products.ts', FCSValue: 2346, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'assets',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'environments',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'environment.prod.ts', FCSValue: 51, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'environment.ts', FCSValue: 662, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'favicon.ico', FCSValue: 5430, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'index.html', FCSValue: 299, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'main.ts', FCSValue: 372, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'polyfills.ts', FCSValue: 2838, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'styles.css', FCSValue: 80, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'test.ts', FCSValue: 642, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.app.json', FCSValue: 172, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.spec.json', FCSValue: 270, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 247, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'grid-graphql',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 891, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'browserslist', FCSValue: 385, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'karma.conf.js', FCSValue: 1028, time: new Date('2019-12-18T15:06:11') },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'server',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  { Indicators: 'file', id: nextId(), name: 'index.js', FCSValue: 417, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'package-lock.json', FCSValue: 15151, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'package.json', FCSValue: 400, time: new Date('2019-12-18T15:06:11') },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'schema',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'schema.js', FCSValue: 7470, time: new Date('2019-12-18T15:06:11') }
                    ]
                  }
                ]
              },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'src',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'app',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'app.component.css', FCSValue: 0, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.html', FCSValue: 1416, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.spec.ts', FCSValue: 1013, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.ts', FCSValue: 2743, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.module.ts', FCSValue: 852, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'edit.service.ts', FCSValue: 1435, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'graphql.module.ts', FCSValue: 658, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'model.ts', FCSValue: 177, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'queries.js', FCSValue: 958, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'assets',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'environments',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'environment.prod.ts', FCSValue: 51, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'environment.ts', FCSValue: 662, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'favicon.ico', FCSValue: 5430, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'index.html', FCSValue: 298, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'main.ts', FCSValue: 372, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'polyfills.ts', FCSValue: 2838, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'styles.css', FCSValue: 80, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'test.ts', FCSValue: 642, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.app.json', FCSValue: 172, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.spec.json', FCSValue: 270, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 247, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'grid-jsdo',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 854, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'browserslist', FCSValue: 388, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'karma.conf.js', FCSValue: 1025, time: new Date('2019-12-18T15:06:11') },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'src',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'app',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'app.component.ts', FCSValue: 5190, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.module.ts', FCSValue: 1006, time: new Date('2019-12-18T15:06:11') },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'data',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'customer.config.ts', FCSValue: 470, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'customer.model.ts', FCSValue: 611, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'data-service.event.ts', FCSValue: 57, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'data-service.interface.ts', FCSValue: 728, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'data.service.ts', FCSValue: 6294, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'model-data-result.ts', FCSValue: 170, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'progress-service-config.ts', FCSValue: 559, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'progress-service-factory.ts', FCSValue: 907, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'progress-session.service.ts', FCSValue: 2172, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'progress.service.ts', FCSValue: 4978, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'service-config.ts', FCSValue: 1396, time: new Date('2019-12-18T15:06:11') }
                        ]
                      }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'assets',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'environments',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'environment.prod.ts', FCSValue: 51, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'environment.ts', FCSValue: 662, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'favicon.ico', FCSValue: 5430, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'index.html', FCSValue: 295, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'main.ts', FCSValue: 372, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'polyfills.ts', FCSValue: 2838, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'styles.css', FCSValue: 80, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'test.ts', FCSValue: 642, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.app.json', FCSValue: 172, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.spec.json', FCSValue: 270, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 247, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'grid-signalr',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 1859, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'browserslist', FCSValue: 388, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'karma.conf.js', FCSValue: 1028, time: new Date('2019-12-18T15:06:11') },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'server',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'Controllers',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'TodoController.cs', FCSValue: 1669, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'Hubs',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'TodoHub.cs', FCSValue: 162, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'Program.cs', FCSValue: 654, time: new Date('2019-12-18T15:06:11') },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'Properties',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'launchSettings.json', FCSValue: 775, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'Startup.cs', FCSValue: 1836, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'appsettings.Development.json', FCSValue: 137, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'appsettings.json', FCSValue: 97, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'server.csproj', FCSValue: 295, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'server.sln', FCSValue: 1110, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'src',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'app',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'app.component.css', FCSValue: 29, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.html', FCSValue: 977, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.spec.ts', FCSValue: 989, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.ts', FCSValue: 1522, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.module.ts', FCSValue: 624, time: new Date('2019-12-18T15:06:11') },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'models',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'todo.model.ts', FCSValue: 91, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'services',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'signalr.service.ts', FCSValue: 944, time: new Date('2019-12-18T15:06:11') }
                        ]
                      }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'assets',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'environments',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'environment.prod.ts', FCSValue: 51, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'environment.ts', FCSValue: 662, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'favicon.ico', FCSValue: 5430, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'index.html', FCSValue: 298, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'main.ts', FCSValue: 372, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'polyfills.ts', FCSValue: 2838, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'styles.css', FCSValue: 80, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'test.ts', FCSValue: 642, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.app.json', FCSValue: 172, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.spec.json', FCSValue: 270, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 247, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'integration-i18n',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 890, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'browserslist', FCSValue: 388, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'karma.conf.js', FCSValue: 1032, time: new Date('2019-12-18T15:06:11') },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'projects',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'integration-i18n',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'locale',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'messages.xlf', FCSValue: 49659, time: new Date('2019-12-18T15:06:11') }
                        ]
                      }
                    ]
                  }
                ]
              },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'src',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'app',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'app.component.html', FCSValue: 111, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.scss', FCSValue: 0, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.spec.ts', FCSValue: 1000, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.ts', FCSValue: 222, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.module.ts', FCSValue: 515, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'assets',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'environments',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'environment.prod.ts', FCSValue: 51, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'environment.ts', FCSValue: 662, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'favicon.ico', FCSValue: 5430, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'index.html', FCSValue: 302, time: new Date('2019-12-18T15:06:11') },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'locale',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'messages.es.xlf', FCSValue: 44842, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'messages.xlf', FCSValue: 42194, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'main.ts', FCSValue: 372, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'polyfills.ts', FCSValue: 2838, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'styles.css', FCSValue: 80, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'test.ts', FCSValue: 642, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.app.json', FCSValue: 172, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.spec.json', FCSValue: 270, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 247, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'integration-jquery',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 866, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'browserslist', FCSValue: 388, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'karma.conf.js', FCSValue: 1034, time: new Date('2019-12-18T15:06:11') },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'src',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'app',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'app.component.css', FCSValue: 0, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.html', FCSValue: 624, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.spec.ts', FCSValue: 1000, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.ts', FCSValue: 340, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.module.ts', FCSValue: 2203, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'other.component.ts', FCSValue: 294, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'test-date-picker.component.ts', FCSValue: 1063, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'test-diagram.component.ts', FCSValue: 1694, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'test-editor.component.ts', FCSValue: 1154, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'test-gantt.component.ts', FCSValue: 4603, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'test-grid.component.ts', FCSValue: 1542, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'test-scheduler.component.ts', FCSValue: 4033, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'test-slider.component.ts', FCSValue: 689, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'test-splitter.component.ts', FCSValue: 2578, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'assets',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'environments',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'environment.prod.ts', FCSValue: 51, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'environment.ts', FCSValue: 662, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'favicon.ico', FCSValue: 5430, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'index.html', FCSValue: 318, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'main.ts', FCSValue: 372, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'polyfills.ts', FCSValue: 2838, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'styles.css', FCSValue: 80, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'test.ts', FCSValue: 642, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.app.json', FCSValue: 172, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.spec.json', FCSValue: 270, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 247, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'integration-pwa',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 3373, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'browserslist', FCSValue: 388, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'karma.conf.js', FCSValue: 1031, time: new Date('2019-12-18T15:06:11') },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'src',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'app',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: '_app-common.scss', FCSValue: 1617, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app-routing.module.ts', FCSValue: 310, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.html', FCSValue: 32, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.scss', FCSValue: 0, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.spec.ts', FCSValue: 986, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.ts', FCSValue: 163, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.module.ts', FCSValue: 3141, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.routes.ts', FCSValue: 717, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.style.css', FCSValue: 306, time: new Date('2019-12-18T15:06:11') },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'charts',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'active-issues.component.ts', FCSValue: 10882, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'issue-Indicatorss.component.ts', FCSValue: 2092, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'statistics.component.ts', FCSValue: 1532, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'Indicatorss-distribution.component.ts', FCSValue: 4819, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'common',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 31, time: new Date('2019-12-18T15:06:11') },
                          {
                            Indicators: 'directory',
                            id: nextId(),
                            name: 'utils',
                            time: new Date('2019-12-18T15:06:11'),
                            contents: [
                              { Indicators: 'file', id: nextId(), name: 'Config.ts', FCSValue: 593, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 59, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'router-module.ts', FCSValue: 48, time: new Date('2019-12-18T15:06:11') }
                            ]
                          }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'dashboard',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'dashboard.component.ts', FCSValue: 3071, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'dashboard.template.html', FCSValue: 1531, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 40, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      { Indicators: 'file', id: nextId(), name: 'dashboard.style.scss', FCSValue: 5235, time: new Date('2019-12-18T15:06:11') },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'issues',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 37, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'issues.component.ts', FCSValue: 2245, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'issues.template.html', FCSValue: 5149, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'label.directive.ts', FCSValue: 1136, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'main-menu',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'main-menu.component.html', FCSValue: 1765, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'main-menu.component.scss', FCSValue: 0, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'main-menu.component.spec.ts', FCSValue: 643, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'main-menu.component.ts', FCSValue: 1790, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'markdown',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'markdown.component.ts', FCSValue: 492, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'profile',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 38, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'profile.component.ts', FCSValue: 1566, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'profile.template.html', FCSValue: 6205, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'shared',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: '_custom.scss', FCSValue: 2402, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'github.service.ts', FCSValue: 1472, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 33, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'issues-processor.service.ts', FCSValue: 5617, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'issues.model.ts', FCSValue: 1313, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'shared.module.ts', FCSValue: 300, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'spinner.component.ts', FCSValue: 426, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'signin',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 39, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'signin.component.ts', FCSValue: 645, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'signin.template.html', FCSValue: 530, time: new Date('2019-12-18T15:06:11') }
                        ]
                      }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'assets',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'app_icon',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'angularX144.png', FCSValue: 5078, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'angularX192.png', FCSValue: 7010, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'angularX36.png', FCSValue: 1600, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'angularX48.png', FCSValue: 2070, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'angularX512.png', FCSValue: 19822, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'angularX72.png', FCSValue: 2715, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'angularX96.png', FCSValue: 3571, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'help_images',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'add_to_home.png', FCSValue: 51829, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'cached_local.png', FCSValue: 55215, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'cached_remote.png', FCSValue: 56083, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'confirm.png', FCSValue: 25508, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'dashboard.png', FCSValue: 101068, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'offline.png', FCSValue: 36927, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'sw.png', FCSValue: 36331, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'i18n',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'en.json', FCSValue: 417, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      { Indicators: 'file', id: nextId(), name: 'issue-closed.png', FCSValue: 1222, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'issue-open.png', FCSValue: 1159, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'issueclosed.png', FCSValue: 1222, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'issueopen.png', FCSValue: 1159, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'login-left-bg.png', FCSValue: 35043, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'login-right-bg.png', FCSValue: 40236, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'noConnection.png', FCSValue: 11232, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'environments',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'environment.prod.ts', FCSValue: 51, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'environment.ts', FCSValue: 662, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'favicon.ico', FCSValue: 5430, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'index.html', FCSValue: 893, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'main.ts', FCSValue: 372, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'manifest.json', FCSValue: 1484, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'ngsw-config.json', FCSValue: 551, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'polyfills.ts', FCSValue: 2838, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'styles.scss', FCSValue: 1049, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'test.ts', FCSValue: 642, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.app.json', FCSValue: 172, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.spec.json', FCSValue: 270, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 247, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'integration-pwa-material',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 3234, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'browserslist', FCSValue: 388, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'karma.conf.js', FCSValue: 1031, time: new Date('2019-12-18T15:06:11') },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'src',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'app',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'app-routing.module.ts', FCSValue: 310, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.html', FCSValue: 32, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.spec.ts', FCSValue: 986, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.ts', FCSValue: 163, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.module.ts', FCSValue: 3227, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.routes.ts', FCSValue: 717, time: new Date('2019-12-18T15:06:11') },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'charts',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'active-issues.component.ts', FCSValue: 11951, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'issue-Indicatorss.component.ts', FCSValue: 2161, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'statistics.component.ts', FCSValue: 1300, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'Indicatorss-distribution.component.ts', FCSValue: 5299, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'common',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 31, time: new Date('2019-12-18T15:06:11') },
                          {
                            Indicators: 'directory',
                            id: nextId(),
                            name: 'utils',
                            time: new Date('2019-12-18T15:06:11'),
                            contents: [
                              { Indicators: 'file', id: nextId(), name: 'Config.ts', FCSValue: 593, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 59, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'router-module.ts', FCSValue: 48, time: new Date('2019-12-18T15:06:11') }
                            ]
                          }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'dashboard',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'dashboard.component.ts', FCSValue: 3077, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'dashboard.template.html', FCSValue: 1555, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 39, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'issues',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 36, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'issues.component.ts', FCSValue: 2266, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'issues.template.html', FCSValue: 5078, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'label.directive.ts', FCSValue: 1136, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'main-menu',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'main-menu.component.html', FCSValue: 2038, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'main-menu.component.spec.ts', FCSValue: 643, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'main-menu.component.ts', FCSValue: 1739, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'markdown',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'markdown.component.ts', FCSValue: 492, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'profile',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 37, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'profile.component.ts', FCSValue: 1343, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'profile.template.html', FCSValue: 6959, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'scss',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: '_dashboard.scss', FCSValue: 1330, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: '_globals.scss', FCSValue: 1741, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: '_header.scss', FCSValue: 212, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: '_issues.scss', FCSValue: 881, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: '_login.scss', FCSValue: 579, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: '_nav.scss', FCSValue: 2203, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: '_profile.scss', FCSValue: 143, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: '_typography.scss', FCSValue: 373, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: '_variables.scss', FCSValue: 2631, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'bootstrap-custom.scss', FCSValue: 84, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'shared',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'github.service.ts', FCSValue: 1472, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 33, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'issues-processor.service.ts', FCSValue: 5617, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'issues.model.ts', FCSValue: 1313, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'shared.module.ts', FCSValue: 300, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'spinner.component.ts', FCSValue: 403, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'signin',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 37, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'signin.component.ts', FCSValue: 660, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'signin.template.html', FCSValue: 1017, time: new Date('2019-12-18T15:06:11') }
                        ]
                      }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'assets',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'app_icon',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'angularX144.png', FCSValue: 5078, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'angularX192.png', FCSValue: 7010, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'angularX36.png', FCSValue: 1600, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'angularX48.png', FCSValue: 2070, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'angularX512.png', FCSValue: 19822, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'angularX72.png', FCSValue: 2715, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'angularX96.png', FCSValue: 3571, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'help_images',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'add_to_home.png', FCSValue: 51829, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'cached_local.png', FCSValue: 55215, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'cached_remote.png', FCSValue: 56083, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'confirm.png', FCSValue: 25508, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'dashboard.png', FCSValue: 101068, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'offline.png', FCSValue: 36927, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'sw.png', FCSValue: 36331, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'i18n',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'en.json', FCSValue: 417, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      { Indicators: 'file', id: nextId(), name: 'issue-closed.png', FCSValue: 1222, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'issue-open.png', FCSValue: 1159, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'issueclosed.png', FCSValue: 1222, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'issueopen.png', FCSValue: 1159, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'login-left-bg.png', FCSValue: 35043, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'login-right-bg.png', FCSValue: 40236, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'noConnection.png', FCSValue: 11232, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'environments',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'environment.prod.ts', FCSValue: 51, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'environment.ts', FCSValue: 662, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'favicon.ico', FCSValue: 5430, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'index.html', FCSValue: 703, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'main.ts', FCSValue: 372, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'manifest.json', FCSValue: 1422, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'ngsw-config.json', FCSValue: 551, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'polyfills.ts', FCSValue: 2838, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'styles.scss', FCSValue: 389, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'test.ts', FCSValue: 642, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.app.json', FCSValue: 172, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.spec.json', FCSValue: 270, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 247, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'pdf-embedded-fonts',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 700, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'browserslist', FCSValue: 385, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'karma.conf.js', FCSValue: 1034, time: new Date('2019-12-18T15:06:11') },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'src',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'app',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'app.component.ts', FCSValue: 778, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.module.ts', FCSValue: 744, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'invoice-data.ts', FCSValue: 345, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'invoice-row.ts', FCSValue: 209, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'invoice.component.ts', FCSValue: 2540, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'assets',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'DejaVuSans.ttf', FCSValue: 757076, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'environments',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'environment.prod.ts', FCSValue: 51, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'environment.ts', FCSValue: 662, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'favicon.ico', FCSValue: 5430, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'index.html', FCSValue: 314, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'main.ts', FCSValue: 372, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'polyfills.ts', FCSValue: 2838, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'styles.scss', FCSValue: 1195, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'test.ts', FCSValue: 642, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.app.json', FCSValue: 172, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.spec.json', FCSValue: 270, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 247, time: new Date('2019-12-18T15:06:11') }
            ]
          }
        ]
      },
      {
        Indicators: 'directory',
        id: nextId(),
        name: 'static',
        time: new Date('2019-12-18T15:06:11'),
        contents: [
          { Indicators: 'file', id: nextId(), name: '404.html', FCSValue: 292, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'index.html', FCSValue: 883, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'styles.css', FCSValue: 57, time: new Date('2019-12-18T15:06:11') }
        ]
      },
      { Indicators: 'file', id: nextId(), name: 'tsconfig.json', FCSValue: 467, time: new Date('2019-12-18T15:06:11') },
      { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 1954, time: new Date('2019-12-18T15:06:11') }
    ]
  },
  {
    Indicators: 'directory',
    id: nextId(),
    name: 'examples-standalone',
    time: new Date('2019-12-18T15:06:11'),
    contents: [
      {
        Indicators: 'directory',
        id: nextId(),
        name: 'angular-universal',
        time: new Date('2019-12-18T15:06:11'),
        contents: [
          { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 1699, time: new Date('2019-12-18T15:06:11') },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'aspnet_core_sample_application',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'ClientApp',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 1040, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'angular.json', FCSValue: 4344, time: new Date('2019-12-18T15:06:11') },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'e2e',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'protractor.conf.js', FCSValue: 752, time: new Date('2019-12-18T15:06:11') },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'src',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'app.e2e-spec.ts', FCSValue: 277, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'app.po.ts', FCSValue: 206, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      { Indicators: 'file', id: nextId(), name: 'tsconfig.e2e.json', FCSValue: 213, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'package-lock.json', FCSValue: 424000, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'package.json', FCSValue: 2401, time: new Date('2019-12-18T15:06:11') },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'src',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'app',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'app.component.css', FCSValue: 172, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'app.component.html', FCSValue: 118, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'app.component.ts', FCSValue: 207, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'app.module.ts', FCSValue: 1297, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'app.server.module.ts', FCSValue: 413, time: new Date('2019-12-18T15:06:11') },
                          {
                            Indicators: 'directory',
                            id: nextId(),
                            name: 'counter',
                            time: new Date('2019-12-18T15:06:11'),
                            contents: [
                              { Indicators: 'file', id: nextId(), name: 'counter.component.html', FCSValue: 215, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'counter.component.spec.ts', FCSValue: 1133, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'counter.component.ts', FCSValue: 260, time: new Date('2019-12-18T15:06:11') }
                            ]
                          },
                          {
                            Indicators: 'directory',
                            id: nextId(),
                            name: 'fetch-data',
                            time: new Date('2019-12-18T15:06:11'),
                            contents: [
                              { Indicators: 'file', id: nextId(), name: 'fetch-data.component.html', FCSValue: 842, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'fetch-data.component.ts', FCSValue: 819, time: new Date('2019-12-18T15:06:11') }
                            ]
                          },
                          {
                            Indicators: 'directory',
                            id: nextId(),
                            name: 'home',
                            time: new Date('2019-12-18T15:06:11'),
                            contents: [
                              { Indicators: 'file', id: nextId(), name: 'home.component.html', FCSValue: 1480, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'home.component.ts', FCSValue: 155, time: new Date('2019-12-18T15:06:11') }
                            ]
                          },
                          {
                            Indicators: 'directory',
                            id: nextId(),
                            name: 'nav-menu',
                            time: new Date('2019-12-18T15:06:11'),
                            contents: [
                              { Indicators: 'file', id: nextId(), name: 'nav-menu.component.css', FCSValue: 249, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'nav-menu.component.html', FCSValue: 1239, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'nav-menu.component.ts', FCSValue: 337, time: new Date('2019-12-18T15:06:11') }
                            ]
                          }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'assets',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                        ]
                      },
                      { Indicators: 'file', id: nextId(), name: 'browserslist', FCSValue: 375, time: new Date('2019-12-18T15:06:11') },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'environments',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'environment.prod.ts', FCSValue: 51, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'environment.ts', FCSValue: 631, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      { Indicators: 'file', id: nextId(), name: 'index.html', FCSValue: 326, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'karma.conf.js', FCSValue: 965, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'main.server.ts', FCSValue: 1137, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'main.ts', FCSValue: 553, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'polyfills.ts', FCSValue: 3162, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'styles.scss', FCSValue: 80, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'test.ts', FCSValue: 642, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'tsconfig.app.json', FCSValue: 194, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'tsconfig.server.json', FCSValue: 241, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'tsconfig.spec.json', FCSValue: 282, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 314, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'tsconfig.json', FCSValue: 384, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 2998, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'Controllers',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  { Indicators: 'file', id: nextId(), name: 'SampleDataController.cs', FCSValue: 1508, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'Pages',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  { Indicators: 'file', id: nextId(), name: 'Error.cshtml', FCSValue: 856, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'Error.cshtml.cs', FCSValue: 619, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: '_ViewImports.cshtml', FCSValue: 107, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              { Indicators: 'file', id: nextId(), name: 'Program.cs', FCSValue: 609, time: new Date('2019-12-18T15:06:11') },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'Properties',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  { Indicators: 'file', id: nextId(), name: 'launchSettings.json', FCSValue: 626, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              { Indicators: 'file', id: nextId(), name: 'Startup.cs', FCSValue: 2699, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'appsettings.Development.json', FCSValue: 137, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'appsettings.json', FCSValue: 97, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'dotnet-angular.csproj', FCSValue: 2804, time: new Date('2019-12-18T15:06:11') },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'wwwroot',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  { Indicators: 'file', id: nextId(), name: 'favicon.ico', FCSValue: 32038, time: new Date('2019-12-18T15:06:11') }
                ]
              }
            ]
          },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'node_sample_application',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 2169, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'angular.json', FCSValue: 4539, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'package-lock.json', FCSValue: 346174, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'package.json', FCSValue: 2952, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'prerender.ts', FCSValue: 1507, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'server.ts', FCSValue: 1506, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'server.tsconfig.json', FCSValue: 399, time: new Date('2019-12-18T15:06:11') },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'src',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'app',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'app.component.ts', FCSValue: 1047, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.module.ts', FCSValue: 1003, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.server.module.ts', FCSValue: 718, time: new Date('2019-12-18T15:06:11') },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'home',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'home.component.ts', FCSValue: 1009, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'products.ts', FCSValue: 37654, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'lazy',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'lazy.module.ts', FCSValue: 1107, time: new Date('2019-12-18T15:06:11') }
                        ]
                      }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'assets',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'environments',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'environment.prod.ts', FCSValue: 51, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'environment.ts', FCSValue: 383, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'favicon.ico', FCSValue: 5430, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'index.html', FCSValue: 302, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'main.server.ts', FCSValue: 57, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'main.ts', FCSValue: 459, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'polyfills.ts', FCSValue: 2480, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'styles.css', FCSValue: 80, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'tsconfig.app.json', FCSValue: 229, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'tsconfig.server.json', FCSValue: 469, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              { Indicators: 'file', id: nextId(), name: 'static.paths.ts', FCSValue: 62, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.json', FCSValue: 363, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 2987, time: new Date('2019-12-18T15:06:11') }
            ]
          }
        ]
      },
      {
        Indicators: 'directory',
        id: nextId(),
        name: 'aspnetcore-data',
        time: new Date('2019-12-18T15:06:11'),
        contents: [
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'ClientApp',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 1059, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'angular.json', FCSValue: 4561, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'browserslist', FCSValue: 383, time: new Date('2019-12-18T15:06:11') },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'e2e',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  { Indicators: 'file', id: nextId(), name: 'protractor.conf.js', FCSValue: 785, time: new Date('2019-12-18T15:06:11') },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'src',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'app.e2e-spec.ts', FCSValue: 291, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.po.ts', FCSValue: 217, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'tsconfig.e2e.json', FCSValue: 225, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              { Indicators: 'file', id: nextId(), name: 'package-lock.json', FCSValue: 413163, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'package.json', FCSValue: 2310, time: new Date('2019-12-18T15:06:11') },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'src',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'app',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'app.component.css', FCSValue: 178, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.html', FCSValue: 124, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.ts', FCSValue: 178, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.module.ts', FCSValue: 1561, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.server.module.ts', FCSValue: 424, time: new Date('2019-12-18T15:06:11') },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'counter',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'counter.component.html', FCSValue: 241, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'counter.component.spec.ts', FCSValue: 1169, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'counter.component.ts', FCSValue: 273, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'fetch-data',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'data.service.ts', FCSValue: 2884, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'fetch-data.component.html', FCSValue: 1544, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'fetch-data.component.ts', FCSValue: 2304, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'home',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'home.component.html', FCSValue: 1494, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'home.component.ts', FCSValue: 163, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'nav-menu',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'nav-menu.component.css', FCSValue: 267, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'nav-menu.component.html', FCSValue: 1472, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'nav-menu.component.ts', FCSValue: 355, time: new Date('2019-12-18T15:06:11') }
                        ]
                      }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'assets',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'browserslist', FCSValue: 383, time: new Date('2019-12-18T15:06:11') },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'environments',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'environment.prod.ts', FCSValue: 54, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'environment.ts', FCSValue: 646, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'index.html', FCSValue: 354, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'karma.conf.js', FCSValue: 996, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'main.ts', FCSValue: 573, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'polyfills.ts', FCSValue: 2901, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'styles.css', FCSValue: 295, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'test.ts', FCSValue: 662, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'tsconfig.app.json', FCSValue: 181, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'tsconfig.server.json', FCSValue: 192, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'tsconfig.spec.json', FCSValue: 274, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 331, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.json', FCSValue: 432, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 2930, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'Controllers',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'BlogsController.cs', FCSValue: 1810, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'Models',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'Blog.cs', FCSValue: 373, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'BloggingContext.cs', FCSValue: 1626, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'Post.cs', FCSValue: 360, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'Pages',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'Error.cshtml', FCSValue: 882, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'Error.cshtml.cs', FCSValue: 847, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: '_ViewImports.cshtml', FCSValue: 112, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          { Indicators: 'file', id: nextId(), name: 'Program.cs', FCSValue: 616, time: new Date('2019-12-18T15:06:11') },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'Properties',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'launchSettings.json', FCSValue: 682, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 1991, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'Startup.cs', FCSValue: 2923, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'appsettings.Development.json', FCSValue: 146, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'appsettings.json', FCSValue: 111, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'aspnetcore-data.csproj', FCSValue: 3284, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'nuget.config', FCSValue: 502, time: new Date('2019-12-18T15:06:11') },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'wwwroot',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'favicon.ico', FCSValue: 32038, time: new Date('2019-12-18T15:06:11') }
            ]
          }
        ]
      },
      {
        Indicators: 'directory',
        id: nextId(),
        name: 'aspnetcore-upload',
        time: new Date('2019-12-18T15:06:11'),
        contents: [
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'ClientApp',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 1050, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'angular.json', FCSValue: 4498, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'browserslist', FCSValue: 383, time: new Date('2019-12-18T15:06:11') },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'e2e',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  { Indicators: 'file', id: nextId(), name: 'protractor.conf.js', FCSValue: 785, time: new Date('2019-12-18T15:06:11') },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'src',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'app.e2e-spec.ts', FCSValue: 291, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.po.ts', FCSValue: 217, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'tsconfig.e2e.json', FCSValue: 225, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              { Indicators: 'file', id: nextId(), name: 'package-lock.json', FCSValue: 406641, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'package.json', FCSValue: 1810, time: new Date('2019-12-18T15:06:11') },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'src',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'app',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'app.component.html', FCSValue: 91, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.component.ts', FCSValue: 178, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.module.ts', FCSValue: 968, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'app.server.module.ts', FCSValue: 424, time: new Date('2019-12-18T15:06:11') },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'home',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'home.component.html', FCSValue: 135, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'home.component.ts', FCSValue: 163, time: new Date('2019-12-18T15:06:11') }
                        ]
                      }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'assets',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'environments',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'environment.prod.ts', FCSValue: 54, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'environment.ts', FCSValue: 646, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'index.html', FCSValue: 345, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'karma.conf.js', FCSValue: 996, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'main.ts', FCSValue: 573, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'polyfills.ts', FCSValue: 2901, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'styles.css', FCSValue: 295, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'test.ts', FCSValue: 662, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'tsconfig.app.json', FCSValue: 181, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'tsconfig.server.json', FCSValue: 192, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'tsconfig.spec.json', FCSValue: 274, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 331, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.json', FCSValue: 432, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 2930, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'Controllers',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'StreamingController.cs', FCSValue: 2461, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'Pages',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'Error.cshtml', FCSValue: 882, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'Error.cshtml.cs', FCSValue: 849, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: '_ViewImports.cshtml', FCSValue: 116, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          { Indicators: 'file', id: nextId(), name: 'Program.cs', FCSValue: 618, time: new Date('2019-12-18T15:06:11') },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'Properties',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'launchSettings.json', FCSValue: 684, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 919, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'Startup.cs', FCSValue: 2519, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'appsettings.Development.json', FCSValue: 146, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'appsettings.json', FCSValue: 111, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'aspnetcore-upload.csproj', FCSValue: 2844, time: new Date('2019-12-18T15:06:11') },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'wwwroot',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'Upload_Directory',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                ]
              },
              { Indicators: 'file', id: nextId(), name: 'favicon.ico', FCSValue: 32038, time: new Date('2019-12-18T15:06:11') }
            ]
          }
        ]
      },
      {
        Indicators: 'directory',
        id: nextId(),
        name: 'electron-dashboard',
        time: new Date('2019-12-18T15:06:11'),
        contents: [
          { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 4551, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: '_config.yml', FCSValue: 29, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'angular.json', FCSValue: 3867, time: new Date('2019-12-18T15:06:11') },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'e2e',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'app.e2e-spec.ts', FCSValue: 386, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'app.po.ts', FCSValue: 175, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.e2e.json', FCSValue: 193, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          { Indicators: 'file', id: nextId(), name: 'electron-builder.json', FCSValue: 315, time: new Date('2019-12-18T15:06:11') },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'hooks',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'environments',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 7709, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'app.config.ts.tpl', FCSValue: 509, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'set_profile.js', FCSValue: 581, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'src',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'app',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'app.config.ts', FCSValue: 509, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'appconfig.ts', FCSValue: 509, time: new Date('2019-12-18T15:06:11') }
                    ]
                  }
                ]
              }
            ]
          },
          { Indicators: 'file', id: nextId(), name: 'karma.conf.js', FCSValue: 1202, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'logo-angular.jpg', FCSValue: 3354, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'logo-electron.jpg', FCSValue: 8028, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'logo-kendo.png', FCSValue: 11430, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'main.ts', FCSValue: 2388, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'package.json', FCSValue: 4139, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'postcss.config.js', FCSValue: 20, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'protractor.conf.js', FCSValue: 960, time: new Date('2019-12-18T15:06:11') },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'src',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'app',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  { Indicators: 'file', id: nextId(), name: '_app-common.scss', FCSValue: 1617, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'app-routing.module.ts', FCSValue: 310, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'app.component.html', FCSValue: 23, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'app.component.scss', FCSValue: 0, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'app.component.spec.ts', FCSValue: 986, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'app.component.ts', FCSValue: 156, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'app.config.ts', FCSValue: 507, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'app.module.ts', FCSValue: 2816, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'app.routes.ts', FCSValue: 717, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'app.style.css', FCSValue: 284, time: new Date('2019-12-18T15:06:11') },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'charts',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'active-issues.component.ts', FCSValue: 9854, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'issue-Indicatorss.component.ts', FCSValue: 2092, time: new Date('2019-12-18T15:06:11') },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'shared',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: '_custom.scss', FCSValue: 2402, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'github.service.ts', FCSValue: 1853, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 33, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'issues-processor.service.ts', FCSValue: 5639, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'issues.model.ts', FCSValue: 1313, time: new Date('2019-12-18T15:06:11') },
                          {
                            Indicators: 'directory',
                            id: nextId(),
                            name: 'shared',
                            time: new Date('2019-12-18T15:06:11'),
                            contents: [
                              { Indicators: 'file', id: nextId(), name: '_custom.scss', FCSValue: 2402, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'github.service.ts', FCSValue: 1853, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 33, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'issues-processor.service.ts', FCSValue: 5639, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'issues.model.ts', FCSValue: 1313, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'shared.module.ts', FCSValue: 301, time: new Date('2019-12-18T15:06:11') }
                            ]
                          },
                          { Indicators: 'file', id: nextId(), name: 'shared.module.ts', FCSValue: 301, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      { Indicators: 'file', id: nextId(), name: 'statistics.component.ts', FCSValue: 1249, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'Indicatorss-distribution.component.ts', FCSValue: 4649, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'common',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 31, time: new Date('2019-12-18T15:06:11') },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'utils',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'Config.ts', FCSValue: 593, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 59, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'router-module.ts', FCSValue: 48, time: new Date('2019-12-18T15:06:11') }
                        ]
                      }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'dashboard',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'dashboard.component.ts', FCSValue: 3014, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'dashboard.template.html', FCSValue: 1506, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 39, time: new Date('2019-12-18T15:06:11') },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'shared',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: '_custom.scss', FCSValue: 2402, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'github.service.ts', FCSValue: 1853, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 33, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'issues-processor.service.ts', FCSValue: 5639, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'issues.model.ts', FCSValue: 1313, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'shared.module.ts', FCSValue: 301, time: new Date('2019-12-18T15:06:11') }
                        ]
                      }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'dashboard.style.scss', FCSValue: 5154, time: new Date('2019-12-18T15:06:11') },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'directives',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'webview.directive.ts', FCSValue: 138, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'issues',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 36, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'issues.component.ts', FCSValue: 2236, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'issues.template.html', FCSValue: 5046, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'label.directive.ts', FCSValue: 1055, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'main-menu',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'main-menu.component.html', FCSValue: 1776, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'main-menu.component.scss', FCSValue: 0, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'main-menu.component.spec.ts', FCSValue: 643, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'main-menu.component.ts', FCSValue: 1786, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'markdown',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'markdown.component.ts', FCSValue: 411, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'profile',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 37, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'profile.component.ts', FCSValue: 1571, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'profile.template.html', FCSValue: 6096, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'providers',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'electron.service.ts', FCSValue: 737, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'shared',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: '_custom.scss', FCSValue: 2402, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'github.service.ts', FCSValue: 1853, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 33, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'issues-processor.service.ts', FCSValue: 5639, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'issues.model.ts', FCSValue: 1313, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'shared.module.ts', FCSValue: 301, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'spinner.component.ts', FCSValue: 399, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'signin',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 37, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'signin.component.ts', FCSValue: 640, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'signin.template.html', FCSValue: 530, time: new Date('2019-12-18T15:06:11') }
                    ]
                  }
                ]
              },
              { Indicators: 'file', id: nextId(), name: 'app.style.css', FCSValue: 284, time: new Date('2019-12-18T15:06:11') },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'assets',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  { Indicators: 'file', id: nextId(), name: 'background.jpg', FCSValue: 232337, time: new Date('2019-12-18T15:06:11') },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'i18n',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'en.json', FCSValue: 78, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'issue-closed.png', FCSValue: 1222, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'issue-open.png', FCSValue: 1159, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'issueclosed.png', FCSValue: 1222, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'issueopen.png', FCSValue: 1159, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'login-left-bg.png', FCSValue: 35043, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'login-right-bg.png', FCSValue: 40236, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'environments',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  { Indicators: 'file', id: nextId(), name: 'environment.dev.ts', FCSValue: 394, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'environment.local.ts', FCSValue: 75, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'environment.prod.ts', FCSValue: 72, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              { Indicators: 'file', id: nextId(), name: 'favicon.256x256.png', FCSValue: 14430, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'favicon.icns', FCSValue: 85688, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'favicon.ico', FCSValue: 16224, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'favicon.png', FCSValue: 14430, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'index.html', FCSValue: 491, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'main.ts', FCSValue: 399, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'polyfills.ts', FCSValue: 1323, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'styles.scss', FCSValue: 333, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'test.ts', FCSValue: 761, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.app.json', FCSValue: 259, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'tsconfig.spec.json', FCSValue: 416, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'typings.d.ts', FCSValue: 190, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          { Indicators: 'file', id: nextId(), name: 'tsconfig.json', FCSValue: 438, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 2998, time: new Date('2019-12-18T15:06:11') }
        ]
      },
      {
        Indicators: 'directory',
        id: nextId(),
        name: 'kendo-angular-finance-portfolio',
        time: new Date('2019-12-18T15:06:11'),
        contents: [
          { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 2408, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'angular.json', FCSValue: 2835, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'browserslist', FCSValue: 429, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'package-lock.json', FCSValue: 437540, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'package.json', FCSValue: 2359, time: new Date('2019-12-18T15:06:11') },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'src',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'app',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  { Indicators: 'file', id: nextId(), name: 'app-routing.module.ts', FCSValue: 949, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'app.component.ts', FCSValue: 312, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'app.module.ts', FCSValue: 2775, time: new Date('2019-12-18T15:06:11') },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'components',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'badge',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'badge.component.html', FCSValue: 261, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'badge.component.scss', FCSValue: 412, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'badge.component.ts', FCSValue: 250, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'footer',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'footer.component.html', FCSValue: 360, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'footer.component.scss', FCSValue: 634, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'footer.component.ts', FCSValue: 355, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'header',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'header.component.html', FCSValue: 930, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'header.component.scss', FCSValue: 1198, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'header.component.ts', FCSValue: 668, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'heatmap',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'heatmap.component.html', FCSValue: 1345, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'heatmap.component.scss', FCSValue: 1159, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'heatmap.component.ts', FCSValue: 4051, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'navigation',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'navigation.component.html', FCSValue: 419, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'navigation.component.scss', FCSValue: 318, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'navigation.component.ts', FCSValue: 304, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'real-time-data',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'real-time-data.component.html', FCSValue: 3229, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'real-time-data.component.scss', FCSValue: 697, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'real-time-data.component.ts', FCSValue: 2841, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'stock-chart',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'stock-chart.component.html', FCSValue: 3603, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'stock-chart.component.scss', FCSValue: 559, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'stock-chart.component.ts', FCSValue: 4120, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'stock-details',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'stock-details.component.html', FCSValue: 4674, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'stock-details.component.scss', FCSValue: 230, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'stock-details.component.ts', FCSValue: 3497, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'stock-list',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'stock-list.component.html', FCSValue: 7409, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'stock-list.component.scss', FCSValue: 3106, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'stock-list.component.ts', FCSValue: 3548, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'stocks',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'stocks.component.html', FCSValue: 304, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'stocks.component.scss', FCSValue: 434, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'stocks.component.ts', FCSValue: 330, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'user-profile',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'user-profile.component.html', FCSValue: 3166, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'user-profile.component.scss', FCSValue: 1177, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'user-profile.component.ts', FCSValue: 1267, time: new Date('2019-12-18T15:06:11') }
                        ]
                      }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'data',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'stocks.ts', FCSValue: 41277, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'directives',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      {
                        Indicators: 'file',
                        id: nextId(),
                        name: 'dropdownlist-popup-selector.directive.ts',
                        FCSValue: 1188,
                        time: new Date('2019-12-18T15:06:11')
                      }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'models',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 98, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'interval.ts', FCSValue: 298, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'stock-interval-details.ts', FCSValue: 158, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'stock.ts', FCSValue: 272, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'pipes',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'helpers.ts', FCSValue: 1981, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'number-format.pipe.ts', FCSValue: 275, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'services',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      { Indicators: 'file', id: nextId(), name: 'stock-data.service.ts', FCSValue: 4988, time: new Date('2019-12-18T15:06:11') }
                    ]
                  }
                ]
              },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'assets',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  { Indicators: 'file', id: nextId(), name: 'area.png', FCSValue: 410, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'candle.png', FCSValue: 391, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'cross-out.svg', FCSValue: 774, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'footer-bg.svg', FCSValue: 2643, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'header-bg.svg', FCSValue: 2649, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'line.png', FCSValue: 522, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'progress-logo.svg', FCSValue: 3665, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'user.jpg', FCSValue: 136966, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'environments',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  { Indicators: 'file', id: nextId(), name: 'environment.prod.ts', FCSValue: 51, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'environment.ts', FCSValue: 662, time: new Date('2019-12-18T15:06:11') }
                ]
              },
              { Indicators: 'file', id: nextId(), name: 'favicon.ico', FCSValue: 5430, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'index.html', FCSValue: 422, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'main.ts', FCSValue: 372, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'polyfills.ts', FCSValue: 2838, time: new Date('2019-12-18T15:06:11') },
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'styles',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  { Indicators: 'file', id: nextId(), name: '_bootstrap.scss', FCSValue: 557, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: '_kendo.scss', FCSValue: 1687, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: '_main.scss', FCSValue: 147, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: '_responsive.scss', FCSValue: 859, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: '_typography.scss', FCSValue: 238, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: '_variables.scss', FCSValue: 2212, time: new Date('2019-12-18T15:06:11') }
                ]
              }
            ]
          },
          { Indicators: 'file', id: nextId(), name: 'tsconfig.app.json', FCSValue: 210, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'tsconfig.json', FCSValue: 543, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'tsconfig.spec.json', FCSValue: 270, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 1988, time: new Date('2019-12-18T15:06:11') }
        ]
      },
      {
        Indicators: 'directory',
        id: nextId(),
        name: 'material-dashboard',
        time: new Date('2019-12-18T15:06:11'),
        contents: [
          { Indicators: 'file', id: nextId(), name: 'angular.json', FCSValue: 3757, time: new Date('2019-12-18T15:06:11') },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'bin',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: 'build-all.js', FCSValue: 597, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'serve-project.js', FCSValue: 345, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          { Indicators: 'file', id: nextId(), name: 'package-lock.json', FCSValue: 448330, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'package.json', FCSValue: 3063, time: new Date('2019-12-18T15:06:11') },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'project',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              {
                Indicators: 'directory',
                id: nextId(),
                name: 'integration-pwa-material',
                time: new Date('2019-12-18T15:06:11'),
                contents: [
                  { Indicators: 'file', id: nextId(), name: 'README.md', FCSValue: 3234, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'browserslist', FCSValue: 388, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'karma.conf.js', FCSValue: 1031, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'ngsw-config.json', FCSValue: 551, time: new Date('2019-12-18T15:06:11') },
                  {
                    Indicators: 'directory',
                    id: nextId(),
                    name: 'src',
                    time: new Date('2019-12-18T15:06:11'),
                    contents: [
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'app',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'app-routing.module.ts', FCSValue: 310, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'app.component.html', FCSValue: 32, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'app.component.spec.ts', FCSValue: 986, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'app.component.ts', FCSValue: 163, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'app.module.ts', FCSValue: 3227, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'app.routes.ts', FCSValue: 717, time: new Date('2019-12-18T15:06:11') },
                          {
                            Indicators: 'directory',
                            id: nextId(),
                            name: 'charts',
                            time: new Date('2019-12-18T15:06:11'),
                            contents: [
                              { Indicators: 'file', id: nextId(), name: 'active-issues.component.ts', FCSValue: 11951, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'issue-Indicatorss.component.ts', FCSValue: 2161, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'statistics.component.ts', FCSValue: 1300, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'Indicatorss-distribution.component.ts', FCSValue: 5299, time: new Date('2019-12-18T15:06:11') }
                            ]
                          },
                          {
                            Indicators: 'directory',
                            id: nextId(),
                            name: 'common',
                            time: new Date('2019-12-18T15:06:11'),
                            contents: [
                              { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 31, time: new Date('2019-12-18T15:06:11') },
                              {
                                Indicators: 'directory',
                                id: nextId(),
                                name: 'utils',
                                time: new Date('2019-12-18T15:06:11'),
                                contents: [
                                  { Indicators: 'file', id: nextId(), name: 'Config.ts', FCSValue: 593, time: new Date('2019-12-18T15:06:11') },
                                  { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 59, time: new Date('2019-12-18T15:06:11') },
                                  { Indicators: 'file', id: nextId(), name: 'router-module.ts', FCSValue: 48, time: new Date('2019-12-18T15:06:11') }
                                ]
                              }
                            ]
                          },
                          {
                            Indicators: 'directory',
                            id: nextId(),
                            name: 'dashboard',
                            time: new Date('2019-12-18T15:06:11'),
                            contents: [
                              { Indicators: 'file', id: nextId(), name: 'dashboard.component.ts', FCSValue: 3077, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'dashboard.template.html', FCSValue: 1555, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 39, time: new Date('2019-12-18T15:06:11') }
                            ]
                          },
                          {
                            Indicators: 'directory',
                            id: nextId(),
                            name: 'issues',
                            time: new Date('2019-12-18T15:06:11'),
                            contents: [
                              { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 36, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'issues.component.ts', FCSValue: 2266, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'issues.template.html', FCSValue: 5078, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'label.directive.ts', FCSValue: 1136, time: new Date('2019-12-18T15:06:11') }
                            ]
                          },
                          {
                            Indicators: 'directory',
                            id: nextId(),
                            name: 'main-menu',
                            time: new Date('2019-12-18T15:06:11'),
                            contents: [
                              { Indicators: 'file', id: nextId(), name: 'main-menu.component.html', FCSValue: 2038, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'main-menu.component.spec.ts', FCSValue: 643, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'main-menu.component.ts', FCSValue: 1739, time: new Date('2019-12-18T15:06:11') }
                            ]
                          },
                          {
                            Indicators: 'directory',
                            id: nextId(),
                            name: 'markdown',
                            time: new Date('2019-12-18T15:06:11'),
                            contents: [
                              { Indicators: 'file', id: nextId(), name: 'markdown.component.ts', FCSValue: 492, time: new Date('2019-12-18T15:06:11') }
                            ]
                          },
                          {
                            Indicators: 'directory',
                            id: nextId(),
                            name: 'profile',
                            time: new Date('2019-12-18T15:06:11'),
                            contents: [
                              { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 37, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'profile.component.ts', FCSValue: 1343, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'profile.template.html', FCSValue: 6959, time: new Date('2019-12-18T15:06:11') }
                            ]
                          },
                          {
                            Indicators: 'directory',
                            id: nextId(),
                            name: 'scss',
                            time: new Date('2019-12-18T15:06:11'),
                            contents: [
                              { Indicators: 'file', id: nextId(), name: '_dashboard.scss', FCSValue: 1330, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: '_globals.scss', FCSValue: 1741, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: '_header.scss', FCSValue: 212, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: '_issues.scss', FCSValue: 881, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: '_login.scss', FCSValue: 579, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: '_nav.scss', FCSValue: 2203, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: '_profile.scss', FCSValue: 143, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: '_typography.scss', FCSValue: 373, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: '_variables.scss', FCSValue: 2631, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'bootstrap-custom.scss', FCSValue: 95, time: new Date('2019-12-18T15:06:11') }
                            ]
                          },
                          {
                            Indicators: 'directory',
                            id: nextId(),
                            name: 'shared',
                            time: new Date('2019-12-18T15:06:11'),
                            contents: [
                              { Indicators: 'file', id: nextId(), name: 'github.service.ts', FCSValue: 1472, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 33, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'issues-processor.service.ts', FCSValue: 5617, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'issues.model.ts', FCSValue: 1313, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'shared.module.ts', FCSValue: 300, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'spinner.component.ts', FCSValue: 403, time: new Date('2019-12-18T15:06:11') }
                            ]
                          },
                          {
                            Indicators: 'directory',
                            id: nextId(),
                            name: 'signin',
                            time: new Date('2019-12-18T15:06:11'),
                            contents: [
                              { Indicators: 'file', id: nextId(), name: 'index.ts', FCSValue: 37, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'signin.component.ts', FCSValue: 660, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'signin.template.html', FCSValue: 1017, time: new Date('2019-12-18T15:06:11') }
                            ]
                          }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'assets',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          {
                            Indicators: 'directory',
                            id: nextId(),
                            name: 'app_icon',
                            time: new Date('2019-12-18T15:06:11'),
                            contents: [
                              { Indicators: 'file', id: nextId(), name: 'angularX144.png', FCSValue: 5078, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'angularX192.png', FCSValue: 7010, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'angularX36.png', FCSValue: 1600, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'angularX48.png', FCSValue: 2070, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'angularX512.png', FCSValue: 19822, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'angularX72.png', FCSValue: 2715, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'angularX96.png', FCSValue: 3571, time: new Date('2019-12-18T15:06:11') }
                            ]
                          },
                          {
                            Indicators: 'directory',
                            id: nextId(),
                            name: 'help_images',
                            time: new Date('2019-12-18T15:06:11'),
                            contents: [
                              { Indicators: 'file', id: nextId(), name: 'add_to_home.png', FCSValue: 51829, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'cached_local.png', FCSValue: 55215, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'cached_remote.png', FCSValue: 56083, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'confirm.png', FCSValue: 25508, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'dashboard.png', FCSValue: 101068, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'offline.png', FCSValue: 36927, time: new Date('2019-12-18T15:06:11') },
                              { Indicators: 'file', id: nextId(), name: 'sw.png', FCSValue: 36331, time: new Date('2019-12-18T15:06:11') }
                            ]
                          },
                          {
                            Indicators: 'directory',
                            id: nextId(),
                            name: 'i18n',
                            time: new Date('2019-12-18T15:06:11'),
                            contents: [
                              { Indicators: 'file', id: nextId(), name: 'en.json', FCSValue: 417, time: new Date('2019-12-18T15:06:11') }
                            ]
                          },
                          { Indicators: 'file', id: nextId(), name: 'issue-closed.png', FCSValue: 1222, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'issue-open.png', FCSValue: 1159, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'issueclosed.png', FCSValue: 1222, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'issueopen.png', FCSValue: 1159, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'login-left-bg.png', FCSValue: 35043, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'login-right-bg.png', FCSValue: 40236, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'noConnection.png', FCSValue: 11232, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      {
                        Indicators: 'directory',
                        id: nextId(),
                        name: 'environments',
                        time: new Date('2019-12-18T15:06:11'),
                        contents: [
                          { Indicators: 'file', id: nextId(), name: 'environment.prod.ts', FCSValue: 51, time: new Date('2019-12-18T15:06:11') },
                          { Indicators: 'file', id: nextId(), name: 'environment.ts', FCSValue: 662, time: new Date('2019-12-18T15:06:11') }
                        ]
                      },
                      { Indicators: 'file', id: nextId(), name: 'favicon.ico', FCSValue: 5430, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'index.html', FCSValue: 703, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'main.ts', FCSValue: 372, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'manifest.json', FCSValue: 1422, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'polyfills.ts', FCSValue: 2838, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'styles.scss', FCSValue: 389, time: new Date('2019-12-18T15:06:11') },
                      { Indicators: 'file', id: nextId(), name: 'test.ts', FCSValue: 642, time: new Date('2019-12-18T15:06:11') }
                    ]
                  },
                  { Indicators: 'file', id: nextId(), name: 'tsconfig.app.json', FCSValue: 172, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'tsconfig.spec.json', FCSValue: 270, time: new Date('2019-12-18T15:06:11') },
                  { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 247, time: new Date('2019-12-18T15:06:11') }
                ]
              }
            ]
          },
          {
            Indicators: 'directory',
            id: nextId(),
            name: 'static',
            time: new Date('2019-12-18T15:06:11'),
            contents: [
              { Indicators: 'file', id: nextId(), name: '404.html', FCSValue: 292, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'index.html', FCSValue: 724, time: new Date('2019-12-18T15:06:11') },
              { Indicators: 'file', id: nextId(), name: 'styles.css', FCSValue: 57, time: new Date('2019-12-18T15:06:11') }
            ]
          },
          { Indicators: 'file', id: nextId(), name: 'tsconfig.json', FCSValue: 467, time: new Date('2019-12-18T15:06:11') },
          { Indicators: 'file', id: nextId(), name: 'tslint.json', FCSValue: 1954, time: new Date('2019-12-18T15:06:11') }
        ]
      }
    ]
  }
]
