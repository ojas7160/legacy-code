export interface Entry {
    statementid : string;
    earningstatementname : string;
    startdate : string;
    enddate : string;
    type : string;
    sourcedate : string;
    financialquality : string;
    activetemplate : string;
    otherparameters : any;
  }
  
  
  export const filesystem: Entry[] = [
      {
        statementid : "1",
        earningstatementname : "Testing statement One",
        startdate : "01/01/2020",
        enddate : "12/31/2020",
        type : "Earning",
        sourcedate : "Cash",
        financialquality : "Electronic Records - Other",
        activetemplate : "Dairy Livestock",
        otherparameters:[
            "Item 1",
            "Item 2"
        ]
      }
  ];