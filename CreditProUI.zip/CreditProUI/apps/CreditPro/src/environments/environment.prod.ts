import { AppConstant } from '../../../Shared/src/lib/constants/app-constants';

export const environment = {
  production: true,
  commonBaseURI: '/WCFCommon.Service/',
  baseURI: '/MMCA.Service/',
  endpoints: AppConstant.endpoints
  // commonBaseURI: 'http://10.161.51.213:61888/',
  // baseURI : 'http://10.161.51.213:41751/',
  /*
  * these above urls are only for testing, below for prod
  */
  // commonBaseURI: 'https://creditpro.farmcrediteast.com/',
  // baseURI : 'http://localhost:41751/',
};
