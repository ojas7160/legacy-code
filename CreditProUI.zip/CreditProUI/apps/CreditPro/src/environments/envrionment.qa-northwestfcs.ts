import { AppConstant } from "apps/Shared/src/lib/constants/app-constants";

export const environment = {
  production: true,
  baseURI: 'https://creditpro-qanext.northwestfcs.com',
  endpoints: AppConstant.endpoints,
  commonBaseURI: 'http://localhost:61888/'
};
