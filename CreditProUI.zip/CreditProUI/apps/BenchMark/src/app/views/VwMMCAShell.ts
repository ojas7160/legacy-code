import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mmcaShell',
  template: ``
})

export class MMCAShellComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
