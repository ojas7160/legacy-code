import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-benchmarkGroup',
  template: ``
})

export class BenchmarkGroupComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
