import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-executiveSummary',
  template: ``
})

export class ExecutiveSummaryComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
