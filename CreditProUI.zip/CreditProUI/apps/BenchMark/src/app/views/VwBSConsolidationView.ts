import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bsConsolidationView',
  template: '<lib-uc-financial-trend></lib-uc-financial-trend>'
})

export class BSConsolidationViewComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
