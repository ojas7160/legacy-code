import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dealSetup',
  template: ``
})

export class DealSetupComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
