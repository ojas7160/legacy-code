import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-esConsolidation',
  template: '<lib-uc-financial-trend></lib-uc-financial-trend>'
})

export class ESConsolidationComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
