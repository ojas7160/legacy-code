import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-balanceSheetTrend',
  template: '<lib-uc-financial-trend></lib-uc-financial-trend>'
})

export class BalanceSheetTrendComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
