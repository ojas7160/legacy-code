import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-balanceSheetProforma',
  template: '<lib-uc-financial-trend></lib-uc-financial-trend>'
})

export class BalanceSheetProformaComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
