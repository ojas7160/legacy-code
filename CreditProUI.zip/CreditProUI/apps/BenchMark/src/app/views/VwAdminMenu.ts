import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminMenu',
  template: `<lib-uc-admin-menu></lib-uc-admin-menu>`
})

export class AdminMenuComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
