import { Component, OnInit } from '@angular/core';
import { RestService } from 'apps/Shared/src/lib/services';

@Component({
  selector: 'app-Consolidations',
  template: `<lib-uc-consolidations></lib-uc-consolidations>`
})

export class ConsolidationsComponent implements OnInit {

  //TODO:test

  constructor(private restService: RestService) {

    //this.restService.get("https://gorest.co.in/public-api/users").subscribe(data=>console.log(data));
  }

  ngOnInit() { }
}
