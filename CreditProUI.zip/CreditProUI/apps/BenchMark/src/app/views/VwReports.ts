import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reports'
})

export class ReportsComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
