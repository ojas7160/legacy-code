import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mmcaBase',
  template: ``
})

export class MMCABaseComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
