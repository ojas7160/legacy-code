import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-earningsStatementTrend',
  template: '<lib-uc-financial-trend></lib-uc-financial-trend>'
})

export class EarningsStatementTrendComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
