import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-projections',
  template: '<lib-uc-financial-trend></lib-uc-financial-trend>'
})

export class ProjectionsComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
