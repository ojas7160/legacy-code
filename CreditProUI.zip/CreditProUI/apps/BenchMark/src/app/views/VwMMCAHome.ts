import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mmcaHome',
  template: ``
})

export class MMCAHomeComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
