import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS, HttpClientXsrfModule } from '@angular/common/http';

// Import ngx-translate and the http loader
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { GridModule } from '@progress/kendo-angular-grid';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

//Shared library Module/Service/Interceptor
import { SharedModule } from '../../../Shared/src/shared.module';
import { SharedLibraryService } from '../../../Shared/src/lib/services/wcf/shared-library.service';
import { HttpInterceptorImpl } from '../../../Shared/src/lib/services/rest/HttpInterceptorImpl';


import { BalancesheetComponent } from './balancesheet/balancesheet.component';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { IndicatorsModule } from '@progress/kendo-angular-indicators';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';




@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    BalancesheetComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    GridModule,
    BrowserAnimationsModule,
    SharedModule,
    HttpClientModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    StoreModule.forRoot({}, {}),
    EffectsModule.forRoot([]),
    IndicatorsModule,
    NgbModule
  ],
  providers: [SharedLibraryService],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor() {

  }
  ngDoBootstrap() {
  }

}
//Load Application Translation
export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
 }
