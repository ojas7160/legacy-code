import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';  // Translation
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { Title } from '@angular/platform-browser';
//Import AppGlobal Service
import { ApplicationGlobalService } from '../app/application-global.service';
//Shared Service Reference
import { SharedLibraryService } from '../../../Shared/src/lib/services/wcf/shared-library.service';

@Injectable({
  providedIn: 'root'
})
export class ApplicationLibraryService {
  public activityCode: string;
  constructor(
    private translate: TranslateService,
    private titleService: Title,
    private appGlobal: ApplicationGlobalService,
    private sharedService: SharedLibraryService

  ) {
  }
  activateRouteData(activatedRoute: ActivatedRoute) {
    let title = '';
    let pageHeader = '';
    if (activatedRoute) {
      activatedRoute.data.subscribe(data => {
        this.appGlobal.appRouteData = data;
        if (this.appGlobal.appRouteData) {
          // console.log("this.appglobal.appRouteData.title -->", this.appglobal.appRouteData.title);
          if (this.appGlobal.appRouteData.title) {
            //if (this.sharedService.getTranslation(this.appGlobal.appRouteData.title)) {
              // console.log("Route Title", this.appglobal.appRouteData.title);
              title = this.sharedService.getTranslation(this.appGlobal.appRouteData.title);
            //}
          }
          else {
            title = 'FPI Portal Home';
          }
          this.titleService.setTitle(title);
         }

      });
    }

  }
}
