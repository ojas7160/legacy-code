import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { BalancesheetComponent } from './balancesheet/balancesheet.component';
const routes: Routes =
  [
    {
      path: '', component: HomeComponent, pathMatch: 'full', data: { title: 'app.pageheader.home', activityCode: '', homeLinkEnable: true, showFooter: true, showProgressbar: true, showStepper: false, showPageHeader: false }
    },
    {
      path: 'balancesheetBS', component: BalancesheetComponent, pathMatch: 'full', data: { title: 'app.pageheader.balancesheet', activityCode: 'BS', homeLinkEnable: true, showFooter: true, showProgressbar: true, showStepper: false, showPageHeader: false }
    }
  ]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
