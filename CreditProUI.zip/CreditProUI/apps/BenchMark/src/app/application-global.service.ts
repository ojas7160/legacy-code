import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ApplicationGlobalService {
  /********************************************************
   *Application Level Global Variable Declarations
   ********************************************************/
  public environment = '';
  public buildInfo = '';
  public serverName = '';

  //ReadOnly Variable Declaration
  public baseApplicantServiceUrl = 'cpoweb/cpors/';
  readonly lcaUrl: string = './assets/json/LCA.json';
  readonly closingUrl: string = './assets/json/closingbalance.json';
  readonly openingUrl: string = './assets/json/oeningbalance.json';
  readonly purchasesUrl: string = './assets/json/purchases.json';
  readonly customerSearchUrl: string = './assets/json/customersearch.json';
  readonly customerSearchListURL: string = './assets/json/customerSearchList.json';
  readonly recentCustomerListURL: string = './assets/json/RecentCustomers.json';
  // App route data to keep state when one page to another at global level.
  public deviceDetectorInfo: any;
  public appRouteData: any;
  readonly RetrieveFilteredReportURL: string = 'http://10.161.51.209:41751/MMCAServiceRest.svc/apinew/RetrieveFilteredReportConfiguration';

 
} 
