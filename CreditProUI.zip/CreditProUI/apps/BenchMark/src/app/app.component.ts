import { Component } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd, NavigationStart } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

//Application Level Sharing
import { ApplicationGlobalService,  } from './application-global.service';
import { ApplicationLibraryService } from './application-library.service';
//Shared Service Reference
import { 
         SharedLibraryService, 
         AppDeviceDetectorService } from '../../../Shared/src/lib/services';
//Import Device information


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'fpiApplication1';
  activityCode: string = '';
  constructor
    (
      public router: Router,
      public activatedroute: ActivatedRoute,
      
      private translate: TranslateService,
      public applibrary: ApplicationLibraryService,
      public appglobal: ApplicationGlobalService,
      public sharedLibrary: SharedLibraryService,
      private deviceDetector: AppDeviceDetectorService
    ) {
    // CALL Initial Load Functions
    this.loadInitialAppStates();
  }
  // Calling from app component constructor
  loadInitialAppStates() {
    // Setup the translation to default english language
    this.translate.setDefaultLang('en');
    this.appglobal.appRouteData = {};
    // Get Device Information
    this.appglobal.deviceDetectorInfo = this.deviceDetector.getDeviceInfo();
    console.log("App Accessed From-->", this.appglobal.deviceDetectorInfo)

   }
}
