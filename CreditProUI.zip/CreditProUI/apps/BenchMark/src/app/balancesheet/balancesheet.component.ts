import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
//Application Level Sharing
import { ApplicationGlobalService } from '../application-global.service';
import { ApplicationLibraryService } from '../application-library.service';
//Shared Service Reference
import { SharedLibraryService } from '../../../../Shared/src/lib/services';

@Component({
  selector: 'app-balancesheet',
  templateUrl: './balancesheet.component.html',
  styleUrls: ['./balancesheet.component.scss']
})
export class BalancesheetComponent implements OnInit {
  closingTemplateURI: string;
  openingTemplateURI: string;
  purchasesTemplateURI: string;
  constructor(
    public appGlobal: ApplicationGlobalService,
    public appLibrary: ApplicationLibraryService,
    public sharedLibrary: SharedLibraryService,
    public activatedroute: ActivatedRoute,
    public router: Router
  ) { }

  ngOnInit(): void {
    this.initializeFormLoad();
  }
  initializeFormLoad() {
    // Stop Browser Back Button functioning
    this.sharedLibrary.preventBackButton();
    //Load Application Route Data
    this.getRouteData();

    this.closingTemplateURI = this.appGlobal.closingUrl;
    this.openingTemplateURI = this.appGlobal.openingUrl;
    this.purchasesTemplateURI = this.appGlobal.purchasesUrl;
  }
  getRouteData() {
    this.appLibrary.activateRouteData(this.activatedroute);
  }
  //Page Event
  onClickBack() {
    this.router.navigate(['']);
  }
}
