import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
//Application Level Sharing
import { ApplicationGlobalService } from '../application-global.service';
import { ApplicationLibraryService } from '../application-library.service';
//Shared Service Reference
import { SharedLibraryService } from '../../../../Shared/src/lib/services';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  
  constructor(
    public appGlobal: ApplicationGlobalService,
    public appLibrary: ApplicationLibraryService,
    public sharedLibrary: SharedLibraryService,
    public activatedroute: ActivatedRoute,

  ) { }

  ngOnInit(): void {
    this.initializeFormLoad();
  }
  initializeFormLoad() {
    // Stop Browser Back Button functioning
    this.sharedLibrary.preventBackButton();
    //Load Application Route Data
    this.getRouteData();

  }
  getRouteData() {
    this.appLibrary.activateRouteData(this.activatedroute);
  }
}
